from flask import Flask, request, jsonify, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_mail import Mail, Message
from flask_cors import CORS
from dotenv import load_dotenv, dotenv_values
from werkzeug.security import generate_password_hash, check_password_hash
from jinja2 import TemplateNotFound
from datetime import datetime, timedelta, time

import pandas as pd
import traceback
import os

# =================== CONFIGURACIÓN BASE ===================
base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

templates_path = os.path.join(base_dir, 'templates')
static_path = os.path.join(base_dir, 'static')
dotenv_path = os.path.join(base_dir, '.env')

load_dotenv(dotenv_path)
env_vars = dotenv_values(dotenv_path)

app = Flask(__name__, template_folder=templates_path, static_folder=static_path)
CORS(app)


app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_DATABASE_URI'] = env_vars.get('DATABASE_URL')

# Configurar correo
try:
    app.config['MAIL_SERVER'] = env_vars.get('MAIL_SERVER')
    app.config['MAIL_PORT'] = int(env_vars.get('MAIL_PORT', 0))
    app.config['MAIL_USE_TLS'] = str(env_vars.get('MAIL_USE_TLS', 'False')).lower() == 'true'
    app.config['MAIL_USERNAME'] = env_vars.get('MAIL_USERNAME')
    app.config['MAIL_PASSWORD'] = env_vars.get('MAIL_PASSWORD')
    app.config['MAIL_DEFAULT_SENDER'] = env_vars.get('MAIL_FROM')
except Exception:
    traceback.print_exc()

db = SQLAlchemy(app)
mail = Mail(app)

# =================== MODELOS ===================
class Usuario(db.Model):
    __tablename__ = 'usuarios'
    idusuario = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nombre = db.Column(db.String(150), nullable=True)
    correo = db.Column(db.String(150), nullable=False, unique=True)
    cedula = db.Column(db.String(50), nullable=True)
    celular = db.Column(db.String(20), nullable=True)  
    rol = db.Column(db.String(50), nullable=True)
    password = db.Column(db.String(1024), nullable=False)
    status = db.Column(db.String(45), nullable=False, default='Activo')
    codigo = db.Column(db.String(50), nullable=True)

class TipoRecurso(db.Model):
    __tablename__ = 'tipo_recurso'
    idtipo_recurso = db.Column(db.Integer, primary_key=True, autoincrement=True)
    tipo_recurso = db.Column(db.String(150), nullable=False)
    status = db.Column(db.String(50), nullable=False, default='Activo')

    recursos = db.relationship('Recurso', back_populates='tipo_rel')

class Recurso(db.Model):
    __tablename__ = 'recursos'
    idrecursos = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nombre = db.Column(db.String(150), nullable=False)
    descripcion = db.Column(db.String(255))
    tipo = db.Column(db.Integer, db.ForeignKey('tipo_recurso.idtipo_recurso'), nullable=False)
    status = db.Column(db.String(50), nullable=False, default='Activo')
    inventario = db.Column(db.Integer, nullable=True)

    tipo_rel = db.relationship('TipoRecurso', back_populates='recursos')

class SolicitudUsuario(db.Model):
    __tablename__ = 'solicitudes_usuario'
    id_soli = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    nombre = db.Column(db.String(150))
    correo = db.Column(db.String(150))
    cedula = db.Column(db.String(50))
    telefono = db.Column(db.String(20))
    rol = db.Column(db.String(50))
    password = db.Column(db.String(1024))

class Edificio(db.Model):
    __tablename__ = 'edificios'
    idedificios = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(45))

class Prestamo(db.Model):
    __tablename__ = "prestamos"

    idprestamos = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nombre = db.Column(db.String(45))
    telefono = db.Column(db.String(45))
    correo = db.Column(db.String(128))
    tipo_recurso = db.Column(db.String(45))
    recurso = db.Column(db.String(128))
    edificio = db.Column(db.String(45))
    aula = db.Column(db.String(45))
    fecha_reserva = db.Column(db.Date)
    hora_inicio = db.Column(db.Time)
    hora_fin = db.Column(db.Time)
    descripcion = db.Column(db.String(1024))
    estado = db.Column(db.String(45), default="Pendiente")

class Aulas(db.Model):
    __tablename__ = 'aulas'

    idaulas = db.Column(db.Integer, primary_key=True)
    aula = db.Column(db.String(45))
    edificio = db.Column(db.Integer, db.ForeignKey('edificios.idedificios'))
    status = db.Column(db.String(45))  
    edificio_rel = db.relationship("Edificio", backref="aulas")
    diario_aulas = db.relationship("DiarioAulas", backref="aula_rel")  # Relación con DiarioAulas

class DiarioAulas(db.Model):
    __tablename__ = 'diario_aulas'

    iddiario_aulas = db.Column(db.Integer, primary_key=True, autoincrement=True)
    docente = db.Column(db.String(128))
    fecha = db.Column(db.Date)
    hora_inicio = db.Column(db.Time)
    hora_fin = db.Column(db.Time)
    aula = db.Column(db.String(128))  
    asignatura = db.Column(db.String(128))
    aula_id = db.Column(db.Integer, db.ForeignKey('aulas.idaulas'))  




# =================== RUTAS PRINCIPALES ===================
@app.route('/')
def index():
    return render_template('Login.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        solicitud_id = request.args.get('solicitud_id')
        return render_template('Login.html', solicitud_id=solicitud_id)

    # Si es POST (inicio de sesión)
    try:
        data = request.get_json()
        correo = data.get('correo')
        clave = data.get('clave')
        rol = data.get('rol')

        if not correo or not clave or not rol:
            return jsonify({
                'success': False,
                'message': 'Correo, clave y rol son requeridos'
            }), 400

        usuario = Usuario.query.filter_by(correo=correo, rol=rol).first()
        if not usuario:
            return jsonify({
                'success': False,
                'message': 'Usuario no encontrado'
            }), 404

        if not check_password_hash(usuario.password, clave):
            return jsonify({
                'success': False,
                'message': 'Contraseña incorrecta'
            }), 401

        # ✅ Si todo está bien
        solicitud_id = request.args.get('solicitud_id')

        if rol.lower() == 'administrador' and solicitud_id:
            return jsonify({
                'success': True,
                'redirect': f'/Usuarios.html?solicitud_id={solicitud_id}',
                'message': 'Inicio de sesión exitoso',
                'nombre': usuario.nombre,
                'rol': usuario.rol
            })

        return jsonify({
            'success': True,
            'message': 'Inicio de sesión exitoso',
            'nombre': usuario.nombre,
            'rol': usuario.rol
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'message': f'Error interno del servidor: {str(e)}'
        }), 500


@app.route('/Calendario')
def calendario():
    return render_template('Calendario.html')

@app.route('/Diario')
def diario():
    return render_template('Diario.html')

@app.route('/Diario_Aulas')
def aulas():
    return render_template('Diario_aulas.html')

@app.route('/Salas')
def salas():
    return render_template('Salas.html')


@app.route('/registro')
@app.route('/Registro.html')
def registro():
    try:
        return render_template('Registro.html')
    except TemplateNotFound:
        try:
            templates_list = os.listdir(templates_path)
        except Exception:
            templates_list = []
        return (
            "<h2>Extraviado</h2>"
            "<p>La plantilla <strong>Registro.html</strong> no se encontró en /templates.</p>"
            f"<p>Archivos en templates: {', '.join(templates_list) if templates_list else 'no se pudo listar'}</p>"
            "<p><a href='/'>Volver al inicio</a></p>",
            404,
        )


@app.route('/Usuarios')
@app.route('/Usuarios.html')
def usuarios():
    try:
        return render_template('Usuarios.html')
    except TemplateNotFound:
        try:
            templates_list = os.listdir(templates_path)
        except Exception:
            templates_list = []
        return (
            "<h2>Extraviado</h2>"
            "<p>La plantilla <strong>Usuarios.html</strong> no se encontró en /templates.</p>"
            f"<p>Archivos en templates: {', '.join(templates_list) if templates_list else 'no se pudo listar'}</p>"
            "<p><a href='/'>Volver al inicio</a></p>",
            404,
        )
    
# ---------------------------------------------------------
# RECUPERACIÓN DE CONTRASEÑA
# ---------------------------------------------------------

from flask_mail import Message
import random, string

# 1️⃣ Enviar código de recuperación al correo
@app.route('/enviar_codigo', methods=['POST'])
def enviar_codigo():
    try:
        data = request.get_json()
        correo = data.get('correo')

        if not correo:
            return jsonify({'success': False, 'error': 'Correo es obligatorio.'}), 400

        usuario = Usuario.query.filter_by(correo=correo).first()
        if not usuario:
            return jsonify({'success': False, 'error': 'El correo no está registrado.'}), 404

        # Generar código aleatorio de 6 dígitos
        codigo = ''.join(random.choices(string.digits, k=6))
        usuario.codigo = codigo
        db.session.commit()

        # Enviar correo
        msg = Message(
            subject="Código de recuperación - Sistema de Inventario",
            recipients=[correo],
            body=f"Tu código de recuperación es: {codigo}\n\nPor seguridad, no lo compartas con nadie."
        )
        mail.send(msg)

        return jsonify({'success': True, 'message': 'Código enviado correctamente.'})

    except Exception as e:
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500


# 2️⃣ Verificar código ingresado por el usuario
@app.route('/verificar_codigo', methods=['POST'])
def verificar_codigo():
    try:
        data = request.get_json()
        correo = data.get('correo')
        codigo = data.get('codigo')

        usuario = Usuario.query.filter_by(correo=correo).first()
        if not usuario:
            return jsonify({'success': False, 'error': 'Usuario no encontrado.'}), 404

        if usuario.codigo == codigo:
            return jsonify({'success': True, 'message': 'Código verificado correctamente.'})
        else:
            return jsonify({'success': False, 'error': 'Código incorrecto.'})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500


# 3️⃣ Cambiar la contraseña después de verificar
@app.route('/cambiar_clave', methods=['POST'])
def cambiar_clave():
    try:
        data = request.get_json()
        correo = data.get('correo')
        nueva_clave = data.get('nueva_clave')

        usuario = Usuario.query.filter_by(correo=correo).first()
        if not usuario:
            return jsonify({'success': False, 'error': 'Usuario no encontrado.'}), 404

        # Hashear la nueva contraseña
        hashed = generate_password_hash(nueva_clave, method='pbkdf2:sha256')
        usuario.clave = hashed
        usuario.codigo = None  # Limpia el código
        db.session.commit()

        return jsonify({'success': True, 'message': 'Contraseña cambiada exitosamente.'})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500
    
    
@app.route('/api/eventos_calendario', methods=['GET'])
def eventos_calendario():
    try:
        eventos_fc = []

        # ===== CLASES =====
        eventos_db = DiarioAulas.query.join(DiarioAulas.aula_rel)\
            .filter(Aulas.aula.ilike('%INFORMATICA%'))\
            .all()

        for evento in eventos_db:
            inicio = evento.fecha.strftime('%Y-%m-%d') + 'T' + evento.hora_inicio.strftime('%H:%M:%S')
            fin = evento.fecha.strftime('%Y-%m-%d') + 'T' + evento.hora_fin.strftime('%H:%M:%S')

            eventos_fc.append({
                'id': evento.iddiario_aulas,
                'titulo': f"{evento.docente} - {evento.aula}",
                'start': inicio,
                'end': fin,
                'color': '#FFC107',
                'tipo': 'clase'   # <- para diferenciar en frontend
            })

        # ===== PRÉSTAMOS =====
        prestamos_db = Prestamo.query.all()  # o agregar filtros si quieres

        for p in prestamos_db:
            # Validar que fecha y hora existan
            if not p.fecha_reserva or not p.hora_inicio:
                continue

            inicio = p.fecha_reserva.strftime('%Y-%m-%d') + 'T00:00:00'  # al inicio del día
            fin = p.fecha_reserva.strftime('%Y-%m-%d') + 'T00:00:00'     # mismo que inicio, se muestra como “todo el día”

            color = "#E67E22" if p.estado.lower() == "pendiente" else "#2980B9" if p.estado.lower() == "en uso" else "#7f8c8d"

            eventos_fc.append({
                'id': p.idprestamos,
                'titulo': f"{p.tipo_recurso} - {p.recurso} ({p.estado})",
                'start': inicio,
                'end': fin,
                'color': color,
                'tipo': 'prestamo',
                'estado': p.estado.lower()
            })

        return jsonify(eventos_fc)

    except Exception as e:
        print(f"Error al cargar eventos: {e}")
        return jsonify({'error': 'Error interno del servidor al cargar eventos.'}), 500

    

# ====== SUBIR EXCEL ======

excel_to_db_aulas = {
            "JLB- SALA DE INFORMATICA 1": "SALA DE INFORMATICA 1",
            "JLB- SALA DE INFORMATICA 2": "SALA DE INFORMATICA 2",
            "JLB- SALA DE INFORMATICA 3": "SALA DE INFORMATICA 3",
            "JLB- SALA DE INFORMATICA 4": "SALA DE INFORMATICA 4",
            "JLB- SALA DE INFORMATICA 5": "SALA DE INFORMATICA 5",
            "SALA DE INFORMATICA 6 (TELEMATICA)": "SALA DE INFORMATICA 6",
            "JLB- SALA DE INFORMATICA 7": "SALA DE INFORMATICA 7",
            "JLB- SALA DE INFORMATICA 8": "SALA DE INFORMATICA 8",
            "JLB- SALA DE INFORMATICA 9": "SALA DE INFORMATICA 9",
            "JLB- SALA DE INFORMATICA 10": "SALA DE INFORMATICA 10",
            "402-SALA DE INFORMATICA 12": "SALA DE INFORMATICA 12",
            "405 SALA DE INFORMATICA MAC ESTUDIO": "SALA DE INFORMATICA MAC JLB",
            "SALA INFORMATICA 16": "SALA DE INFORMATICA 16",
            "SALA INFORMATICA 17": "SALA DE INFORMATICA 17",
            "SALA INFORMATICA 18": "SALA DE INFORMATICA 18",
            "SALA INFORMATICA 19": "SALA DE INFORMATICA 19",
            "CLLR - SALA DE INFORMATICA 13 P 201": "SALA DE INFORMATICA 201",
            "CLLR-505 SALA DE INFORMATICA": "SALA DE INFORMATICA 505",
            "CLLR-601 SALA DE INFORMATICA": "SALA DE INFORMATICA 601",
            "SALA DE INFORMATICA 11 (SALA MAC)  - DC": "SALA DE INFORMATICA MAC DC",
        }

@app.route('/api/upload_horario_aulas', methods=['POST'])
def upload_horario_aulas():
    import re

    file = request.files.get('horario_excel')
    semana = request.form.get('semana')
    fecha_str = request.form.get('fecha')

    if not file or not fecha_str:
        return jsonify({'success': False, 'error': 'Falta archivo o fecha'}), 400

    fecha_excel = datetime.strptime(fecha_str, '%Y-%m-%d').date()
    df = pd.read_excel(file, skiprows=8).fillna("")

    # Normalizar nombres de columnas
    df.columns = [str(c).upper().strip() for c in df.columns]

    if 'AULA' not in df.columns or 'HORA' not in df.columns:
        return jsonify({'success': False, 'error': 'Columna AULA o HORA no encontrada'}), 400

    col_s1 = [c for c in df.columns if c == '1']
    col_s2 = [c for c in df.columns if c == '2']

    def tiene_x(row, columnas):
        return any(str(row[c]).strip().upper() == 'X' for c in columnas) if columnas else False

    def debe_subirse(row):
        x1 = tiene_x(row, col_s1)
        x2 = tiene_x(row, col_s2)
        if not x1 and not x2:
            return True
        if semana == '1' and x1:
            return True
        if semana == '2' and x2:
            return True
        return False

    # Solo aulas de informática
    df = df[df['AULA'].astype(str).str.upper().str.contains("INFORMATICA")]
    df = df[df.apply(debe_subirse, axis=1)]

    # Crear diccionario de aulas en DB para buscar ID rápidamente
    aulas_bd = {a.aula: a.idaulas for a in Aulas.query.all()}

    # Borrar registros existentes para la fecha
    DiarioAulas.query.filter_by(fecha=fecha_excel).delete()
    db.session.commit()

    insertados = 0
    filas_sin_aula = []

    for _, row in df.iterrows():
        try:
            h_ini, h_fin = row['HORA'].split(" - ")
            hora_inicio = datetime.strptime(h_ini.strip(), '%I:%M:%S %p').time()
            hora_fin = datetime.strptime(h_fin.strip(), '%I:%M:%S %p').time()
        except:
            continue

        # Mapear nombre de aula Excel → DB
        aula_nombre = map_aula_excel_to_db(row.get('AULA', ''))
        aula_id = aulas_bd.get(aula_nombre)

        if not aula_id:
            filas_sin_aula.append(row.get('AULA', ''))
            continue  # no insertar filas sin aula válida

        nuevo = DiarioAulas(
            docente=row.get('DOCENTE', ''),
            fecha=fecha_excel,
            hora_inicio=hora_inicio,
            hora_fin=hora_fin,
            aula=aula_nombre,
            aula_id=aula_id,
            asignatura=row.get('ASIGNATURA', '')
        )

        db.session.add(nuevo)
        insertados += 1

    db.session.commit()

    # Actualizar estados de aulas automáticamente según los horarios
    try:
        api_actualizar_estados_horario()
    except Exception as e:
        print("⚠ Error al actualizar estados:", e)

    mensaje = f'Se subieron {insertados} registros para la fecha {fecha_excel}'
    if filas_sin_aula:
        mensaje += f"; No se encontraron aulas para: {', '.join(filas_sin_aula)}"

    return jsonify({
        'success': True,
        'message': mensaje
    })



@app.route("/api/aulas_reservas/<int:id_reserva>/estado", methods=["PUT"])
def actualizar_estado_aula(id_reserva):
    datos = request.get_json()
    if not datos or 'estado' not in datos:
        return jsonify({"success": False, "error": "No se recibió el estado"}), 400

    nueva_estado = datos['estado']

    # Buscar la reserva en la DB
    reserva = DiarioAulas.query.filter_by(iddiario_aulas=id_reserva).first()
    if not reserva:
        return jsonify({"success": False, "error": "Reserva no encontrada"}), 404

    # Actualizar estado
    reserva.estado = nueva_estado
    try:
        db.session.commit()
        return jsonify({"success": True, "nuevo_estado": nueva_estado})
    except Exception as e:
        db.session.rollback()
        return jsonify({"success": False, "error": str(e)}), 500


def map_aula_excel_to_db(nombre_excel):
    n = nombre_excel.upper().strip()

    # Si coincide exacto → lo devolvemos
    if n in excel_to_db_aulas:
        return excel_to_db_aulas[n]

    # Quita prefijos comunes y espacios extras
    n = n.replace("JLB-", "").replace("CLLR-", "")
    n = n.replace("SALA DE ", "SALA DE ").strip()

    return n


@app.route('/api/salas_informatica')
def salas_informatica():
    hoy = datetime.today().date()
    ahora = datetime.now().time()

    aulas = Aulas.query.filter(Aulas.aula.ilike("%informatica%")).all()
    respuesta = []

    for aula in aulas:
        registros_hoy = [
            r for r in aula.diario_aulas
            if r.fecha == hoy and r.hora_inicio and r.hora_fin
        ]
        horarios = [(r.hora_inicio, r.hora_fin) for r in registros_hoy]
        estado_db = (aula.status or "").strip()
        estado_final = calcular_estado_sala(horarios, estado_db, ahora)

        respuesta.append({
            "id": aula.idaulas,
            "aula": aula.aula,
            "edificio": aula.edificio_rel.nombre if aula.edificio_rel else "Sin nombre",
            "status": estado_final or "Cerrada"
        })

    return jsonify(respuesta)



BLOQUES = [
    ("mañana", time(6, 0), time(11, 15)),
    ("tarde", time(14, 0), time(17, 15)),
    ("noche", time(18, 30), time(21, 40)),
]

# -------------------
# Util: buscar el siguiente inicio y el último fin de clases en "horarios" (lista de (start,end) times)
# -------------------
def obtener_siguiente_y_ultimo(ahora, horarios):
   
    siguientes = [s for (s, f) in horarios if s > ahora]
    siguiente_inicio = min(siguientes) if siguientes else None

    fines = [f for (_, f) in horarios]
    ultimo_fin = max(fines) if fines else None

    return siguiente_inicio, ultimo_fin

def horario_en_bloque(horario_start, horario_end, bloque_start, bloque_end):
  
    return not (horario_end <= bloque_start or horario_start >= bloque_end)

# -------------------
# Función para calcular estado automático de la sala
# -------------------
def calcular_estado_sala(horarios, estado_db, ahora_time):
    """
    Calcula el estado de una sala según horarios, bloques y hora actual.
    - "Por abrir": si hay una clase próxima en menos de 30 minutos.
    - "En uso": si hay una clase en curso.
    - "Abierta": si hay hueco entre clases dentro del bloque.
    - "Por cerrar": si faltan 15 minutos para la última clase del bloque.
    - "Cerrada": si ya terminó la última clase del bloque o no hay clases.
    """

    manuales = {"Abierta", "Cerrado", "En uso"}
    if estado_db in manuales:
        return estado_db

    ahora_dt = datetime.combine(datetime.today(), ahora_time)

    if not horarios:
        return "Cerrada"

    horarios_sorted = sorted(horarios, key=lambda x: x[0])

    # Buscar bloque actual
    bloque_actual = None
    for nombre, start, end in BLOQUES:
        if start <= ahora_time <= end:
            bloque_actual = (start, end)
            break

    # Si no hay bloque actual, ver si falta clase para próximo bloque
    if not bloque_actual:
        futuras = [inicio for inicio, fin in horarios_sorted if inicio > ahora_time]
        if futuras:
            siguiente_inicio = min(futuras)
            diff_min = (datetime.combine(datetime.today(), siguiente_inicio) - ahora_dt).total_seconds() / 60
            if 0 <= diff_min <= 30:
                return "Por abrir"
        return "Cerrada"

    start_bloque, end_bloque = bloque_actual

    # Filtrar clases dentro del bloque actual
    clases_en_bloque = [
        (inicio, fin) for inicio, fin in horarios_sorted
        if horario_en_bloque(inicio, fin, start_bloque, end_bloque)
    ]
    if not clases_en_bloque:
        return "Cerrada"

    # 1. ¿Estamos dentro de alguna clase? -> En uso
    for inicio, fin in clases_en_bloque:
        if inicio <= ahora_time <= fin:
            return "En uso"

    # 2. ¿Hay una clase próxima en menos de 30 minutos? -> Por abrir
    futuras = [(inicio, fin) for inicio, fin in clases_en_bloque if inicio > ahora_time]
    if futuras:
        siguiente_inicio, _ = futuras[0]
        diff_min = (datetime.combine(datetime.today(), siguiente_inicio) - ahora_dt).total_seconds() / 60
        if 0 <= diff_min <= 30:
            return "Por abrir"

    # 3. ¿Hay hueco entre clases dentro del bloque? -> Abierta
    # Si hay una clase anterior que ya terminó y otra futura en el mismo bloque, la sala debe quedar "Abierta"
    pasadas = [(inicio, fin) for inicio, fin in clases_en_bloque if fin < ahora_time]
    if pasadas and futuras:
        # Estamos entre dos clases dentro del bloque
        return "Abierta"

    # 4. ¿Faltan 15 minutos para la última clase del bloque? -> Por cerrar
    ultimo_fin = max(fin for _, fin in clases_en_bloque)
    diff_fin = (datetime.combine(datetime.today(), ultimo_fin) - ahora_dt).total_seconds() / 60
    if 0 <= diff_fin <= 15:
        return "Por cerrar"

    # 5. Si ya pasó la última clase del bloque
    if ahora_time > ultimo_fin:
        return "Cerrada"

    # Default
    return "Cerrada"

def horario_en_bloque(horario_start, horario_end, bloque_start, bloque_end):
    """
    Devuelve True si el horario [horario_start, horario_end] se solapa con el bloque [bloque_start, bloque_end]
    """
    return not (horario_end <= bloque_start or horario_start >= bloque_end)

# -------------------
# Endpoint: actualizar estados según horarios
# -------------------
@app.route('/api/actualizar_estados_horario', methods=['POST'])
def api_actualizar_estados_horario():
    try:
        hoy = datetime.today().date()
        ahora = datetime.now().time()
        aulas = Aulas.query.filter(Aulas.aula.ilike("%informatica%")).all()
        cambios = 0

        manuales = {"Abierta", "Cerrado", "En uso"}

        for aula in aulas:
            registros_hoy = [r for r in aula.diario_aulas if r.fecha == hoy]
            horarios = [(r.hora_inicio, r.hora_fin) for r in registros_hoy if r.hora_inicio and r.hora_fin]

            estado_db = aula.status or ""
            nuevo_estado = calcular_estado_sala(horarios, estado_db, ahora)

            # Solo actualizar si NO es manual
            if estado_db not in manuales and nuevo_estado != estado_db:
                aula.status = nuevo_estado
                cambios += 1

        db.session.commit()
        return jsonify({"success": True, "cambios": cambios}), 200

    except Exception as e:
        traceback.print_exc()
        db.session.rollback()
        return jsonify({"success": False, "error": str(e)}), 500


# -------------------
# Endpoint: cambio manual de estado
# -------------------
@app.route('/api/salas/<int:id>/estado', methods=['PUT'])
def actualizar_estado(id):
    sala = db.session.get(Aulas, id)
    if not sala:
        return jsonify({'error': 'Sala no encontrada'}), 404

    nuevo_estado = request.json.get('estado')
    if not nuevo_estado:
        return jsonify({'error': 'No se recibió el estado'}), 400

    # Normalizar y validar
    estados_validos = {"por_abrir", "abierto", "en_uso", "por_cerrar", "cerrado"}
    nuevo_estado = nuevo_estado.lower().replace(" ", "_")
    if nuevo_estado not in estados_validos:
        return jsonify({'error': 'Estado no válido'}), 400

    sala.status = nuevo_estado
    try:
        db.session.commit()
        return jsonify({'success': True, 'estado': sala.status})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500





# --- API PARA OBTENER LAS RESERVAS DE AULAS ---
@app.route("/api/aulas_reservas")
def aulas_reservas():
    hoy = datetime.today().date()
    registros = DiarioAulas.query.filter_by(fecha=hoy).all()

    resultado = []
    for r in registros:
        try:
            inicio_str = r.hora_inicio.strftime("%I:%M %p") if r.hora_inicio else "-"
            fin_str = r.hora_fin.strftime("%I:%M %p") if r.hora_fin else "-"
            aula_nombre = r.aula_rel.aula if getattr(r, "aula_rel", None) and getattr(r.aula_rel, "aula", None) else (getattr(r, "aula", None) or f"Aula ID {getattr(r, 'aula_id', 'N/A')}")
            resultado.append({
                "id": r.iddiario_aulas,
                "docente": r.docente or "-",
                "inicio": inicio_str,
                "fin": fin_str,
                "aula": aula_nombre,
                "asignatura": r.asignatura or "-",
                "estado": getattr(r, "estado", "-")
            })
        except Exception as e:
            print(f"Error procesando registro {getattr(r, 'iddiario_aulas', 'N/A')}: {e}")
            continue

    return jsonify(resultado)


# =================== CRUD DE TIPO RECURSO ===================
# ====== RENDERIZAR PÁGINA ======
@app.route('/TipoRecurso')
@app.route('/TipoRecurso.html')
def tipo_recurso():
    try:
        return render_template('TipoRecurso.html')
    except TemplateNotFound:
        try:
            templates_list = os.listdir(templates_path)
        except Exception:
            templates_list = []
        return (
            "<h2>Extraviado</h2>"
            "<p>La plantilla <strong>TipoRecurso.html</strong> no se encontró en /templates.</p>"
            f"<p>Archivos en templates: {', '.join(templates_list) if templates_list else 'no se pudo listar'}</p>"
            "<p><a href='/'>Volver al inicio</a></p>",
            404,
        )

# ====== LISTAR ======
@app.route('/TiposRecurso')
def obtener_tipos_recurso():
    try:
        tipos = TipoRecurso.query.all()
        data = [
            {
                "idtiporecurso": t.idtipo_recurso,
                "nombre": t.tipo_recurso,
                "status": t.status
            }
            for t in tipos
        ]
        return jsonify(data)
    except Exception as e:
        traceback.print_exc()
        return jsonify({"success": False, "error": str(e)}), 500

# ====== AGREGAR ======
@app.route('/tiporecurso/agregar', methods=['POST'])
def agregar_tipo_recurso():
    try:
        data = request.get_json()
        nombre = data.get('nombre', '').strip().upper()
        estado = data.get('status', 'Activo')

        if not nombre:
            return jsonify({'success': False, 'error': 'El nombre del tipo de recurso es obligatorio'}), 400

        # Evitar duplicados
        if TipoRecurso.query.filter_by(tipo_recurso=nombre).first():
            return jsonify({'success': False, 'error': 'Ya existe un tipo de recurso con ese nombre'}), 400

        nuevo_tipo = TipoRecurso(tipo_recurso=nombre, status=estado)
        db.session.add(nuevo_tipo)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500

# ====== ACTUALIZAR ======
@app.route('/tiporecurso/actualizar/<int:id>', methods=['POST'])
def actualizar_tipo_recurso(id):
    try:
        data = request.get_json()
        tipo = TipoRecurso.query.get(id)
        if not tipo:
            return jsonify({'success': False, 'error': 'Tipo de recurso no encontrado'}), 404

        tipo.tipo_recurso = data.get('nombre', tipo.tipo_recurso).strip().upper()
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500

# ====== CAMBIAR ESTADO ======
@app.route('/tiporecurso/estado/<int:id>', methods=['POST'])
def cambiar_estado_tipo_recurso(id):
    try:
        tipo = TipoRecurso.query.get(id)
        if not tipo:
            return jsonify({'success': False, 'error': 'Tipo de recurso no encontrado'}), 404

        tipo.status = "Inactivo" if tipo.status.lower() == "activo" else "Activo"
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500


# =================== CRUD DE RECURSOS ===================
@app.route('/Recurso')
@app.route('/Recurso.html')
def recurso():
    try:
        return render_template('Recurso.html')
    except TemplateNotFound:
        try:
            templates_list = os.listdir(templates_path)
        except Exception:
            templates_list = []
        return (
            "<h2>Extraviado</h2>"
            "<p>La plantilla <strong>Recurso.html</strong> no se encontró en /templates.</p>"
            f"<p>Archivos en templates: {', '.join(templates_list) if templates_list else 'no se pudo listar'}</p>"
            "<p><a href='/'>Volver al inicio</a></p>",
            404,
        )

@app.route('/Recursos', methods=['GET'])
def obtener_recursos():
    try:
        recursos = Recurso.query.join(TipoRecurso).all()
        lista = [
            {
                'idrecurso': r.idrecursos,
                'nombre': r.nombre,
                'descripcion': r.descripcion,
                'tipo': r.tipo_rel.tipo_recurso if r.tipo_rel else None,
                'status': r.status,
                'inventario': r.inventario
            }
            for r in recursos
        ]
        return jsonify(lista)
    except Exception as e:
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/Recursos/<int:id>', methods=['GET'])
def obtener_recurso(id):
    try:
        recurso = db.session.get(Recurso, id)
        if not recurso:
            return jsonify({'success': False, 'error': 'Recurso no encontrado'}), 404
        return jsonify({
            'idrecurso': recurso.idrecursos,
            'nombre': recurso.nombre,
            'descripcion': recurso.descripcion,
            'tipo': recurso.tipo_rel.tipo_recurso if recurso.tipo_rel else None,
            'tipo_id': recurso.tipo,
            'status': recurso.status,
            'inventario': recurso.inventario if recurso.inventario is not None else 0
        })
    except Exception as e:
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/Recursos', methods=['POST'])
def crear_recurso():
    try:
        data = request.get_json()
        nuevo = Recurso(
            nombre=data.get('nombre', '').upper(),
            descripcion=data.get('descripcion', '').upper(),
            tipo=data.get('tipo'),
            status=data.get('status', 'Activo'),
            inventario=int(data.get('inventario', 0))
        )
        db.session.add(nuevo)
        db.session.commit()
        return jsonify({'success': True, 'message': 'Recurso agregado correctamente'})
    except Exception as e:
        db.session.rollback()
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/Recursos/<int:id>', methods=['PUT'])
def actualizar_recurso(id):
    try:
        data = request.get_json()
        recurso = Recurso.query.get(id)
        if not recurso:
            return jsonify({'success': False, 'error': 'Recurso no encontrado'}), 404

        recurso.nombre = data.get('nombre', recurso.nombre).upper()
        recurso.descripcion = data.get('descripcion', recurso.descripcion).upper()
        recurso.tipo = data.get('tipo', recurso.tipo)
        recurso.status = data.get('status', recurso.status)
        recurso.inventario = int(data.get('inventario', recurso.inventario))

        db.session.commit()
        return jsonify({'success': True, 'message': 'Recurso actualizado correctamente'})
    except Exception as e:
        db.session.rollback()
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/Recursos/estado', methods=['PUT'])
def cambiar_estado():
    try:
        data = request.get_json()
        idrecurso = data.get('idrecurso')
        nuevo_status = data.get('status')

        recurso = Recurso.query.get(idrecurso)
        if not recurso:
            return jsonify({'success': False, 'error': 'Recurso no encontrado'}), 404

        recurso.status = nuevo_status
        db.session.commit()
        return jsonify({'success': True, 'message': f'Status actualizado a {nuevo_status}'})
    except Exception as e:
        db.session.rollback()
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/TiposRecurso', methods=['GET'])
def listar_tipos_recurso():
    try:
        tipos = TipoRecurso.query.all()
        lista = [
            {'id': t.idtipo_recurso, 'nombre': t.tipo_recurso, 'status': t.status}
            for t in tipos
        ]
        return jsonify(lista)
    except Exception as e:
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500

# =================== USUARIOS ===================
@app.route('/UsuariosDatos', methods=['GET'])
def obtener_usuarios():
    try:
        usuarios = Usuario.query.all()
        lista = [
            {
                'idusuario': u.idusuario,
                'nombre': u.nombre,
                'correo': u.correo,
                'cedula': u.cedula,
                'celular': u.celular,
                'rol': u.rol,
                'status': u.status
            }
            for u in usuarios
        ]
        return jsonify(lista)
    except Exception as e:
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/Usuarios/<int:id>', methods=['GET'])
def obtener_usuario(id):
    try:
        usuario = db.session.get(Usuario, id)
        if not usuario:
            return jsonify({'success': False, 'error': 'Usuario no encontrado'}), 404
        return jsonify({
            'idusuario': usuario.idusuario,
            'nombre': usuario.nombre,
            'correo': usuario.correo,
            'cedula': usuario.cedula,
            'celular': usuario.celular,
            'rol': usuario.rol,
            'status': usuario.status
        })
    except Exception as e:
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/Usuarios/<int:id>', methods=['PUT'])
def editar_usuario(id):
    try:
        data = request.get_json()
        usuario = Usuario.query.get(id)
        if not usuario:
            return jsonify({'success': False, 'error': 'Usuario no encontrado'}), 404

        usuario.nombre = data.get('nombre', usuario.nombre)
        usuario.correo = data.get('correo', usuario.correo)
        usuario.celular = data.get('celular', usuario.celular)
        usuario.rol = data.get('rol', usuario.rol)

        db.session.commit()
        return jsonify({'success': True, 'message': 'Usuario actualizado correctamente'})
    except Exception as e:
        db.session.rollback()
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/Usuarios/estado', methods=['PUT'])
def cambiar_estado_usuario():
    try:
        data = request.get_json()
        idusuario = data.get('idusuario')
        nuevo_status = data.get('status')

        usuario = Usuario.query.get(idusuario)
        if not usuario:
            return jsonify({'success': False, 'error': 'Usuario no encontrado'}), 404

        usuario.status = nuevo_status
        db.session.commit()
        return jsonify({'success': True, 'message': f'Status cambiado a {nuevo_status}'})
    except Exception as e:
        db.session.rollback()
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500
    

@app.route('/UsuariosAgregar', methods=['POST'])
def agregar_usuario():
    try:
        data = request.get_json()
        nombre = data.get('nombre')
        cedula = data.get('cedula')
        correo = data.get('correo')
        celular = data.get('celular')
        rol = data.get('rol')
        password = data.get('password')
        solicitud_id = data.get('solicitud_id')

        if not all([nombre, correo, rol]):
            return jsonify({'success': False, 'error': 'Nombre, correo y rol son obligatorios'}), 400

        # Si viene con contraseña desde solicitud, úsala, si no, genera una por defecto
        clave = password if password else 'Usuario123'
        password_hash = generate_password_hash(clave)

        # Evitar duplicados por correo
        if Usuario.query.filter_by(correo=correo).first():
            return jsonify({'success': False, 'error': 'Ya existe un usuario con ese correo.'}), 400


        nuevo_usuario = Usuario(
            nombre=nombre,
            cedula=cedula,
            correo=correo,
            celular=celular,
            rol=rol,
            password=password_hash,
            status='Activo'
        )

        db.session.add(nuevo_usuario)

        # Si proviene de una solicitud, eliminarla
        if solicitud_id:
            solicitud = db.session.get(SolicitudUsuario, solicitud_id)
            if solicitud:
                db.session.delete(solicitud)

        db.session.commit()
        return jsonify({'success': True, 'message': 'Usuario agregado correctamente desde solicitud' if solicitud_id else 'Usuario agregado correctamente'})
    except Exception as e:
        db.session.rollback()
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500
   

@app.route('/solicitar_usuario', methods=['POST'])
def solicitar_usuario():
    try:
        data = request.get_json()
        nombre = data.get('nombre')
        correo = data.get('correo')
        cedula = data.get('cedula')
        telefono = data.get('telefono')
        rol = data.get('rol')
        password = data.get('password')

        # Validar campos
        if not all([nombre, correo, cedula, telefono, rol, password]):
            return jsonify({'success': False, 'message': 'Todos los campos son obligatorios.'}), 400

        # Guardar sin encriptar
        solicitud = SolicitudUsuario(
            nombre=nombre,
            correo=correo,
            cedula=cedula,
            telefono=telefono,
            rol=rol,
            password=password
        )
        db.session.add(solicitud)
        db.session.commit()

        # Enviar correo al administrador
        try:
            enlace = f"http://127.0.0.1:5050/login?solicitud_id={solicitud.id_soli}"

            msg = Message(
                subject="Nueva solicitud de usuario",
                recipients=["favianrichardo@gmail.com"],
                html=f"""
                <h3>Nueva solicitud de registro</h3>
                <p>Se ha recibido una nueva solicitud con los siguientes datos:</p>
                <ul>
                    <li><strong>Nombre:</strong> {nombre}</li>
                    <li><strong>Correo:</strong> {correo}</li>
                    <li><strong>Cédula:</strong> {cedula}</li>
                    <li><strong>Teléfono:</strong> {telefono}</li>
                    <li><strong>Rol solicitado:</strong> {rol}</li>
                </ul>
                <p>
                    <a href="{enlace}" 
                    style="background-color:#007BFF;color:white;padding:10px 20px;text-decoration:none;border-radius:5px;">
                    Agregar usuario
                    </a>
                </p>
                <p>Al hacer clic, será redirigido al inicio de sesión para validar como administrador.</p>
                """
            )
            mail.send(msg)
        except Exception as mail_error:
            print("Error enviando correo:", mail_error)

        return jsonify({'success': True, 'message': 'Solicitud enviada correctamente.'})
    except Exception as e:
        db.session.rollback()
        traceback.print_exc()
        return jsonify({'success': False, 'message': str(e)}), 500
    

@app.route('/obtener_solicitud/<int:id_soli>', methods=['GET'])
def obtener_solicitud(id_soli):
    try:
        solicitud = db.session.get(SolicitudUsuario, id_soli)
        if not solicitud:
            return jsonify({'success': False, 'message': 'Solicitud no encontrada'}), 404
        
        return jsonify({
            'success': True,
            'solicitud': {
                'id': solicitud.id_soli,
                'nombre': solicitud.nombre,
                'correo': solicitud.correo,
                'cedula': solicitud.cedula,
                'telefono': solicitud.telefono,
                'rol': solicitud.rol,
                'password': solicitud.password
            }
        })
    except Exception as e:
        traceback.print_exc()
        return jsonify({'success': False, 'message': str(e)}), 500



# === RUTAS API PARA RESERVAS ===
# ==========================


@app.route('/api/tipos_recurso')
def obtener_tipos_recurso_api():
    tipos = TipoRecurso.query.all()
    return jsonify([
        {"id": t.idtipo_recurso, "nombre": t.tipo_recurso}
        for t in tipos
    ])


@app.route('/api/recursos_por_tipo/<int:id_tipo>')
def obtener_recursos_por_tipo(id_tipo):
    recursos = Recurso.query.filter_by(tipo=id_tipo).all()
    return jsonify([
        {"id": r.idrecursos, "nombre": r.nombre}
        for r in recursos
    ])


@app.route('/api/edificios')
def obtener_edificios():
    edificios_lista = Edificio.query.all()
    return jsonify([
        {'id': e.idedificios, 'nombre': e.nombre}
        for e in edificios_lista
    ])


@app.route('/api/aulas_por_edificio/<int:id_edificio>', methods=['GET'])
def obtener_aulas_por_edificio(id_edificio):
    aulas_lista = Aulas.query.filter_by(edificio=id_edificio).all()
    return jsonify([
        {
            'id': a.idaulas,
            'aula': a.aula,
            'edificio': a.edificio,
            'status': a.status
        }
        for a in aulas_lista

       
    ])


@app.route("/api/crear_prestamo", methods=["POST"])
def crear_prestamo():
    try:
        data = request.get_json()

        nuevo = Prestamo(
            nombre=data.get("nombre"),
            telefono=data.get("telefono"),
            correo=data.get("correo"),
            tipo_recurso=data.get("tipo_recurso"),
            recurso=data.get("recurso"),
            edificio=data.get("edificio"),
            aula=data.get("aula"),
            fecha_reserva=data.get("fecha_reserva"),
            hora_inicio=data.get("hora_inicio"),
            hora_fin=data.get("hora_fin"),
            descripcion=data.get("descripcion")
        )

        db.session.add(nuevo)
        db.session.commit()

        return jsonify({"success": True, "mensaje": "Prestamo creado correctamente"}), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500
    
    
@app.route("/api/prestamos", methods=["GET"])
def obtener_prestamos():
    prestamos = Prestamo.query.all()
    data = []
    
    for p in prestamos:
        
        hora_inicio_str = p.hora_inicio.strftime("%I:%M %p") if p.hora_inicio else None
        hora_fin_str = p.hora_fin.strftime("%I:%M %p") if p.hora_fin else None
        fecha_reserva_str = p.fecha_reserva.strftime("%d/%m/%Y") if p.fecha_reserva else None
        edificio = str(p.edificio) if p.edificio else ""
        aula = str(p.aula) if p.aula else ""
        partes_ubicacion = []

        if edificio:
            partes_ubicacion.append(edificio)

        if aula:
            partes_ubicacion.append(aula)
            
        if partes_ubicacion:
            ubicacion_unificada = "-".join(partes_ubicacion)
        else:
            ubicacion_unificada = "No especificada"
        
        data.append({
            "id": p.idprestamos,
            "nombre": p.nombre,
            "telefono": p.telefono,
            "correo": p.correo,
            "ubicacion": ubicacion_unificada, 
            "fecha": fecha_reserva_str, 
            "inicio": hora_inicio_str,
            "fin": hora_fin_str,
            "recurso": p.recurso,
            "descripcion": p.descripcion,
            "estado": p.estado 
        })
    
    return jsonify(data)

@app.route("/api/prestamos/<int:id_prestamo>", methods=["DELETE"])
def eliminar_prestamo(id_prestamo):
    try:
        # 1. BUSCAR EL OBJETO: Usa el ID para obtener la instancia completa del modelo.
        #    Asumiendo que 'Prestamo' es el nombre de tu modelo:
        prestamo_a_eliminar = Prestamo.query.get(id_prestamo) 
        
        # 2. VERIFICAR: Comprobar si la reserva existe
        if not prestamo_a_eliminar:
            return jsonify({"mensaje": "Error: Reserva no encontrada para el ID proporcionado."}), 404

        # 3. ELIMINAR EL OBJETO: Pasa la instancia del objeto, NO el ID.
        db.session.delete(prestamo_a_eliminar)
        
        # 4. CONFIRMAR: Guardar los cambios en la base de datos
        db.session.commit()
        
        # 5. RESPUESTA EXITOSA
        return jsonify({"mensaje": f"Reserva {id_prestamo} eliminada correctamente."}), 200

    except Exception as e:
        # Revertir la transacción si algo falla
        db.session.rollback()
        # Puedes imprimir el error en el log del servidor
        print(f"Error al intentar eliminar la reserva {id_prestamo}: {e}")
        return jsonify({"mensaje": "Error interno del servidor al eliminar la reserva."}), 500
    

# =================== ACTUALIZAR ESTADO DE PRÉSTAMO ===================
@app.route("/api/prestamos/<int:id_prestamo>/estado", methods=["PUT"])
def actualizar_estado_prestamo(id_prestamo):
    try:
        data = request.get_json()
        nuevo_estado = data.get('estado')

        if not nuevo_estado:
            return jsonify({"success": False, "error": "El nuevo estado es requerido."}), 400

        # 3. Buscar el préstamo en la base de datos por su ID (¡LÍNEA CORREGIDA!)
        # CAMBIO: De Prestamo.query.get a db.session.get
        prestamo = db.session.get(Prestamo, id_prestamo) 

        if not prestamo:
            return jsonify({"success": False, "error": "Préstamo no encontrado."}), 404

        prestamo.estado = nuevo_estado
        db.session.commit()

        return jsonify({
            "success": True, 
            "message": f"Estado del préstamo {id_prestamo} actualizado a '{nuevo_estado}'."
        }), 200

    except Exception as e:
        db.session.rollback()
        traceback.print_exc()
        return jsonify({
            "success": False, 
            "error": "Error interno del servidor al actualizar el estado."
        }), 500
    

# =================== ERRORES ===================
@app.errorhandler(404)
def pagina_no_encontrada(e):
    return (
        "<h2>Extraviado</h2>"
        "<p>La URL solicitada no se encontró en el servidor.</p>"
        "<p><a href='/'>Volver al inicio</a></p>",
        404,)
    

# =================== MAIN ===================
if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5050, debug=True)
