-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: centerbeam.proxy.rlwy.net    Database: railway
-- ------------------------------------------------------
-- Server version	9.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `aulas`
--

DROP TABLE IF EXISTS `aulas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aulas` (
  `idaulas` int NOT NULL AUTO_INCREMENT,
  `aula` varchar(45) NOT NULL,
  `edificio` int NOT NULL,
  `status` varchar(45) NOT NULL,
  PRIMARY KEY (`idaulas`),
  KEY `frk_edificios_idx` (`edificio`),
  CONSTRAINT `frk_edificio` FOREIGN KEY (`edificio`) REFERENCES `edificios` (`idedificios`)
) ENGINE=InnoDB AUTO_INCREMENT=259 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aulas`
--

LOCK TABLES `aulas` WRITE;
/*!40000 ALTER TABLE `aulas` DISABLE KEYS */;
INSERT INTO `aulas` VALUES (1,'SALA DE INFORMATICA 1',1,'abierto'),(2,'SALA DE INFORMATICA 2',1,'abierto'),(3,'SALA DE INFORMATICA 3',1,'abierto'),(4,'SALA DE INFORMATICA 4',1,'abierto'),(5,'SALA DE INFORMATICA 5',1,'abierto'),(6,'SALA DE INFORMATICA 6',1,'cerrado'),(7,'SALA DE INFORMATICA 7',1,'cerrado'),(8,'SALA DE INFORMATICA 8',1,'cerrado'),(9,'SALA DE INFORMATICA 9',1,'cerrado'),(10,'SALA DE INFORMATICA 10',1,'cerrado'),(11,'SALA DE INFORMATICA 12',1,'cerrado'),(12,'SALA DE INFORMATICA 16',2,'cerrado'),(13,'SALA DE INFORMATICA 17',2,'cerrado'),(14,'SALA DE INFORMATICA 18',2,'cerrado'),(15,'SALA DE INFORMATICA 19',2,'cerrado'),(16,'SALA DE INFORMATICA 201',3,'cerrado'),(17,'SALA DE INFORMATICA 404',1,'cerrado'),(18,'SALA DE INFORMATICA 505',3,'cerrado'),(19,'SALA DE INFORMATICA 601',3,'cerrado'),(20,'SALA DE INFORMATICA MAC JLB',1,'cerrado'),(21,'SALA DE INFORMATICA MAC DC',7,'cerrado'),(22,'AUDITORIO MENOR',1,'cerrado'),(23,'JLB-201',1,'cerrado'),(24,'JLB-202',1,'cerrado'),(25,'JLB-203',1,'cerrado'),(26,'JLB-301',1,'cerrado'),(27,'JLB-302',1,'cerrado'),(28,'JLB-303',1,'cerrado'),(29,'JLB-304',1,'cerrado'),(30,'JLB-305',1,'cerrado'),(31,'JLB-401',1,'cerrado'),(32,'JLB-403',1,'cerrado'),(33,'JLB-406',1,'cerrado'),(34,'JLB-TALLER DE DISEÑO 6',1,'cerrado'),(35,'ES-301',2,'cerrado'),(36,'ES-302',2,'cerrado'),(37,'ES-303',2,'cerrado'),(43,'ES-304',2,'cerrado'),(44,'ES-401',2,'cerrado'),(45,'ES-402',2,'cerrado'),(46,'ES-403',2,'cerrado'),(47,'ES-404',2,'cerrado'),(48,'ES-501',2,'cerrado'),(49,'ES-502',2,'cerrado'),(50,'ES-503',2,'cerrado'),(51,'ES-504',2,'cerrado'),(52,'ES-601',2,'cerrado'),(53,'ES-602',2,'cerrado'),(54,'ES-603 DIBUJO',2,'cerrado'),(55,'ES-604 DIBUJO',2,'cerrado'),(56,'ES-701',2,'cerrado'),(57,'ES-702',2,'cerrado'),(58,'ES-703',2,'cerrado'),(59,'ES-704',2,'cerrado'),(60,'ES-801',2,'cerrado'),(61,'ES-802',2,'cerrado'),(62,'ES-803',2,'cerrado'),(63,'ES-804',2,'cerrado'),(64,'ES-SALA DE AUDIENCIAS',2,'cerrado'),(65,'ES-SALA DE JUNTAS RECTORIA PISO 10',2,'cerrado'),(66,'CLLR-AUDITORIO SIMON RODRIGUEZ',3,'cerrado'),(67,'CLLR-302',3,'cerrado'),(68,'CLLR-303',3,'cerrado'),(69,'CLLR-304',3,'cerrado'),(70,'CLLR-401',3,'cerrado'),(71,'CLLR-402 EMISORA UDI RADIO',3,'cerrado'),(72,'CLLR-403',3,'cerrado'),(73,'CLLR-404',3,'cerrado'),(74,'CLLR-405',3,'cerrado'),(75,'CLLR-501',3,'cerrado'),(76,'CLLR-502',3,'cerrado'),(77,'CLLR-503',3,'cerrado'),(78,'CLLR-504',3,'cerrado'),(79,'CLLR-LAB MATERIALES Y MADERAS PISO 1',3,'cerrado'),(80,'CLLR-LAB DE AGUAS SOTANO',3,'cerrado'),(81,'CLLR-LAB DE AUTOMATIZACION Y CONTROL',3,'cerrado'),(82,'CLLR-TALLER ROBOTICA SOTANO',3,'cerrado'),(83,'DB-1001',4,'cerrado'),(84,'DB-1002',4,'cerrado'),(85,'DB-1003',4,'cerrado'),(86,'DB-1004',4,'cerrado'),(87,'DB-1005',4,'cerrado'),(88,'DB-1006',4,'cerrado'),(89,'DB-1007',4,'cerrado'),(90,'DB-1101',4,'cerrado'),(91,'DB-1102',4,'cerrado'),(92,'DB-1103',4,'cerrado'),(93,'DB-1104',4,'cerrado'),(94,'DB-1105',4,'cerrado'),(95,'DB-1106',4,'cerrado'),(96,'DB-1107',4,'cerrado'),(97,'DB-1201',4,'cerrado'),(98,'DB-1202',4,'cerrado'),(99,'DB-1203',4,'cerrado'),(100,'DB-1204',4,'cerrado'),(101,'DB-1205',4,'cerrado'),(102,'DB-1206',4,'cerrado'),(103,'DB-1207',4,'cerrado'),(104,'DB-1301',4,'cerrado'),(105,'DB-1302',4,'cerrado'),(106,'DB-1303',4,'cerrado'),(107,'DB-1304',4,'cerrado'),(108,'DB-1305',4,'cerrado'),(109,'DB-1306',4,'cerrado'),(110,'DB-1307',4,'cerrado'),(111,'DB-501',4,'cerrado'),(112,'DB-502',4,'cerrado'),(113,'DB-503',4,'cerrado'),(114,'DB-504',4,'cerrado'),(115,'DB-505',4,'cerrado'),(116,'DB-506',4,'cerrado'),(117,'DB-507',4,'cerrado'),(118,'DB-601',4,'cerrado'),(119,'DB-602',4,'cerrado'),(120,'DB-603',4,'cerrado'),(121,'DB-604',4,'cerrado'),(122,'DB-605',4,'cerrado'),(123,'DB-606',4,'cerrado'),(124,'DB-607',4,'cerrado'),(125,'DB-701',4,'cerrado'),(126,'DB-702',4,'cerrado'),(127,'DB-703',4,'cerrado'),(128,'DB-704',4,'cerrado'),(129,'DB-705',4,'cerrado'),(130,'DB-706',4,'cerrado'),(131,'DB-707',4,'cerrado'),(132,'DB-801',4,'cerrado'),(133,'DB-802',4,'cerrado'),(134,'DB-803',4,'cerrado'),(135,'DB-804',4,'cerrado'),(136,'DB-805',4,'cerrado'),(137,'DB-806',4,'cerrado'),(138,'DB-807',4,'cerrado'),(139,'DB-COLISEO',4,'cerrado'),(140,'DB-AUDITORIO',4,'cerrado'),(225,'EF-102',5,'cerrado'),(226,'EF-201',5,'cerrado'),(227,'EF-202',5,'cerrado'),(228,'EF-301',5,'cerrado'),(229,'EF-302',5,'cerrado'),(230,'EF-401',5,'cerrado'),(231,'EF-402',5,'cerrado'),(232,'EF-LAB DE CRIMINALISTICA',5,'cerrado'),(233,'EF-SALA CULTURAL',5,'cerrado'),(234,'EF-TALLER DE DISEÑO 1',5,'cerrado'),(235,'EF-TALLER DE DISEÑO 2',5,'cerrado'),(236,'EF-TALLER DE DISEÑO 3',5,'cerrado'),(237,'EF-TALLER DE DISEÑO 4',5,'cerrado'),(238,'SB-201',6,'cerrado'),(239,'SB-202',6,'cerrado'),(240,'SB-203',6,'cerrado'),(241,'SB-204',6,'cerrado'),(242,'SB-205',6,'cerrado'),(243,'SB-206',6,'cerrado'),(244,'SB-301',6,'cerrado'),(245,'SB-302',6,'cerrado'),(246,'SB-303',6,'cerrado'),(247,'SB-304',6,'cerrado'),(248,'SB-305',6,'cerrado'),(249,'SB-401 CAMARA GESELL',6,'cerrado'),(250,'SB-601',6,'cerrado'),(251,'SB-LAB DE MAQUINAS ELECTRICAS',6,'cerrado'),(252,'SB-LAB ELECTRONICA 1',6,'cerrado'),(253,'SB-LAB ELECTRONICA 2',6,'cerrado'),(254,'DC-LAB EDICION DE VIDEO',7,'cerrado'),(255,'DC-ESTUDIO FOTOGRAFICO',7,'cerrado'),(256,'DC-LAB DE FOTOGRAFIA Y REVELADO',7,'cerrado'),(257,'DC-LAB DE IDIOMAS',7,'cerrado'),(258,'DC-TALLER DE IMPRESION',7,'cerrado');
/*!40000 ALTER TABLE `aulas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diario_aulas`
--

DROP TABLE IF EXISTS `diario_aulas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `diario_aulas` (
  `iddiario_aulas` int NOT NULL AUTO_INCREMENT,
  `docente` varchar(128) NOT NULL,
  `fecha` date NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fin` time NOT NULL,
  `aula` varchar(128) NOT NULL,
  `asignatura` varchar(128) NOT NULL,
  `estado` varchar(45) NOT NULL,
  `aula_id` int DEFAULT NULL,
  PRIMARY KEY (`iddiario_aulas`),
  KEY `fk_aula` (`aula_id`),
  CONSTRAINT `fk_aula` FOREIGN KEY (`aula_id`) REFERENCES `aulas` (`idaulas`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diario_aulas`
--

LOCK TABLES `diario_aulas` WRITE;
/*!40000 ALTER TABLE `diario_aulas` DISABLE KEYS */;
INSERT INTO `diario_aulas` VALUES (1,'LUIS FERNANDO TELLEZ JEREZ','2025-11-27','06:00:00','07:30:00','SALA DE INFORMATICA 201','ELECTIVA II (Técnias de Creatividad Publicitaria ) ','Por abrir',16),(2,'NUBIA MARITZA PALOMINO MENDEZ','2025-11-27','06:00:00','07:30:00','SALA DE INFORMATICA 601','TALLER DE REDACCION','Por abrir',19),(3,'ERIKA XIMENA SARMIENTO CANO','2025-11-27','06:00:00','07:30:00','SALA DE INFORMATICA 17','CONTABILIDAD DE COSTOS','Por abrir',13),(4,'JOHN WILLIAM RUIZ ZAPATA','2025-11-27','06:00:00','07:30:00','SALA DE INFORMATICA 1','PROGRAMACION III','Por abrir',1),(5,'JONATHAN ARLEY MONSALVE SALAZAR','2025-11-27','06:00:00','07:30:00','SALA DE INFORMATICA 2','INGENIERIA DEL SOFTWARE II','Por abrir',2),(6,'FABIAN ANDRES NUÑEZ PINZON','2025-11-27','06:00:00','07:30:00','SALA DE INFORMATICA 404','INGENIERIA DEL SOFTWARE I','Por abrir',17),(7,'JORGE GIOVANNY CASTELLANOS VALDERRAMA','2025-11-27','06:00:00','07:30:00','SALA DE INFORMATICA 5','ELECTIVA PROFESIONAL IV (Derecho Informático ) ','Por abrir',5),(8,'JESSICA MORENO REALPE','2025-11-27','06:00:00','07:30:00','SALA DE INFORMATICA 9','ELECTIVA II (Arquitectura de la Información) ','Por abrir',9),(9,'JOHN ENRIQUE BRETON ESCOBAR','2025-11-27','06:00:00','07:30:00','SALA DE INFORMATICA MAC JLB','ELECTIVA II (Postproducción II ) ','Por abrir',20),(10,'KEVIN JAIR CASTELLANOS GONZALEZ','2025-11-27','06:00:00','07:30:00','SALA DE INFORMATICA 10','ELECTIVA PROFESIONAL IV (Seguridad en Redes) ','Por abrir',10),(11,'JAIRO EDUARDO VARGAS ALVAREZ','2025-11-27','06:00:00','07:30:00','SALA DE INFORMATICA 3','GESTION DE REDES SOCIALES','Por abrir',3),(12,'CRISOSTOMO ALBERTO BARAJAS SOLANO','2025-11-27','06:00:00','07:30:00','SALA DE INFORMATICA 4','ELECTIVA PROFESIONAL VI (Inteligencia Artificial ) ','Por abrir',4),(13,'SERGIO RICARDO LEON QUIJANO','2025-11-27','06:00:00','07:30:00','SALA DE INFORMATICA 7','REALIZACION AUDIOVISUAL','Por abrir',7),(14,'DANIEL ALFONSO RICO TAVERA','2025-11-27','08:00:00','09:30:00','SALA DE INFORMATICA 201','AUTOEDICION III','Por abrir',16),(15,'HENRY FERNANDEZ PINTO','2025-11-27','08:00:00','09:30:00','SALA DE INFORMATICA 601','SIMULACION DE NEGOCIOS INTERNACIONALES','Por abrir',19),(16,'LUIS GABRIEL URUETA ALVAREZ','2025-11-27','08:00:00','09:30:00','SALA DE INFORMATICA 505','TALLER DE ORIENTACION GRAFICA','Por abrir',18),(17,'CRISOSTOMO ALBERTO BARAJAS SOLANO','2025-11-27','08:00:00','09:30:00','SALA DE INFORMATICA 1','ELECTIVA PROFESIONAL I (Diseño Web y Usabilidad ) ','Por abrir',1),(18,'DUVAN RAMIREZ MOLINA','2025-11-27','08:00:00','09:30:00','SALA DE INFORMATICA 2','LOGICA COMPUTACIONAL','Por abrir',2),(19,'ALEXANDRA SORAYA BELTRAN CASTRO','2025-11-27','08:00:00','09:30:00','SALA DE INFORMATICA 404','BASE DE DATOS II','Por abrir',17),(20,'JORGE GIOVANNY CASTELLANOS VALDERRAMA','2025-11-27','08:00:00','09:30:00','SALA DE INFORMATICA 5','BASE DE DATOS II','Por abrir',5),(21,'JONNATHAN ALFREDO RAMOS CHAUX','2025-11-27','08:00:00','09:30:00','SALA DE INFORMATICA 9','ANALISIS NUMERICO','Por abrir',9),(22,'JOHN ENRIQUE BRETON ESCOBAR','2025-11-27','08:00:00','09:30:00','SALA DE INFORMATICA MAC JLB','RETOQUE DIGITAL','Por abrir',20),(23,'EDGARDO JAVIER RUA RANGEL ','2025-11-27','08:00:00','09:30:00','SALA DE INFORMATICA 10','TELEMATICA II','Por abrir',10),(24,'ABSALÓN  RINCÓN MUÑOZ','2025-11-27','08:00:00','09:30:00','SALA DE INFORMATICA 3','TALLER DE MODELADO 3D','Por abrir',3),(25,'RICARDO VICENTE JAIME VIVAS','2025-11-27','08:00:00','09:30:00','SALA DE INFORMATICA 4','MODELAMIENTO Y SIMULACION','Por abrir',4),(26,'WILSON DARIO ALFONSO ALVARADO','2025-11-27','08:00:00','09:30:00','SALA DE INFORMATICA 6','REDES I','Por abrir',6),(27,'MARCOS YAMID RUBIANO AVELLANEDA','2025-11-27','08:00:00','09:30:00','SALA DE INFORMATICA 7','INTRODUCCION AL DISEÑO WEB','Por abrir',7),(28,'DANIEL ALFONSO RICO TAVERA','2025-11-27','09:45:00','11:15:00','SALA DE INFORMATICA 201','AUTOEDICION III','Por abrir',16),(29,'LUIS GABRIEL URUETA ALVAREZ','2025-11-27','09:45:00','11:15:00','SALA DE INFORMATICA 505','TALLER DE ORIENTACION GRAFICA','Por abrir',18),(30,'RAFAEL RICARDO MANTILLA GUIZA','2025-11-27','09:45:00','11:15:00','SALA DE INFORMATICA 1','FUNDAMENTOS DE PROGRAMACION','Por abrir',1),(31,'ANDRES FELIPE JEREZ ARIZA ','2025-11-27','09:45:00','11:15:00','SALA DE INFORMATICA 2','ESTRUCTURA DE DATOS','Por abrir',2),(32,'ALEXANDRA SORAYA BELTRAN CASTRO','2025-11-27','09:45:00','11:15:00','SALA DE INFORMATICA 404','BASE DE DATOS II','Por abrir',17),(33,'JORGE GIOVANNY CASTELLANOS VALDERRAMA','2025-11-27','09:45:00','11:15:00','SALA DE INFORMATICA 5','BASE DE DATOS II','Por abrir',5),(34,'DUVAN RAMIREZ MOLINA','2025-11-27','09:45:00','11:15:00','SALA DE INFORMATICA 9','PROGRAMACION I','Por abrir',9),(35,'CRISOSTOMO ALBERTO BARAJAS SOLANO','2025-11-27','09:45:00','11:15:00','SALA DE INFORMATICA 12','SISTEMAS DE INFORMACION I','Por abrir',11),(36,'JOHN ENRIQUE BRETON ESCOBAR','2025-11-27','09:45:00','11:15:00','SALA DE INFORMATICA MAC JLB','RETOQUE DIGITAL','Por abrir',20),(37,'EDGARDO JAVIER RUA RANGEL ','2025-11-27','09:45:00','11:15:00','SALA DE INFORMATICA 10','TELEMATICA II','Por abrir',10),(38,'ABSALÓN  RINCÓN MUÑOZ','2025-11-27','09:45:00','11:15:00','SALA DE INFORMATICA 3','TALLER DE MODELADO 3D','Por abrir',3),(39,'RICARDO VICENTE JAIME VIVAS','2025-11-27','09:45:00','11:15:00','SALA DE INFORMATICA 4','TEORIA GENERAL DE SISTEMAS','Por abrir',4),(40,'WILSON DARIO ALFONSO ALVARADO','2025-11-27','09:45:00','11:15:00','SALA DE INFORMATICA 6','SEMINARIO DE TELEMATICA','Por abrir',6),(41,'MARCOS YAMID RUBIANO AVELLANEDA','2025-11-27','09:45:00','11:15:00','SALA DE INFORMATICA 7','INTRODUCCION AL DISEÑO WEB','Por abrir',7),(42,'FABIAN ANDRES NUÑEZ PINZON','2025-11-27','09:45:00','11:15:00','SALA DE INFORMATICA 8','SISTEMAS DE INFORMACION II','Por abrir',8),(43,'JAIRO EDUARDO VARGAS ALVAREZ','2025-11-27','14:00:00','15:30:00','SALA DE INFORMATICA MAC DC','SEMINARIO NUEVAS FORMAS DE CREACION','Por abrir',21),(44,'DIEGO ALEJANDRO FORERO CARRILLO','2025-11-27','14:00:00','15:30:00','SALA DE INFORMATICA 201','INTRODUCCION A LA PRODUCCION AUDIOVISUAL','Por abrir',16),(45,'NICOLAS ZABALA FERREIRA','2025-11-27','14:00:00','15:30:00','SALA DE INFORMATICA 505','INTRODUCCION AL DISEÑO MULTIMEDIAL','Por abrir',18),(46,'RUBEN DARIO CORONADO NIÑO','2025-11-27','14:00:00','15:30:00','SALA DE INFORMATICA 17','CULTURA DIGITAL','Por abrir',13),(47,'FABIAN ANDRES NUÑEZ PINZON','2025-11-27','14:00:00','15:30:00','SALA DE INFORMATICA 1','FUNDAMENTOS DE PROGRAMACION','Por abrir',1),(48,'FRANKIN EDUARDO LOPEZ FLOREZ','2025-11-27','14:00:00','15:30:00','SALA DE INFORMATICA 5','ANALISIS Y METRICAS ONLINE','Por abrir',5),(49,'LUIS FERNANDO TELLEZ JEREZ','2025-11-27','14:00:00','15:30:00','SALA DE INFORMATICA 10','MARKETING EN LA ERA DIGITAL','Por abrir',10),(50,'WILLIAM GREGORY QUINTANA MOGOLLON','2025-11-27','14:00:00','15:30:00','SALA DE INFORMATICA 3','BRANDING','Por abrir',3),(51,'JAIME ALBERTO JIMENEZ GUZMAN','2025-11-27','14:00:00','15:30:00','SALA DE INFORMATICA 7','TALLER DISEÑO PUBLICITARIO','Por abrir',7),(52,'JAIRO EDUARDO VARGAS ALVAREZ','2025-11-27','15:45:00','17:15:00','SALA DE INFORMATICA MAC DC','SEMINARIO NUEVAS FORMAS DE CREACION','Por abrir',21),(53,'DIEGO ALEJANDRO FORERO CARRILLO','2025-11-27','15:45:00','17:15:00','SALA DE INFORMATICA 201','INTRODUCCION A LA PRODUCCION AUDIOVISUAL','Por abrir',16),(54,'SANTIAGO BETANCUR ZAPATA','2025-11-27','15:45:00','17:15:00','SALA DE INFORMATICA 601','NARRATIVAS DIGITALES','Por abrir',19),(55,'NICOLAS ZABALA FERREIRA','2025-11-27','15:45:00','17:15:00','SALA DE INFORMATICA 505','INTRODUCCION AL DISEÑO MULTIMEDIAL','Por abrir',18),(56,'RUBEN DARIO CORONADO NIÑO','2025-11-27','15:45:00','17:15:00','SALA DE INFORMATICA 17','CULTURA DIGITAL','Por abrir',13),(57,'FABIAN ANDRES NUÑEZ PINZON','2025-11-27','15:45:00','17:15:00','SALA DE INFORMATICA 1','FUNDAMENTOS DE PROGRAMACION','Por abrir',1),(58,'LUISA FERNANDA SUAREZ BARRERA','2025-11-27','15:45:00','17:15:00','SALA DE INFORMATICA 2','NARRATIVA AUDIOVISUAL','Por abrir',2),(59,'FRANKIN EDUARDO LOPEZ FLOREZ','2025-11-27','15:45:00','17:15:00','SALA DE INFORMATICA 5','ANALISIS Y METRICAS ONLINE','Por abrir',5),(60,'LUIS FERNANDO TELLEZ JEREZ','2025-11-27','15:45:00','17:15:00','SALA DE INFORMATICA 10','MARKETING EN LA ERA DIGITAL','Por abrir',10),(61,'WILLIAM GREGORY QUINTANA MOGOLLON','2025-11-27','15:45:00','17:15:00','SALA DE INFORMATICA 3','BRANDING','Por abrir',3),(62,'JAIME ALBERTO JIMENEZ GUZMAN','2025-11-27','15:45:00','17:15:00','SALA DE INFORMATICA 7','TALLER DISEÑO PUBLICITARIO','Por abrir',7),(63,'YENY VICTORIA ARDILA ARDILA','2025-11-27','18:30:00','20:00:00','SALA DE INFORMATICA 201','SISTEMAS DE INFORMACION GEOGRAFICA','Por abrir',16),(64,'RAFAEL RICARDO MANTILLA GUIZA','2025-11-27','18:30:00','20:00:00','SALA DE INFORMATICA 1','FUNDAMENTOS DE PROGRAMACION','Por abrir',1),(65,'JEYSSON CAMILO PINZON CASTILLO','2025-11-27','18:30:00','20:00:00','SALA DE INFORMATICA 2','SOLUCIONES COMPUTACIONALES A PROBLEMAS DE INGENIERIA','Por abrir',2),(66,'ALEXANDRA SORAYA BELTRAN CASTRO','2025-11-27','18:30:00','20:00:00','SALA DE INFORMATICA 404','BASE DE DATOS II','Por abrir',17),(67,'LAERTE ALBERTO FERREIRA CASTRO','2025-11-27','18:30:00','20:00:00','SALA DE INFORMATICA 5','FUNDAMENTOS DE PROGRAMACION','Por abrir',5),(68,'MARTIN  PEREZ JAIMES','2025-11-27','18:30:00','20:00:00','SALA DE INFORMATICA 10','REDES II','Por abrir',10),(69,'SONIA ISABEL POLO TRIANA','2025-11-27','18:30:00','20:00:00','SALA DE INFORMATICA 3','TALLER DE DISTRIBUCION DE PLANTA','Por abrir',3),(70,'EDGARDO JAVIER RUA RANGEL ','2025-11-27','18:30:00','20:00:00','SALA DE INFORMATICA 6','REDES I','Por abrir',6),(71,'RAFAEL RICARDO MANTILLA GUIZA','2025-11-27','20:10:00','21:40:00','SALA DE INFORMATICA 1','FUNDAMENTOS DE PROGRAMACION','Por abrir',1),(72,'JOHN WILLIAM RUIZ ZAPATA','2025-11-27','20:10:00','21:40:00','SALA DE INFORMATICA 2','PROGRAMACION I','Por abrir',2),(73,'ALEXANDRA SORAYA BELTRAN CASTRO','2025-11-27','20:10:00','21:40:00','SALA DE INFORMATICA 404','BASE DE DATOS II','Por abrir',17),(74,'LAERTE ALBERTO FERREIRA CASTRO','2025-11-27','20:10:00','21:40:00','SALA DE INFORMATICA 5','FUNDAMENTOS DE PROGRAMACION','Por abrir',5),(75,'MARTIN  PEREZ JAIMES','2025-11-27','20:10:00','21:40:00','SALA DE INFORMATICA 10','REDES II','Por abrir',10),(76,'SONIA ISABEL POLO TRIANA','2025-11-27','20:10:00','21:40:00','SALA DE INFORMATICA 3','TALLER DE DISTRIBUCION DE PLANTA','Por abrir',3);
/*!40000 ALTER TABLE `diario_aulas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edificios`
--

DROP TABLE IF EXISTS `edificios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `edificios` (
  `idedificios` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  PRIMARY KEY (`idedificios`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edificios`
--

LOCK TABLES `edificios` WRITE;
/*!40000 ALTER TABLE `edificios` DISABLE KEYS */;
INSERT INTO `edificios` VALUES (1,'Jorge Luis Borges'),(2,'Ernesto Sabato'),(3,'Carlos Lleras Restrepo'),(4,'Daniel Bernoulli'),(5,'Enrico Fermi'),(6,'Simon Bolivar'),(7,'David Consuegra');
/*!40000 ALTER TABLE `edificios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prestamos`
--

DROP TABLE IF EXISTS `prestamos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prestamos` (
  `idprestamos` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `telefono` varchar(45) NOT NULL,
  `correo` varchar(128) NOT NULL,
  `tipo_recurso` varchar(45) NOT NULL,
  `recurso` varchar(128) NOT NULL,
  `edificio` varchar(45) NOT NULL,
  `aula` varchar(45) NOT NULL,
  `fecha_reserva` date NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fin` time NOT NULL,
  `descripcion` varchar(1024) NOT NULL,
  `estado` varchar(45) NOT NULL DEFAULT 'Pendiente',
  PRIMARY KEY (`idprestamos`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prestamos`
--

LOCK TABLES `prestamos` WRITE;
/*!40000 ALTER TABLE `prestamos` DISABLE KEYS */;
INSERT INTO `prestamos` VALUES (3,'Favian Niño','3022041857','frninoc@gmail.com','CÁMARA Y MICRÓFONOS','LOGITECH 1','Daniel Bernoulli','DB-807','2025-11-21','10:18:00','11:35:00','sisa','Devuelto');
/*!40000 ALTER TABLE `prestamos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recursos`
--

DROP TABLE IF EXISTS `recursos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recursos` (
  `idrecursos` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `inventario` int NOT NULL,
  `tipo` int NOT NULL,
  `status` varchar(45) NOT NULL,
  PRIMARY KEY (`idrecursos`),
  KEY `frk_tipo_recurso_idx` (`tipo`),
  CONSTRAINT `fk_tipo_recurso` FOREIGN KEY (`tipo`) REFERENCES `tipo_recurso` (`idtipo_recurso`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recursos`
--

LOCK TABLES `recursos` WRITE;
/*!40000 ALTER TABLE `recursos` DISABLE KEYS */;
INSERT INTO `recursos` VALUES (1,'LOGITECH 1','LOGITECH',77777777,1,'Activo'),(2,'HDMI 1','HDMI',1111111,2,'Activo'),(3,'HP 1P','Portátil',1234672,3,'Activo'),(10,'CABLE DE RED 1','CABLE DE RED UTP',125425444,5,'Activo');
/*!40000 ALTER TABLE `recursos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solicitudes_usuario`
--

DROP TABLE IF EXISTS `solicitudes_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `solicitudes_usuario` (
  `id_soli` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `correo` varchar(150) NOT NULL,
  `cedula` varchar(50) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `rol` varchar(50) NOT NULL,
  `password` varchar(1024) NOT NULL,
  PRIMARY KEY (`id_soli`),
  UNIQUE KEY `id` (`id_soli`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solicitudes_usuario`
--

LOCK TABLES `solicitudes_usuario` WRITE;
/*!40000 ALTER TABLE `solicitudes_usuario` DISABLE KEYS */;
INSERT INTO `solicitudes_usuario` VALUES (7,'Ismael','ismael@gmail.com','125425644','233114555','Auxiliar','isma123');
/*!40000 ALTER TABLE `solicitudes_usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_recurso`
--

DROP TABLE IF EXISTS `tipo_recurso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo_recurso` (
  `idtipo_recurso` int NOT NULL AUTO_INCREMENT,
  `tipo_recurso` varchar(255) NOT NULL,
  `status` varchar(45) NOT NULL,
  PRIMARY KEY (`idtipo_recurso`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_recurso`
--

LOCK TABLES `tipo_recurso` WRITE;
/*!40000 ALTER TABLE `tipo_recurso` DISABLE KEYS */;
INSERT INTO `tipo_recurso` VALUES (1,'CÁMARA Y MICRÓFONOS','Activo'),(2,'CABLE HDMI','Activo'),(3,'PORTÁTIL','Activo'),(4,'VIDEOBEAM','Activo'),(5,'CABLE DE RED','Activo'),(6,'SALA DE INFORMÁTICA','Activo');
/*!40000 ALTER TABLE `tipo_recurso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `idusuario` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `correo` varchar(150) NOT NULL,
  `cedula` varchar(50) NOT NULL,
  `celular` varchar(20) NOT NULL,
  `rol` varchar(50) NOT NULL,
  `password` varchar(1024) NOT NULL,
  `status` varchar(45) DEFAULT NULL,
  `codigo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`idusuario`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Daniel Vesga','frninoc@gmail.com','12345','112331312','Administrador','scrypt:32768:8:1$D8fYBrZ8vWrfnaFK$71266c0feb96b1fa153465cb526626e6493c1f3b4839df035dec5272b7bfc97a286b3e04f8a9caae58b7c9bf8620bfb01e10fd5627d36581330ec35d07a8741a','Activo',''),(2,'Andres Blanco M','andresilloblanco29@gmail.com','123456','31234345','Auxiliar','scrypt:32768:8:1$ymv0YEwq0EJEY9RU$c406035d64bc76707d56e4db76e60a01dfb3b2cd8e8586292d50954a87789c838b37be7eaa73b30999450c2a577cb6dec46d45429aa851a0854f12de7d7c36bf','Activo',NULL),(3,'Andrés Felipe Blanco Méndez','auxandres@gmail.com','1098643940','3247132692','Auxiliar','scrypt:32768:8:1$BY3E6yM6Y3T0yi1u$04fd5a94fcf34ab17cbad4a41d9c1a85d92df1f8f04d8851cf20fd51de4196a548e730ad56924dba3c734bb9095de7b81b1b3a3b181ded7ce72679e40b537e7a','Inactivo',NULL),(4,'Daniel González Roa','auxdaniel@gmail.com','1099735512','3022041857','Auxiliar','scrypt:32768:8:1$yqVse5dnEVJEtP3Q$a9b16c4e7e0803b4f3acb84f3e23394de9dd18715f36b7034e7b8889a0b3e4e084a63bb72dbb253e4eb3a39113e18123b3d3044fc8dff880ed9a9c4c2c4a594a','Inactivo',NULL),(5,'Favián Ricardo Niño Carvajal','auxfavian@gmail.com','91500343','3184079947','Auxiliar','favian123','Activo',NULL),(6,'Germán Andrés Bautista Blanco','gbautista3@udi.edu.co','1098675052','3207502508','Docente','scrypt:32768:8:1$kSa7SJiGvVFXrfqO$84a05a69f234e5b81850df8e3a65a73a44c8bfc45eaf38f0d25a043f795891dbdcbf9f96bb56ff6d25856f3360fcaa75b95f0062a052de4b052788c4b4b7b5e0','Activo',NULL),(7,'Giuliana Espinosa Barajas','gespinosa1@udi.edu.co','1098751476','3052548551','Docente','scrypt:32768:8:1$PfTtCmhVfKtEDN6C$0d635986a2731c9b2c8da05d5f3b5fd99425dcf6cf14206b6e3ed4b97d7fcd84de8c83d56023389cf9f8029436eb222ff29c18cb35dfe37cfa7a3af00e8d9c3b','Activo',NULL),(8,'victor julio alvarez','vjalv@udi.edu.co','1090000006','3012223344','Auxiliar','scrypt:32768:8:1$Kq0QKZTJZT0eF1iA$ef21f45bb04e8bcbf3e4472630b9da7fefde407fa268def52b90db0cbb8399e82d0f5baf3f2d5ce8d62ef91cb3de3b54ccbbd2e4c4af8b442c8c51a78b746fc4','Activo',NULL),(27,'Guillermo Archila','ad@edu.co','123456789','3185204758','Auxiliar','scrypt:32768:8:1$PDpzcvFK9E57w6nl$510907700b1ec95c0de16b47a79bb3b5a6d936e458facf05fa2292e10661cf2f3389d0aebd18d6b68e4cad709356cceccb1879c1f4430ce9114863db394ca412','Activo',NULL),(28,'DANIEL ROA','daniel@udi.edu.co','12345678','19813901091','Administrador','scrypt:32768:8:1$KCe3yqL6Egnxex7R$e37820de48fdae6cd3fa84d5e4ea51f88462273f7167479bb06871e238a6a5884e66e1565868ace57702a53ecabafd663cf0ec396989d03ca24fc2dc7619682d','Activo',NULL),(29,'Juan David Blanco Mendez','juanblanco@gmail.com','1025875698','3255421555','Auxiliar','scrypt:32768:8:1$XDSDW6zDToRAIlGE$57c90b5bdb46e9485ac74e3ca420cbe6497fb98219c789d8e0861e19631d998ded1a67f81815993ffcc8820f3165fd5c4c35db76f77e32ddd2e11f4dade668d8','Activo',NULL),(30,'Daniel Fernando Gonzalez','danielF@udi.edu.co','12345678','1234567891','Docente','scrypt:32768:8:1$OwqnYktI2nrFMIls$787f9f961f853b69bec84d75e439edc09379c0bb423c8659838d8418da345dded38a85a102e9d35041a93902c08a29a5c03cad6f9ce019480a9682b35e58cf39','Inactivo',NULL),(31,'Isma','isma@gmail.com','5454465465','322545545','Docente','scrypt:32768:8:1$ePAelky9hyBad0Wp$94f70cb6257f93c766e204f5a82a025bf5b50d4df4207613c9b3703b9dff9cbebfe8036c759b9d40103535f2110027afef339344904448937ffa59c0042a2c2b','Activo',NULL),(32,'Guillermo Archila','favianricardo@gmail.com','1234','3185204758','Administrador','scrypt:32768:8:1$C8Fd95RX4tboLXdY$e09be5d110556aac3bf8d758e0da1b8be99470dd2891574f07c0902c49e4d426c12fc85a8b3b47de9caa2c17943138782b4ee5782d2eebd9592bfa0b7d9a122d','Activo',NULL),(33,'asdasd','asda@gmail.com','34324234','23423423','Auxiliar','scrypt:32768:8:1$oY04gTth0G8opFvF$4d51df9def4062d722ddf1c8b95bced77220ab7a76dcdaae65d7b2d588141d950f922a20978a06d55413b5b2d945846b11c7ae842a05531ae002fe2448838f1b','Activo',NULL);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-27 14:35:25
