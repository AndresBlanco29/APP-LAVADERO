document.addEventListener("DOMContentLoaded", () => {
    cargarAulas();
});

const botonVerDispositivos = document.getElementById("btn-ver-dispositivos");
if (botonVerDispositivos) {
    botonVerDispositivos.addEventListener("click", function() {
        window.location.href = '/Diario'; // Ajusta la ruta según tu proyecto
    });
}

const btnvolver = document.getElementById("btn-volver");
if (btnvolver) {
    btnvolver.addEventListener("click", () => window.location.href = '/Calendario');
}

/* --- Modal de detalles --- */
const overlayDetalle = document.getElementById("overlay-detalle");
const btnCerrarDetalle = document.getElementById("cerrar-detalle");

if (btnCerrarDetalle) btnCerrarDetalle.addEventListener("click", () => overlayDetalle.style.display = "none");
if (overlayDetalle) overlayDetalle.addEventListener("click", (e) => {
    if (e.target === overlayDetalle) overlayDetalle.style.display = "none";
});

/* --- Abrir modal con datos --- */
function abrirDetallesConDatos(datos) {
    if (!datos) return;

    document.getElementById("modal-docente").textContent = datos.docente || "-";
    document.getElementById("modal-aula").textContent = datos.aula || "-";
    document.getElementById("modal-asignatura").textContent = datos.asignatura || "-";
    document.getElementById("modal-inicio").textContent = datos.inicio || "-";
    document.getElementById("modal-fin").textContent = datos.fin || "-";

    overlayDetalle.style.display = "flex";
}

function texto(td) {
    return td ? td.textContent.trim() : "";
}

document.addEventListener("click", function (e) {
    const btn = e.target.closest(".Btn-Detalles");
    if (!btn) return;

    const tr = btn.closest("tr");
    if (!tr) return;

    const tds = tr.querySelectorAll("td");

    const datos = {
        docente: texto(tds[0]),
        inicio: texto(tds[1]),
        fin: texto(tds[2]),
        aula: texto(tds[3]),
        asignatura: texto(tds[4]),
        descripcion: tds[6] ? tds[6].textContent.trim() : "-",
    };

    abrirDetallesConDatos(datos);
});



// =================================================================
// ===== CARGAR AULAS DINÁMICAMENTE =====
// =================================================================

async function cargarAulas() {
    const tbody = document.getElementById("tabla-aulas-body");
    tbody.innerHTML = '';

    try {
        const res = await fetch("/api/aulas_reservas");
        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
        const aulas = await res.json();

        aulas.forEach(a => {
            const tr = document.createElement("tr");
            tr.dataset.id = a.id || '';

            tr.innerHTML = `
                <td>${a.docente || '-'}</td>
                <td>${a.inicio || '-'}</td>
                <td>${a.fin || '-'}</td>
                <td>${a.aula || '-'}</td>
                <td>${a.asignatura || '-'}</td>
            `;

            tbody.appendChild(tr);
        });

    } catch (err) {
        console.error("Error cargando aulas:", err);
        tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; color:red;">${err.message || 'Error al conectar con la API.'}</td></tr>`;
    }
}

const btnSeleccionarFecha = document.querySelector(".calendario");
const modalFiltro = document.getElementById("modal-filtro-hora");
const btnAplicarFiltro = document.getElementById("btn-aplicar-filtro");
const btnCerrarFiltro = document.getElementById("btn-cerrar-filtro");

btnSeleccionarFecha.addEventListener("click", () => {
    modalFiltro.style.display = "flex";
});

btnCerrarFiltro.addEventListener("click", () => {
    modalFiltro.style.display = "none";
});

modalFiltro.addEventListener("click", (e) => {
    if (e.target === modalFiltro) modalFiltro.style.display = "none";
});

// =============================================
// === FILTRAR POR HORA DE INICIO ==============
// =============================================

btnAplicarFiltro.addEventListener("click", () => {
    const horaSeleccionada = document.getElementById("horaFiltro").value; 

    if (!horaSeleccionada) {
        alert("Seleccione una hora");
        return;
    }

    const tbody = document.getElementById("tabla-aulas-body");
    const filas = [...tbody.querySelectorAll("tr")];

    filas.forEach(fila => {
        const horaInicio = fila.children[1].textContent.trim(); // columna "Inicio"

        // Convertimos "06:00 AM" → "06:00"
        const horaNormalizada = normalizarHora(horaInicio);

        if (horaNormalizada === horaSeleccionada) {
            fila.style.display = "";
        } else {
            fila.style.display = "none";
        }
    });

    modalFiltro.style.display = "none";
});

function normalizarHora(hora) {
    // Si la hora viene en formato "06:00", se queda igual.
    // Si viene en formato "6:00 AM" → se convierte a 24h "06:00".

    if (!hora) return "";

    // Ya viene en formato 24h → lo retornamos
    if (/^\d{2}:\d{2}$/.test(hora)) {
        return hora;
    }

    // Formato 12h → convertimos
    const partes = hora.match(/(\d{1,2}):(\d{2})\s?(AM|PM)/i);
    if (!partes) return hora;

    let h = parseInt(partes[1]);
    let m = partes[2];
    let ampm = partes[3].toUpperCase();

    if (ampm === "PM" && h !== 12) h += 12;
    if (ampm === "AM" && h === 12) h = 0;

    return `${String(h).padStart(2, "0")}:${m}`;
}


function cargarHorasClases() {
    const gruposHoras = {
        "Mañana": [
            ["06:00", "6:00 AM"],
            ["08:00", "8:00 AM"],
            ["09:45", "9:45 AM"]
        ],
        "Tarde": [
            ["14:00", "2:00 PM"],
            ["15:45", "3:45 PM"]
        ],
        "Noche": [
            ["18:30", "6:30 PM"],
            ["20:10", "8:10 PM"]
        ]
    };

    const select = document.getElementById("horaFiltro");
    select.innerHTML = "";

    Object.keys(gruposHoras).forEach(grupo => {
        const optgroup = document.createElement("optgroup");
        optgroup.label = grupo;

        gruposHoras[grupo].forEach(([value, texto]) => {
            const option = document.createElement("option");
            option.value = value;
            option.textContent = texto;
            optgroup.appendChild(option);
        });

        select.appendChild(optgroup);
    });
}

document.addEventListener("DOMContentLoaded", cargarHorasClases);



