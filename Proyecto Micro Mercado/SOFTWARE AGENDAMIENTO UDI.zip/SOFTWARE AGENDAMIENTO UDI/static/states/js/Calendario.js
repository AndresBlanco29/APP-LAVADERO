// 🔒 Ocultar contenido hasta que se verifique la sesión para evitar parpadeo
document.documentElement.style.visibility = "hidden";

// =================================================================
// ===== FUNCIONES DE GESTIÓN DE DATOS =====
// =================================================================

function marcarEventosEnCalendario(calendar, resumen) {
    console.log("📆 Resumen recibido para marcar en calendario:", resumen);

    if (!resumen || resumen.length === 0) return;

    resumen.forEach(item => {
        if (!item.fecha) return;

        calendar.addEvent({
            title: `Evento: ${item.cantidad ?? 0}`,
            start: item.fecha,
            allDay: true,
            color: '#FFC107'
        });
    });
}

// =================================================================
// ===== LÓGICA PRINCIPAL =====
document.addEventListener("DOMContentLoaded", async function () {

    const usuario = localStorage.getItem("usuario");
    const rol = localStorage.getItem("rol");

    if (!usuario || !rol) {
        window.location.replace("/");
        return;
    }

    document.documentElement.style.visibility = "visible";

    const etiquetaUsuario = document.querySelector(".username");
    if (etiquetaUsuario) etiquetaUsuario.textContent = usuario;

    const calendarEl = document.getElementById("calendar");
    const modal = document.getElementById("formReserva");
    const userRol = rol.toLowerCase();

    // ===== SUBIDA DE EXCEL =====
    async function subirExcelHandler() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.xlsx, .xls';

        input.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file) return;

            // Mostrar modal de fecha
            const modal = document.getElementById('modalFechaExcel');
            const fechaInput = document.getElementById('fechaExcel');
            const semanaSelect = document.getElementById('semanaExcel'); // <-- nuevo select de semana

            modal.style.display = 'flex';

            return new Promise((resolve) => {
                document.getElementById('btnCancelarFecha').onclick = () => {
                    modal.style.display = 'none';
                    resolve();
                };
                document.getElementById('btnConfirmarFecha').onclick = async () => {
                    const fechaSeleccionada = fechaInput.value;
                    const semanaSeleccionada = semanaSelect.value; // <-- obtenemos semana

                    if (!fechaSeleccionada) { 
                        alert("Seleccione una fecha"); 
                        return; 
                    }

                    modal.style.display = 'none';

                    const formData = new FormData();
                    formData.append('horario_excel', file);
                    formData.append('fecha', fechaSeleccionada); 
                    formData.append('semana', semanaSeleccionada); // <-- enviamos semana al backend

                    try {
                        const response = await fetch('/api/upload_horario_aulas', {
                            method: 'POST',
                            body: formData
                        });

                        const data = await response.json();
                        console.log("📦 Respuesta del servidor de Excel:", data);

                        if (data.error || !data.success) {
                            alert('❌ Error al procesar el archivo: ' + (data.error || 'Error desconocido.'));
                            return;
                        }

                        alert('✅ Archivo subido y procesado correctamente.');
                        calendar.refetchEvents();

                    } catch (error) {
                        alert('⚠️ Error al subir el archivo: ' + error);
                        console.error("Error en la subida:", error);
                    }
                };

            });
        };

        input.click();
    }


    // ===== BOTONES PERSONALIZADOS =====
    const customButtons = (userRol === "docente") ? {} : {
        myCustomButton: { text: "Subir Excel", click: subirExcelHandler },
        configButton: { text: "⚙️ Configurar calendario", click: function() {
            document.getElementById("calendar").style.display = "none";
            document.getElementById("configuracionCalendario").style.display = "block";
        }}
    };

    const leftToolbar = (userRol === "docente") ? "prev,next today" : "prev,next today myCustomButton configButton";

    // ===== CALENDARIO =====
    const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: "dayGridMonth",
        height: 872,
        locale: "es",
        headerToolbar: { left: leftToolbar, center: "title", right: "dayGridMonth,timeGridWeek,timeGridDay" },
        customButtons: customButtons,
        buttonText: { today: "Hoy", month: "Mes", week: "Semana", day: "Día" },
        dateClick: function(info) {
            const fechaSeleccionada = new Date(info.dateStr + "T00:00:00");
            const hoy = new Date(); hoy.setHours(0,0,0,0);
            if (fechaSeleccionada < hoy) return alert("⚠️ No puedes seleccionar una fecha pasada.");
            abrirFormularioReserva(info.dateStr);
        },

        events: async function(fetchInfo, successCallback, failureCallback) {
            try {
                const response = await fetch('/api/eventos_calendario'); 
                const data = await response.json();

                // Bloques horarios definidos (puedes ajustar)
                const bloques = [
                    { nombre: '6:00 AM', inicio: '06:00:00', fin: '07:30:00' },
                    { nombre: '8:00 AM', inicio: '08:00:00', fin: '09:30:00' },
                    { nombre: '9:45 AM', inicio: '09:45:00', fin: '11:15:00' },
                    { nombre: '2:00 PM', inicio: '14:00:00', fin: '15:30:00' },
                    { nombre: '3:45 PM', inicio: '15:45:00', fin: '17:15:00' },
                    { nombre: '6:30 PM', inicio: '18:30:00', fin: '20:00:00' },
                    { nombre: '8:10 PM', inicio: '20:10:00', fin: '21:40:00' }
                ];

                // Separar clases y préstamos
                const clases = data.filter(ev => ev.tipo === 'clase');
                const prestamos = data.filter(ev => ev.tipo === 'prestamo');

                // Agrupar clases por fecha y bloque horario
                const clasesPorBloque = {};  // { fecha: { bloqueNombre: cantidad } }

                clases.forEach(ev => {
                    const fecha = ev.start.slice(0,10);  // 'YYYY-MM-DD'
                    const horaInicio = ev.start.slice(11,19); // 'HH:MM:SS'

                    if (!clasesPorBloque[fecha]) clasesPorBloque[fecha] = {};

                    // Buscar bloque horario donde cae la clase
                    const bloque = bloques.find(b => horaInicio >= b.inicio && horaInicio <= b.fin);
                    const bloqueNombre = bloque ? bloque.nombre : 'Otros';

                    clasesPorBloque[fecha][bloqueNombre] = (clasesPorBloque[fecha][bloqueNombre] || 0) + 1;
                });

                // Crear eventos resumen de clases agrupadas
                const eventosResumenClases = [];

                for (const fecha in clasesPorBloque) {
                    for (const bloqueNombre in clasesPorBloque[fecha]) {
                        const cantidad = clasesPorBloque[fecha][bloqueNombre];
                        eventosResumenClases.push({
                            id: `resumen-clases-${fecha.replace(/-/g,'')}-${bloqueNombre.replace(/[: ]/g,'')}`,
                            title: `${cantidad} clases a las ${bloqueNombre}`,
                            start: fecha,
                            allDay: true,
                            color: '#FFC107',
                            tipo: 'clase_resumen'
                        });
                    }
                }

                // Agrupar préstamos por fecha y estado (como antes)
                const prestamosPorFecha = {};
                prestamos.forEach(ev => {
                    const fecha = ev.start.slice(0,10);
                    if (!prestamosPorFecha[fecha]) {
                        prestamosPorFecha[fecha] = { pendiente: 0, 'en uso': 0, devuelto: 0 };
                    }
                    const estado = ev.estado || 'devuelto';
                    if (estado === 'pendiente') prestamosPorFecha[fecha].pendiente++;
                    else if (estado === 'en uso') prestamosPorFecha[fecha]['en uso']++;
                    else prestamosPorFecha[fecha].devuelto++;
                });

                const eventosResumenPrestamos = [];
                for (const fecha in prestamosPorFecha) {
                    const c = prestamosPorFecha[fecha];
                    let tituloPartes = [];
                    if (c.pendiente > 0) tituloPartes.push(`${c.pendiente} Préstamos pendientes`);
                    if (c['en uso'] > 0) tituloPartes.push(`${c['en uso']} Préstamos en uso`);
                    if (c.devuelto > 0) tituloPartes.push(`${c.devuelto} Préstamos devueltos`);

                    eventosResumenPrestamos.push({
                        id: 'resumen-prestamos-' + fecha.replace(/-/g, ''),
                        title: tituloPartes.join(' | '),
                        start: fecha,
                        allDay: true,
                        color: c.pendiente > 0 ? '#E67E22' : c['en uso'] > 0 ? '#2980B9' : c.devuelto > 0 ? '#27AE60' : '#7f8c8d',
                        tipo: 'prestamo_resumen'
                    });
                }

                // Combinar resúmenes de clases y préstamos para mostrar en el calendario
                const eventosFinales = [...eventosResumenClases, ...eventosResumenPrestamos];

                successCallback(eventosFinales);

            } catch (err) {
                console.error("Error al cargar eventos del calendario:", err);
                failureCallback(err);
            }
        }


    });

    calendar.render();

    // ===== MODALES =====
    window.cerrarSesion = function() {
        localStorage.clear();
        window.location.replace("/");
    }

    const btnVolverCalendario = document.getElementById("btnVolverCalendario");
    if (btnVolverCalendario) btnVolverCalendario.addEventListener("click", () => {
        document.getElementById("configuracionCalendario").style.display = "none";
        document.getElementById("calendar").style.display = "block";
        calendar.refetchEvents();
    });

    function abrirFormularioReserva(fecha) {
        const fechaInput = document.getElementById("fechaReserva");
        if (modal) {
            modal.style.display = "flex";
            if (fechaInput) fechaInput.value = fecha;
        }
    }

    function cerrarFormularioReserva() {
        if (!modal) return;
        modal.style.display = "none";
        document.getElementById("formularioReserva").reset();
        calendar.refetchEvents();
    }

    document.getElementById("cerrar-reserva").addEventListener("click", (e) => {
        e.preventDefault();
        cerrarFormularioReserva();
    });

    modal.addEventListener("click", (e) => {
        if (e.target === modal) cerrarFormularioReserva();
    });

    document.addEventListener("keydown", (e) => {
        if (e.key === "Escape" && modal.style.display === "flex") {
            cerrarFormularioReserva();
        }
    });

    // ===== CARGA DE SELECTS =====
    const tipoSelect = document.getElementById("tipoRecurso");
    const recursoSelect = document.getElementById("recurso");
    const edificioSelect = document.getElementById("selEdificio");
    const aulaSelect = document.getElementById("selAula");

    async function cargarTiposRecurso() {
        try {
            const res = await fetch("/api/tipos_recurso");
            const tipos = await res.json();
            tipoSelect.innerHTML = '<option value="">Seleccionar...</option>';
            tipos.forEach(t => tipoSelect.add(new Option(t.nombre, t.id)));
        } catch (err) { console.error("Error al cargar tipos de recurso:", err); }
    }

    tipoSelect.addEventListener("change", async () => {
        recursoSelect.innerHTML = '<option value="">Seleccionar...</option>';
        if (!tipoSelect.value) return;
        try {
            const res = await fetch(`/api/recursos_por_tipo/${tipoSelect.value}`);
            const recursos = await res.json();
            recursos.forEach(r => recursoSelect.add(new Option(r.nombre, r.nombre)));
        } catch (err) { console.error("Error al cargar recursos:", err); }
    });

    async function cargarEdificios() {
        try {
            const res = await fetch("/api/edificios");
            const edificios = await res.json();
            edificioSelect.innerHTML = '<option value="">Seleccionar...</option>';
            edificios.forEach(e => edificioSelect.add(new Option(e.nombre, e.id)));
        } catch (err) { console.error("Error al cargar edificios:", err); }
    }

    edificioSelect.addEventListener("change", async () => {
        aulaSelect.innerHTML = '<option value="">Seleccionar...</option>';
        if (!edificioSelect.value) return;
        try {
            const res = await fetch(`/api/aulas_por_edificio/${edificioSelect.value}`);
            const aulas = await res.json();
            aulas.forEach(a => aulaSelect.add(new Option(a.aula, a.aula)));
        } catch (err) { console.error("Error al cargar aulas:", err); }
    });

    await cargarTiposRecurso();
    await cargarEdificios();

    // ===== ENVÍO DE FORMULARIOS =====
    document.getElementById("formularioReserva").addEventListener("submit", async (e) => {
        e.preventDefault();
        const datos = {
            nombre: document.getElementById("usuario").value,
            telefono: document.getElementById("telefono").value,
            correo: document.getElementById("correo").value,
            tipo_recurso: tipoSelect.options[tipoSelect.selectedIndex].text,
            recurso: recursoSelect.value,
            edificio: edificioSelect.options[edificioSelect.selectedIndex].text,
            aula: aulaSelect.value,
            fecha_reserva: document.getElementById("fechaReserva").value,
            hora_inicio: document.getElementById("horaInicio").value,
            hora_fin: document.getElementById("horaFin").value,
            descripcion: document.getElementById("descripcion").value
        };
        try {
            const res = await fetch("/api/crear_prestamo", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(datos)
            });
            const data = await res.json();
            if (data.success) {
                alert("✅ Reserva guardada correctamente.");
                cerrarFormularioReserva();
            } else { alert("❌ Error: " + data.error); }
        } catch (err) { alert("⚠️ Error al enviar datos: " + err); }
    });

    

});
