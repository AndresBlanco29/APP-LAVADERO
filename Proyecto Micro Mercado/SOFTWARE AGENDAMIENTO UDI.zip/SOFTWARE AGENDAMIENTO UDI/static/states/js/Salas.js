document.addEventListener("DOMContentLoaded", () => {
  cargarSalas();
  // Actualizar cada minuto
  setInterval(() => {
    actualizarEstadosHorario().then(cargarSalas);
  }, 60000);
});

async function cargarSalas() {
  try {
    const res = await fetch("/api/salas_informatica");
    const salas = await res.json();

    const tbody = document.querySelector("tbody");
    tbody.innerHTML = "";

    salas.forEach(sala => {
      const fila = document.createElement("tr");

      fila.innerHTML = `
        <td>${sala.aula}</td>
        <td>${sala.edificio}</td>
        <td style="text-align:center;">
          <span class="estado ${mapEstadoClase(sala.status)}">
            ${formatearEstado(sala.status)}
          </span>
        </td>
        <td>
          <button class="btn-estado" data-id="${sala.id}">
            <i class="fa fa-refresh"></i> Cambiar estado
          </button>
        </td>
      `;
      tbody.appendChild(fila);
    });

    // Botones de cambio manual
    document.querySelectorAll(".btn-estado").forEach(btn => {
      btn.addEventListener("click", async () => {
        const id = btn.dataset.id;
        await cambiarEstadoSala(id);
      });
    });

  } catch (e) {
    console.error("Error cargando salas:", e);
  }
}

async function cambiarEstadoSala(id) {
  try {
    const fila = document.querySelector(`button[data-id='${id}']`).closest("tr");
    const estadoSpan = fila.querySelector(".estado");
    const estadoActual = estadoSpan.textContent.toLowerCase().replace(/ /g, "_");

    const estados = ["por_abrir", "abierto", "en_uso", "por_cerrar", "cerrado"];
    let indice = estados.indexOf(estadoActual);
    const nuevoEstado = estados[(indice + 1) % estados.length];

    const res = await fetch(`/api/salas/${id}/estado`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ estado: nuevoEstado })
    });

    if (!res.ok) throw new Error(`Error al cambiar estado: ${res.status}`);
    const data = await res.json();

    estadoSpan.className = "estado " + mapEstadoClase(data.estado);
    estadoSpan.textContent = formatearEstado(data.estado);

  } catch (e) {
    console.error(e);
    alert("No se pudo cambiar el estado");
  }
}

async function actualizarEstadosHorario() {
  try {
    await fetch("/api/actualizar_estados_horario", { method: "POST" });
  } catch (e) {
    console.error("Error al actualizar estados:", e);
  }
}

// Mapea el estado a la clase CSS según tu CSS
function mapEstadoClase(estado) {
  if (!estado) return "inactiva";

  const e = estado.toLowerCase().replace(/ /g, "_");

  switch (e) {
    case "por_abrir": return "por-abrir";
    case "por_cerrar": return "por-cerrar";
    case "abierto": return "abierto";
    case "en_uso": return "en-uso";
    case "cerrado": return "inactiva";  // coincide con tu CSS rojo
    default: return "inactiva";
  }
}

// Formato de texto visible
function formatearEstado(estado) {
  if (!estado) return "Desconocido";

  switch (estado.toLowerCase()) {
    case "por_abrir": return "Por abrir";
    case "abierto": return "Abierto";
    case "en_uso": return "En uso";
    case "por_cerrar": return "Por cerrar";
    case "cerrado": return "Cerrado";
    default: return estado;
  }
}
