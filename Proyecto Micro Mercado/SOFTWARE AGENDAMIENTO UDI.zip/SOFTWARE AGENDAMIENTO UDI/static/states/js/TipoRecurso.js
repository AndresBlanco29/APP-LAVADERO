// 🔒 Ocultar el contenido hasta verificar sesión
document.documentElement.style.visibility = "hidden";

document.addEventListener("DOMContentLoaded", () => {
  const usuario = localStorage.getItem("usuario");
  const rol = localStorage.getItem("rol");

  // Si no hay usuario o rol, redirige inmediatamente al login
  if (!usuario || !rol) {
    window.location.replace("/"); // reemplaza la URL actual en el historial
    return;
  }

  // Mostrar contenido y nombre del usuario
  document.documentElement.style.visibility = "visible";
  const userElement = document.querySelector(".username");
  if (userElement) userElement.textContent = usuario;

  // Botón cerrar sesión
  const btnCerrar = document.getElementById("cerrarSesion");
  if (btnCerrar) {
    btnCerrar.addEventListener("click", () => {
      // Limpiar todo lo relacionado con sesión
      localStorage.clear();
      // Reemplazar URL actual para evitar back
      window.location.replace("/");
    });
  }
});

// Evitar que el navegador muestre contenido sensible desde cache
window.addEventListener("pageshow", (event) => {
  if (event.persisted) {
    window.location.replace("/"); // si venía del historial y persistió, redirige
  }
});


document.addEventListener("DOMContentLoaded", () => {
  const tablaBody = document.querySelector("tbody");
  const btnAgregar = document.getElementById("btnAgregar");
  const modalAgregar = document.getElementById("modalAgregar");
  const modalActualizar = document.getElementById("modalActualizar");
  const modalExito = document.getElementById("modalExito");

  const cerrarAgregar = document.getElementById("modalCerrarAgregar");
  const cerrarActualizar = document.getElementById("modalCerrarActualizar");
  const cerrarExito = document.getElementById("cerrarExito");
  const btnAceptarExito = document.getElementById("btnAceptarExito");

  const btnGuardarAgregar = document.getElementById("btnGuardarAgregar");
  const btnGuardarActualizar = document.getElementById("btnGuardarActualizar");

  const inputRecurso = document.getElementById("inputRecurso");
  const selectEstado = document.getElementById("selectEstado");
  const inputRecursoActualizar = document.getElementById("inputRecursoActualizar");

  let idActualizar = null;

  // ---------- FUNCIONES BASE ----------
  function abrirModal(modal) {
    modal.style.display = "flex";
    setTimeout(() => modal.classList.add("activo"), 10);
  }

  function cerrarModal(modal) {
    modal.classList.remove("activo");
    setTimeout(() => (modal.style.display = "none"), 200);
  }

  function mostrarExito() {
    abrirModal(modalExito);
  }

  // ---------- FUNCIÓN SEGURA DE PARSEO ----------
  async function parsearJSONSeguro(res) {
    const text = await res.text();
    try {
      return JSON.parse(text);
    } catch {
      console.error("Respuesta no válida del servidor:", text);
      throw new Error("El servidor no devolvió JSON válido");
    }
  }

  // ---------- CARGAR TABLA ----------
  async function cargarTiposRecurso() {
    try {
      const res = await fetch("/TiposRecurso");
      if (!res.ok) throw new Error(`Error HTTP ${res.status}`);
      const data = await parsearJSONSeguro(res);

      tablaBody.innerHTML = "";

      data.forEach(item => {
        const fila = document.createElement("tr");

        // Convertir solo para mostrar, no para guardar
        const nombreMayus = item.nombre ? item.nombre.toUpperCase() : "";
        const estadoMayus = item.status ? item.status.toUpperCase() : "";

        const estadoClase = estadoMayus === "ACTIVO" ? "activo" : "inactivo";

        fila.innerHTML = `
          <td>${nombreMayus}</td>
          <td><span class="estado ${estadoClase}">${estadoMayus}</span></td>
          <td class="opciones">
            <button class="btn-editar" data-id="${item.idtiporecurso}" data-nombre="${item.nombre}">
              <i class="fas fa-pen"></i>
            </button>
            <button class="btn-recargar" data-id="${item.idtiporecurso}">
              <i class="fas fa-sync"></i>
            </button>
          </td>
        `;
        tablaBody.appendChild(fila);
      });
    } catch (error) {
      console.error("Error al cargar los tipos de recurso:", error);
    }
  }


  // ---------- AGREGAR ----------
  btnAgregar.addEventListener("click", () => abrirModal(modalAgregar));
  cerrarAgregar.addEventListener("click", () => cerrarModal(modalAgregar));

  btnGuardarAgregar.addEventListener("click", async () => {
    const nombre = inputRecurso.value.trim();
    const estado = selectEstado.value;

    if (!nombre || !estado) {
      alert("Por favor complete todos los campos");
      return;
    }

    try {
      const res = await fetch("/tiporecurso/agregar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nombre, status: estado }),
      });

      if (!res.ok) throw new Error(`Error HTTP ${res.status}`);
      const data = await parsearJSONSeguro(res);

      if (data.success) {
        cerrarModal(modalAgregar);
        mostrarExito();
        cargarTiposRecurso();
      } else {
        alert(data.error || "Error al agregar tipo de recurso");
      }
    } catch (error) {
      console.error("Error al guardar tipo de recurso:", error);
    }
  });

  // ---------- ACTUALIZAR ----------
  tablaBody.addEventListener("click", e => {
    if (e.target.closest(".btn-editar")) {
      const btn = e.target.closest(".btn-editar");
      idActualizar = btn.dataset.id;
      inputRecursoActualizar.value = btn.dataset.nombre;
      abrirModal(modalActualizar);
    }
  });

  cerrarActualizar.addEventListener("click", () => cerrarModal(modalActualizar));

  btnGuardarActualizar.addEventListener("click", async () => {
    const nombre = inputRecursoActualizar.value.trim();
    if (!nombre) {
      alert("Debe ingresar un nombre");
      return;
    }

    try {
      const res = await fetch(`/tiporecurso/actualizar/${idActualizar}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nombre }),
      });

      if (!res.ok) throw new Error(`Error HTTP ${res.status}`);
      const data = await parsearJSONSeguro(res);

      if (data.success) {
        cerrarModal(modalActualizar);
        mostrarExito();
        cargarTiposRecurso();
      } else {
        alert(data.error || "Error al actualizar");
      }
    } catch (error) {
      console.error("Error al actualizar tipo de recurso:", error);
    }
  });

  // ---------- CAMBIAR ESTADO ----------
  tablaBody.addEventListener("click", async e => {
    if (e.target.closest(".btn-recargar")) {
      const id = e.target.closest(".btn-recargar").dataset.id;
      try {
        const res = await fetch(`/tiporecurso/estado/${id}`, { method: "POST" });
        if (!res.ok) throw new Error(`Error HTTP ${res.status}`);
        const data = await parsearJSONSeguro(res);

        if (data.success) {
          mostrarExito();
          cargarTiposRecurso();
        } else {
          alert(data.error || "Error al cambiar el estado");
        }
      } catch (error) {
        console.error("Error al cambiar estado:", error);
      }
    }
  });

  // ---------- MODAL ÉXITO ----------
  cerrarExito.addEventListener("click", () => cerrarModal(modalExito));
  btnAceptarExito.addEventListener("click", () => cerrarModal(modalExito));

  // ---------- INICIO ----------
  cargarTiposRecurso();
});
