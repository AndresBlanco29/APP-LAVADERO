// 🔒 Ocultar el contenido hasta verificar sesión
document.documentElement.style.visibility = "hidden";

document.addEventListener("DOMContentLoaded", () => {
  const usuario = localStorage.getItem("usuario");
  const rol = localStorage.getItem("rol");

  // Si no hay usuario o rol, redirige inmediatamente al login
  if (!usuario || !rol) {
    window.location.replace("/"); // reemplaza la URL actual en el historial
    return;
  }

  // Mostrar contenido y nombre del usuario
  document.documentElement.style.visibility = "visible";
  const userElement = document.querySelector(".username");
  if (userElement) userElement.textContent = usuario;

  // Botón cerrar sesión
  const btnCerrar = document.getElementById("cerrarSesion");
  if (btnCerrar) {
    btnCerrar.addEventListener("click", () => {
      // Limpiar todo lo relacionado con sesión
      localStorage.clear();
      // Reemplazar URL actual para evitar back
      window.location.replace("/");
    });
  }
});

// Evitar que el navegador muestre contenido sensible desde cache
window.addEventListener("pageshow", (event) => {
  if (event.persisted) {
    window.location.replace("/"); // si venía del historial y persistió, redirige
  }
});


document.addEventListener("DOMContentLoaded", () => {
  let usuarios = [];
  let filaEditando = null;
  let solicitudPassword = null; // 👈 para guardar la contraseña de la solicitud

  const tbody = document.getElementById("tbodyUsuarios");
  const franjaInferior = document.getElementById("franjaInferior");

  const modalAgregar = document.getElementById("modalAgregar");
  const modalEditar = document.getElementById("modalEditar");
  const modalExito = document.getElementById("modalExito");

  const btnAgregar = document.getElementById("btnAgregar");
  const modalCerrar = document.getElementById("modalCerrar");
  const cancelAgregar = document.getElementById("cancelAgregar");
  const guardarAgregar = document.getElementById("guardarAgregar");
  const inputNombre = document.getElementById("inputNombre");
  const inputCedula = document.getElementById("inputCedula");
  const inputRol = document.getElementById("inputRol");
  const inputCorreo = document.getElementById("inputCorreo");
  const inputCelular = document.getElementById("inputCelular");

  const modalCerrarEditar = document.getElementById("modalCerrarEditar");
  const cancelEditar = document.getElementById("cancelEditar");
  const guardarEditar = document.getElementById("guardarEditar");
  const editarNombre = document.getElementById("editarNombre");
  const editarCedula = document.getElementById("editarCedula");
  const editarRol = document.getElementById("editarRol");
  const editarCorreo = document.getElementById("editarCorreo");
  const editarCelular = document.getElementById("editarCelular");

  const cerrarExito = document.getElementById("cerrarExito");
  const btnAceptarExito = document.getElementById("btnAceptarExito");
  const textoExito = document.getElementById("textoExito");

  // ======== Funciones modales ========
  function abrirModal(modal) {
    if (!modal) return;
    modal.style.display = "flex";
    setTimeout(() => modal.classList.add("activo"), 10);
    modal.setAttribute("aria-hidden", "false");
  }

  function cerrarModal(modal) {
    if (!modal) return;
    modal.classList.remove("activo");
    setTimeout(() => (modal.style.display = "none"), 180);
    modal.setAttribute("aria-hidden", "true");
  }

  function mostrarExito(msj = "La acción se completó correctamente.") {
    textoExito.textContent = msj;
    abrirModal(modalExito);
    setTimeout(() => cerrarModal(modalExito), 1800);
  }

  // ======== Cargar usuarios desde BD ========
  async function cargarUsuariosDesdeBD() {
    try {
      const resp = await fetch("/UsuariosDatos");
      const data = await resp.json();
      if (resp.ok && Array.isArray(data)) {
        usuarios = data.map((u) => ({
          nombre: u.nombre,
          cedula: u.cedula,
          rol: u.rol,
          correo: u.correo,
          celular: u.celular || "",
          estado: u.status || "Activo",
          id: u.idusuario || null,
        }));
        cargarTabla();
      } else {
        usuarios = [];
        cargarTabla();
      }
    } catch (err) {
      console.error("Error al cargar usuarios:", err);
      usuarios = [];
      cargarTabla();
    }
  }

  // ======== Renderizar tabla ========
  function cargarTabla() {
    tbody.innerHTML = "";
    usuarios.forEach((u, i) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${u.nombre.toUpperCase()}</td>
        <td>${u.cedula.toUpperCase()}</td>
        <td>${u.rol.toUpperCase()}</td>
        <td>${u.correo.toUpperCase()}</td>
        <td>${(u.celular || "").toUpperCase()}</td>
        <td style="text-align:center;"><span class="estado ${
          u.estado === "Activo" ? "activo" : "inactivo"
        }">${u.estado.toUpperCase()}</span></td>
        <td style="text-align:center;">
          <div class="opciones" role="group" aria-label="acciones">
            <button class="btn-editar" data-index="${i}" title="Editar"><i class="fas fa-pen"></i></button>
            <button class="btn-recargar" data-index="${i}" title="${
        u.estado === "Activo" ? "Desactivar" : "Activar"
      }"><i class="fas fa-sync"></i></button>
          </div>
        </td>
      `;

      tbody.appendChild(tr);
    });

    franjaInferior.textContent = `Mostrando del 1 al ${usuarios.length} de ${usuarios.length} usuarios`;

    document.querySelectorAll(".btn-recargar").forEach((btn) => {
      btn.onclick = async () => {
        const idx = Number(btn.dataset.index);
        const nuevoEstado =
          usuarios[idx].estado === "Activo" ? "Inactivo" : "Activo";
        try {
          const resp = await fetch(`/Usuarios/estado`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              idusuario: usuarios[idx].id,
              status: nuevoEstado,
            }),
          });
          const data = await resp.json();
          if (resp.ok && data.success) {
            usuarios[idx].estado = nuevoEstado;
            cargarTabla();
          } else {
            alert("Error al actualizar estado.");
          }
        } catch (err) {
          console.error("Error cambiando estado:", err);
        }
      };
    });

    document.querySelectorAll(".btn-editar").forEach((btn) => {
      btn.onclick = () => {
        const idx = Number(btn.dataset.index);
        filaEditando = idx;
        const u = usuarios[idx];
        editarNombre.value = u.nombre;
        editarCedula.value = u.cedula;
        editarRol.value = u.rol;
        editarCorreo.value = u.correo;
        editarCelular.value = u.celular || "";
        abrirModal(modalEditar);
      };
    });
  }

  // ======== Si hay solicitud pendiente ========
  async function verificarSolicitudPendiente() {
    const params = new URLSearchParams(window.location.search);
    const solicitud_id = params.get("solicitud_id");
    if (!solicitud_id) return;

    try {
      const resp = await fetch(`/obtener_solicitud/${solicitud_id}`);
      const data = await resp.json();
      if (data.success && data.solicitud) {
        const s = data.solicitud;

        // Guardamos la contraseña temporalmente 👇
        solicitudPassword = s.password;

        // Abrir modal con datos precargados
        inputNombre.value = s.nombre;
        inputCedula.value = s.cedula;
        inputCorreo.value = s.correo;
        inputCelular.value = s.telefono;
        inputRol.value = s.rol;

        abrirModal(modalAgregar);
      }
    } catch (err) {
      console.error("Error obteniendo solicitud:", err);
    }
  }

  // ======== Eventos agregar ========
  if (btnAgregar)
    btnAgregar.addEventListener("click", () => {
      inputNombre.value = "";
      inputCedula.value = "";
      inputRol.value = "";
      inputCorreo.value = "";
      inputCelular.value = "";
      solicitudPassword = null; // limpiar por si acaso
      abrirModal(modalAgregar);
    });

  if (modalCerrar) modalCerrar.addEventListener("click", () => cerrarModal(modalAgregar));
  if (cancelAgregar) cancelAgregar.addEventListener("click", () => cerrarModal(modalAgregar));

  if (guardarAgregar)
    guardarAgregar.addEventListener("click", async () => {
      const nombre = inputNombre.value.trim();
      const cedula = inputCedula.value.trim();
      const rol = inputRol.value.trim();
      const correo = inputCorreo.value.trim();
      const celular = inputCelular.value.trim();
      if (!nombre || !cedula || !rol || !correo) {
        alert("Por favor completa los campos obligatorios");
        return;
      }

      // Detectar si viene de una solicitud
      const params = new URLSearchParams(window.location.search);
      const solicitud_id = params.get("solicitud_id");

      try {
        const resp = await fetch("/UsuariosAgregar", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            nombre,
            cedula,
            rol,
            correo,
            celular,
            status: "Activo",
            solicitud_id,
            password: solicitudPassword, // 👈 se envía si existía
          }),
        });
        const data = await resp.json();
        if (resp.ok && data.success) {
          cerrarModal(modalAgregar);
          mostrarExito("Usuario agregado correctamente.");
          await cargarUsuariosDesdeBD();

          // Si provenía de una solicitud, limpiar la URL
          if (solicitud_id) {
            window.history.replaceState({}, document.title, window.location.pathname);
          }
        } else {
          alert(data.error || "Error al agregar usuario.");
        }
      } catch (err) {
        console.error("Error agregando usuario:", err);
      }
    });

  // ======== Eventos editar ========
  if (modalCerrarEditar) modalCerrarEditar.addEventListener("click", () => cerrarModal(modalEditar));
  if (cancelEditar) cancelEditar.addEventListener("click", () => cerrarModal(modalEditar));

  if (guardarEditar)
    guardarEditar.addEventListener("click", async () => {
      if (filaEditando === null) return;
      const nombre = editarNombre.value.trim();
      const rol = editarRol.value.trim();
      const correo = editarCorreo.value.trim();
      const celular = editarCelular.value.trim();
      if (!nombre || !rol || !correo) {
        alert("Completa los campos obligatorios");
        return;
      }

      try {
        const resp = await fetch(`/Usuarios/${usuarios[filaEditando].id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ nombre, rol, correo, celular }),
        });
        const data = await resp.json();
        if (resp.ok && data.success) {
          cerrarModal(modalEditar);
          mostrarExito("Usuario actualizado correctamente.");
          filaEditando = null;
          await cargarUsuariosDesdeBD();
        } else {
          alert(data.error || "Error al actualizar usuario.");
        }
      } catch (err) {
        console.error("Error actualizando usuario:", err);
      }
    });

  // ======== Eventos modal éxito ========
  if (cerrarExito) cerrarExito.addEventListener("click", () => cerrarModal(modalExito));
  if (btnAceptarExito) btnAceptarExito.addEventListener("click", () => cerrarModal(modalExito));

  // ======== Cerrar modales al click fuera ========
  window.addEventListener("click", (e) => {
    [modalAgregar, modalEditar, modalExito].forEach((m) => {
      if (m && e.target === m) cerrarModal(m);
    });
  });

  // ======== Cerrar con ESC ========
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      [modalAgregar, modalEditar, modalExito].forEach((m) => {
        if (m && m.classList.contains("activo")) cerrarModal(m);
      });
    }
  });

  // ======== Inicializar ========
  verificarSolicitudPendiente();
  cargarUsuariosDesdeBD();
});
