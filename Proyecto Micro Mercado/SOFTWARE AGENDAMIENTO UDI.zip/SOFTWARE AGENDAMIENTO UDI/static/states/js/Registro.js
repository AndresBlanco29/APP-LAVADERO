document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('registroForm');
    const togglePassword = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('password');
    const btnVolver = document.querySelector('.btn-back');

    // Mostrar / ocultar contraseña
    togglePassword.addEventListener('click', () => {
        const type = passwordInput.type === 'password' ? 'text' : 'password';
        passwordInput.type = type;
    });

    // Envío de formulario
    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const nombre = document.getElementById('nombre').value.trim();
        const correo = document.getElementById('correo').value.trim();
        const cedula = document.getElementById('cedula').value.trim();
        const telefono = document.getElementById('telefono').value.trim();
        const password = document.getElementById('password').value.trim();
        const rol = document.getElementById('rol').value.trim();


        const errores = [];
        if (!nombre) errores.push("El campo Nombre es obligatorio.");
        if (!correo) errores.push("El campo Correo es obligatorio.");
        if (!cedula) errores.push("El campo Cédula es obligatorio.");
        if (!telefono) errores.push("El campo Teléfono es obligatorio.");
        if (!password) errores.push("El campo Contraseña es obligatorio.");
        if (!rol) errores.push("Debe seleccionar un rol.");

        if (errores.length > 0) {
            alert("Por favor corrija los siguientes errores:\n- " + errores.join("\n- "));
            return;
        }

        const datos = { nombre, correo, cedula, telefono, password, rol };

        try {
            // Desactiva el botón de envío mientras se procesa
            const btnSubmit = form.querySelector('.btn-submit');
            btnSubmit.disabled = true;
            btnSubmit.textContent = 'Enviando...';

            const respuesta = await fetch('/solicitar_usuario', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(datos)
            });

            const resultado = await respuesta.json();

            if (resultado.success) {
                alert("Solicitud enviada correctamente. Recibirá una confirmación cuando sea aprobada.");
                form.reset();
            } else {
                alert("Error: " + (resultado.message || "No se pudo enviar la solicitud."));
            }
        } catch (error) {
            console.error("Error al enviar la solicitud:", error);
            alert("Error al conectar con el servidor. Intente nuevamente.");
        } finally {
            // Reactiva el botón
            const btnSubmit = form.querySelector('.btn-submit');
            btnSubmit.disabled = false;
            btnSubmit.textContent = 'Enviar';
        }
    });

    // Botón volver al inicio
    btnVolver.addEventListener('click', () => {
        window.location.href = '/';
    });
});
