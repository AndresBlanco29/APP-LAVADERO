document.addEventListener("DOMContentLoaded", () => {
    cargarPrestamos();
});

const boton = document.getElementById("ver_aulas");

boton.addEventListener("click", function() {
  window.location.href = '/Diario_Aulas';
});

const btnvolver = document.getElementById("btn-volver");

btnvolver.addEventListener("click", function() {
  window.location.href = '/Calendario';
});

/* --- Convierte "20/08/2025" en "Miércoles, 20 de agosto de 2025" --- */
function convertirFechaLarga(fechaTexto) {
  if (!fechaTexto) return "-";

  const soloFecha = fechaTexto.split(",")[0].trim();
  const partes = soloFecha.split("/");
  if (partes.length !== 3) return fechaTexto;

  const dia = parseInt(partes[0]);
  const mes = parseInt(partes[1]) - 1;
  const anio = parseInt(partes[2]);

  const fecha = new Date(anio, mes, dia);
  const opciones = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
  const fechaLarga = new Intl.DateTimeFormat("es-ES", opciones).format(fecha);

  return fechaLarga.charAt(0).toUpperCase() + fechaLarga.slice(1);
}

/* --- Elementos del modal --- */
const overlayDetalle = document.getElementById("overlay-detalle");
const btnCerrarDetalle = document.getElementById("cerrar-detalle");

/* --- Cerrar modal --- */
btnCerrarDetalle.addEventListener("click", () => (overlayDetalle.style.display = "none"));
overlayDetalle.addEventListener("click", (e) => {
  if (e.target === overlayDetalle) overlayDetalle.style.display = "none";
});

/* --- Abre modal con los datos --- */
function abrirDetallesConDatos(datos) {
  if (!datos) return;

  const fechaSolicitudLarga = convertirFechaLarga(datos.fechaSolicitud);
  const fechaPrestamoLarga = convertirFechaLarga(datos.fechaPrestamo);

  document.getElementById("modal-nombre").textContent = datos.nombre || "-";
  document.getElementById("modal-telefono").textContent = datos.telefono || "-";
  document.getElementById("modal-correo").textContent = datos.correo || "-";
  document.getElementById("modal-recurso").textContent = datos.recurso || "-";
  document.getElementById("modal-edificio").textContent = datos.edificio || "-";
  document.getElementById("modal-desc").textContent = datos.descripcion || "-";
  document.getElementById("modal-fecha").textContent = fechaSolicitudLarga || "-";
  document.getElementById("modal-dia").textContent = fechaPrestamoLarga || "-";
  document.getElementById("modal-inicio").textContent = datos.horaInicio || "-";
  document.getElementById("modal-fin").textContent = datos.horaFin || "-";

  overlayDetalle.style.display = "flex";
}

/* --- Utilidad para limpiar texto --- */
function texto(td) {
  return td ? td.textContent.trim() : "";
}

/* --- Detecta click en botón Detalles --- */
document.addEventListener("click", function (e) {
  const btn = e.target.closest(".Btn-Detalles");
  if (!btn) return;

  const tr = btn.closest("tr");
  if (!tr) return;

  const tds = tr.querySelectorAll("td");

  const datos = {
    nombre: texto(tds[0]),
    fechaPrestamo: texto(tds[1]).split(",")[0].trim(),
    horaInicio: (texto(tds[1]).split(",")[1] || "").trim(),
    horaFin: (texto(tds[2]).split(",")[1] || "").trim(),
    recurso: texto(tds[3]),
    aula: texto(tds[4]),
    descripcion: texto(tds[5]),
    telefono: tr.dataset.telefono || "",
    correo: tr.dataset.correo || "",
    edificio: tr.dataset.edificio || "",
    fechaSolicitud: tr.dataset.fechaSolicitud || ""
  };

  abrirDetallesConDatos(datos);
});


// =================================================================
// ===== SECCIÓN CORREGIDA: LÓGICA DE ESTADOS Y ACTUALIZACIÓN =====
// =================================================================

/**
 * Devuelve un objeto con la clase CSS, la letra y el TEXTO COMPLETO
 * para un estado determinado ('P', 'U', 'D').
 */
function getEstadoInfo(estado) {
    if (estado === "Pendiente") {
        return { clase: 'estado-pendiente', letra: 'P',  };
    } else if (estado === "En uso") {
        return { clase: 'estado-en-uso', letra: 'U',  };
    } else if (estado === "Devuelto") {
        return { clase: 'estado-devuelto', letra: 'D', };
    }
    // Valor por defecto si el estado no es válido
    return { clase: 'estado-desconocido', letra: '?' };
}


/**
 * Se activa al hacer clic en el botón "Cambiar Estado".
 * Cambia el estado del préstamo de forma cíclica (P -> U -> D -> P).
 */
function cambiarEstado(btnAccion) {
    const fila = btnAccion.closest('tr');
    const btnEstado = fila.querySelector('.btn-estado-tabla');
    const idReserva = fila.dataset.id;
    
    let estadoActual = btnEstado.dataset.estado;
    let nuevoEstado;

    // 1. Calcular el siguiente estado
    if (estadoActual === 'Pendiente') {
        nuevoEstado = 'En uso';
    } else if (estadoActual === 'En uso') {
        nuevoEstado = 'Devuelto';
    } else { // Si es 'D' o cualquier otro valor, vuelve a 'P'
        return;
    }

    // 2. ACTUALIZAR LA INTERFAZ EN TIEMPO REAL
    const estadoInfo = getEstadoInfo(nuevoEstado);
    btnEstado.className = `btn-estado-tabla ${estadoInfo.clase}`; // Actualiza clase y color
    btnEstado.dataset.estado = nuevoEstado; // Actualiza el estado guardado en el botón
    // Actualiza el contenido del botón para mostrar el círculo y el texto completo
    btnEstado.innerHTML = `<span class="estado-circulo">${estadoInfo.letra}</span>`;

   
    // 3. ENVIAR CAMBIO AL SERVIDOR
    fetch(`/api/prestamos/${idReserva}/estado`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ estado: nuevoEstado }),
    })
    .then(response => {
        if (!response.ok) {
            console.error('Error al actualizar el estado en el servidor.');
        }
        return response.json();
    })
    .then(data => {
        if(data.success) {
            
        } else {
            console.error('El servidor devolvió un error:', data.error);
        }
    })
    .catch(error => {
        console.error('Error de red al actualizar el estado:', error);
    });
}


async function cargarPrestamos() {
    const tbody = document.getElementById("tabla-prestamos");

    const encabezado = tbody.querySelector('.head');
    tbody.innerHTML = ''; 
    if (encabezado) {
        tbody.appendChild(encabezado);
    }

    try {
        const res = await fetch("/api/prestamos");
        const prestamos = await res.json();

        prestamos.forEach(p => {
            const tr = document.createElement("tr");
            
            tr.dataset.id = p.id || '';
            tr.dataset.telefono = p.telefono || 'N/A';
            tr.dataset.correo = p.correo || 'N/A';
            tr.dataset.edificio = p.ubicacion || 'No especificado';
            tr.dataset.fechaSolicitud = p.fecha || 'N/A';
            
            // Usamos la función auxiliar para obtener la info visual del estado
            const estadoInfo = getEstadoInfo(p.estado);

            // Se construye la fila de la tabla
            tr.innerHTML = `
                <td>${p.nombre || 'N/A'}</td>
                <td>${p.fecha || 'N/A'}, ${p.inicio || 'N/A'}</td>
                <td>${p.fecha || 'N/A'}, ${p.fin || 'N/A'}</td>
                <td>${p.recurso || 'N/A'}</td>
                <td>${p.ubicacion || 'N/A'}</td> 
                <td>${p.descripcion || "N.A"}</td>
                
                <td>
                    <button class="btn-estado-tabla ${estadoInfo.clase}" data-estado="${p.estado}">
                        <span class="estado-circulo">${estadoInfo.letra}</span>
                      
                    </button>
                </td>
                <td>
                    <button class="btn-accion-cambiar" onclick="cambiarEstado(this)">
                        Cambiar Estado
                    </button>
                </td>
                <td class="columna-opciones">
                    <button class="Btn-Detalles">Detalles</button>
                    <button class="btn-eliminar" onclick="eliminarReserva(${p.id}, this)">
                        <img src="/static/images/borrar.jpeg" alt="Eliminar">
                    </button>
                </td>`;

            tbody.appendChild(tr);
        });

    } catch (err) {
        console.error("Error cargando préstamos:", err);
        tbody.innerHTML += `<tr><td colspan="9" style="text-align:center; color:red;">${err.message || 'Error al conectar con la API.'}</td></tr>`;
    }
}


async function eliminarReserva(idReserva, elementoBoton) {
    if (!confirm(`¿Está seguro de que desea eliminar la reserva con ID ${idReserva}?`)) {
        return;
    }

    try {
        const response = await fetch(`/api/prestamos/${idReserva}`, {
            method: 'DELETE',
        });

        if (response.ok) {
            const fila = elementoBoton.closest('tr');
            if (fila) {
                fila.remove();
            }
        } else {
            const errorData = await response.json();
            alert(`Error al eliminar: ${errorData.mensaje || 'Error desconocido del servidor.'}`);
        }

    } catch (error) {
        console.error("Error en la solicitud de eliminación:", error);
        alert("Ocurrió un error de conexión al intentar eliminar.");
    }
}
