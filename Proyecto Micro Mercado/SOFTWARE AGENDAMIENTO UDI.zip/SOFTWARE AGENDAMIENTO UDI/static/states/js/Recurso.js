// 🔒 Ocultar el contenido hasta verificar sesión
document.documentElement.style.visibility = "hidden";



window.addEventListener("pageshow", (event) => {
  if (event.persisted) window.location.replace("/");
});

document.addEventListener("DOMContentLoaded", async () => {

  const usuario = localStorage.getItem("usuario");
  const rol = localStorage.getItem("rol");

  if (!usuario || !rol) {
    window.location.replace("/");
    return;
  }

  document.documentElement.style.visibility = "visible";
  const userElement = document.querySelector(".username");
  if (userElement) userElement.textContent = usuario;

  const btnCerrar = document.getElementById("cerrarSesion");
  if (btnCerrar) {
    btnCerrar.addEventListener("click", () => {
      localStorage.clear();
      window.location.replace("/");
    });
  }
  
  const tbody = document.querySelector("tbody");

  // 🔹 Modales
  const modalAgregar = document.getElementById("modalAgregar");
  const modalActualizar = document.getElementById("modalActualizar");
  const modalConfirmar = document.getElementById("modalConfirmar");
  const modalExito = document.getElementById("modalExito");

  // 🔹 Botones
  const btnAbrir = document.getElementById("btnAbrirAgregar");
  const cerrarAgregar = document.getElementById("cerrarAgregar");
  const btnGuardar = document.getElementById("btnGuardar");
  const cerrarConfirmar = document.getElementById("cerrarConfirmar");
  const btnSiGuardar = document.getElementById("btnSiGuardar");
  const btnCancelarGuardar = document.getElementById("btnCancelarGuardar");
  const btnAceptarExito = document.querySelector(".btn-aceptar");
  const cerrarActualizar = document.getElementById("cerrarActualizar");
  const btnActualizar = document.getElementById("btnActualizar");

  // 🔹 Inputs modal AGREGAR
  const selTipo = document.getElementById("selTipo");
  const inputMarca = document.getElementById("inputMarca");
  const inputInventario = document.getElementById("inputInventario");
  const inputDescripcion = document.getElementById("inputDescripcion");
  const selEstado = document.getElementById("selEstado");

  const campoEdificio = document.getElementById("campoEdificio");
  const campoAula = document.getElementById("campoAula");
  const selEdificio = document.getElementById("selEdificio");
  const selAula = document.getElementById("selAula");


  // 🔹 Inputs modal ACTUALIZAR
  const selTipoActualizar = document.getElementById("selTipoActualizar");
  const inputMarcaActualizar = document.getElementById("inputMarcaActualizar");
  const inputInventarioActualizar = document.getElementById("inputInventarioActualizar");
  const inputDescripcionActualizar = document.getElementById("inputDescripcionActualizar");
  const selEstadoActualizar = document.getElementById("selEstadoActualizar");

  let idRecursoEditar = null;

  const aulasPorEdificio = {
    "Edificio ERNESTO SÁBATO": ["Sala 16", "Sala 17", "Sala 18","Sala 19"],
    "Edificio JORGE LUIS BORGES": ["Sala 1","Sala 2","Sala 3","Sala 4","Sala 5","Sala 6","Sala 7","Sala 8","Sala 9","Sala 10","Sala 12","Sala 404","Sala MAC"],
    "Edificio CARLOS LLERAS": ["Sala 201","Sala 505","Sala 601"],
    "Edificio DAVID CONSUEGRA": ["Sala MAC"]
  };

  // ==================== FUNCIONES ====================
  async function cargarRecursos() {
    try {
      const resp = await fetch("/Recursos");
      const data = await resp.json();

      if (resp.ok && Array.isArray(data)) {
        tbody.innerHTML = "";
        data.forEach((r) => {
          const fila = document.createElement("tr");
          fila.innerHTML = `
            <td>${(r.nombre || "—").toUpperCase()}</td>
            <td>${(r.descripcion || "—").toUpperCase()}</td>
            <td>${(r.tipo || "—").toUpperCase()}</td>
            <td><span class="estado ${r.status === "Activo" ? "activo" : "inactivo"}">${r.status}</span></td>
            <td>
              <button class="btn-editar" data-id="${r.idrecurso}"><i class="fa-solid fa-pen-to-square"></i></button>
              <button class="btn-recargar" data-id="${r.idrecurso}"><i class="fa-solid fa-sync"></i></button>
            </td>
          `;
          tbody.appendChild(fila);
        });
      } else {
        tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;">No hay recursos registrados</td></tr>`;
      }
    } catch (err) {
      console.error("Error cargando recursos:", err);
      tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; color:red;">Error al conectar con el servidor</td></tr>`;
    }

    inicializarEventos();
  }

  // 🔹 Cargar tipos de recurso en un <select>
  async function cargarTiposRecurso(selectElement) {
      try {
          const resp = await fetch("/TiposRecurso");
          if (!resp.ok) {
              console.error("Error en la respuesta HTTP:", resp.status);
              return;
          }

          const data = await resp.json();

          // Limpiar el select y agregar opción por defecto
          selectElement.innerHTML = '<option value="">Seleccione el tipo de recurso</option>';

          // Agregar opciones según la respuesta del servidor
          data.forEach(tipo => {
              if (tipo.status === "Activo") {
                  const option = document.createElement("option");
                  option.value = tipo.idtiporecurso; // ID correcto para guardar en DB
                  option.textContent = tipo.nombre;   // Nombre que se muestra al usuario
                  selectElement.appendChild(option);
              }
          });
      } catch (err) {
          console.error("Error cargando tipos de recurso:", err);
      }
  }

  function openModal(modal) { modal.style.display = "flex"; }
  function closeModal(modal) { modal.style.display = "none"; }

  function limpiarFormulario() {
    selTipo.value = "";
    inputMarca.value = "";
    inputInventario.value = "";
    inputDescripcion.value = "";
    selEstado.value = "";
    campoEdificio.style.display = "none";
    campoAula.style.display = "none";
    selEdificio.value = "";
    selAula.innerHTML = '<option value="">Seleccione un aula</option>';
  }

  // 🔹 Actualiza campos según el tipo de recurso
  function actualizarCamposPorTipo(tipoSelect, inventarioInput, marcaInput, descripcionInput, estadoSelect, campoEdificio, campoAula, selEdificio, selAula) {
      const textoSeleccionado = tipoSelect.options[tipoSelect.selectedIndex].text;

      if (textoSeleccionado === "SALA DE INFORMATICA") {
        // Solo deshabilitar los campos que NO se usan
        inventarioInput.disabled = true;
        descripcionInput.disabled = true;
        estadoSelect.disabled = true;

        // Limpiar valores de esos campos
        inventarioInput.value = "";
        descripcionInput.value = "";
        estadoSelect.value = "Cerrada";

        // Mostrar campos de Edificio y Aula
        campoEdificio.style.display = "block";
        campoAula.style.display = "none"; // hasta que se seleccione un edificio
        selEdificio.value = "";
        selAula.innerHTML = '<option value="">Seleccione un aula</option>';

        // Mantener habilitado el nombre
        marcaInput.disabled = false;
    }

  }



  // 🔹 Evento para detectar cambio en tipo de recurso
  selTipo.addEventListener("change", () => {
      actualizarCamposPorTipo(
          selTipo, 
          inputInventario, 
          inputMarca, 
          inputDescripcion, 
          selEstado, 
          campoEdificio, 
          campoAula, 
          selEdificio, 
          selAula
      );
  });


  // ==================== EVENTOS ====================

  // Abrir modal agregar
  btnAbrir.addEventListener("click", async () => {
      limpiarFormulario();
      await cargarTiposRecurso(selTipo);
      // 🔹 Pasa los 9 parámetros
      actualizarCamposPorTipo(selTipoActualizar, inputInventarioActualizar, inputMarcaActualizar, inputDescripcionActualizar, selEstadoActualizar, campoEdificio, campoAula, selEdificio, selAula);

      openModal(modalAgregar);
  });

  cerrarAgregar.addEventListener("click", () => closeModal(modalAgregar));

  // Cambio de tipo de recurso (Agregar)
  selTipo.addEventListener("change", () => {
    actualizarCamposPorTipo(selTipo, inputInventario, inputMarca, inputDescripcion, selEstado, campoEdificio, campoAula, selEdificio, selAula);
  });

  // Selección de edificio (Agregar)
  selEdificio.addEventListener("change", () => {
    const edificioId = selEdificio.value;
    if (edificioId) {
        campoAula.style.display = "block"; // mostrar select de aula
        cargarAulasPorEdificio(edificioId, selAula);
    } else {
        campoAula.style.display = "none";
        selAula.innerHTML = '<option value="">Seleccione un aula</option>';
    }
  });


  // Guardar recurso
  btnGuardar.addEventListener("click", () => {
    if (!selTipo.value) {
    alert("Seleccione un tipo de recurso.");
    return;
}

const tipoSeleccionado = selTipo.options[selTipo.selectedIndex].text;

if (tipoSeleccionado === "Sala de Informática") {
    if (!inputMarca.value || !selEdificio.value) {
        alert("Ingrese nombre de sala y edificio.");
        return;
    }
} else {
    if (!inputMarca.value || !inputDescripcion.value || !selEstado.value || !inputInventario.value) {
        alert("Complete todos los campos antes de guardar.");
        return;
    }
}

    closeModal(modalAgregar);
    openModal(modalConfirmar);
  });

  btnCancelarGuardar.addEventListener("click", () => closeModal(modalConfirmar));
  cerrarConfirmar.addEventListener("click", () => closeModal(modalConfirmar));

  btnSiGuardar.addEventListener("click", async () => {
    const tipoSeleccionado = selTipo.options[selTipo.selectedIndex].text;

    if (tipoSeleccionado === "Sala de Informática") {
        // Validar nombre y edificio
        if (!inputMarca.value || !selEdificio.value) {
            alert("Ingrese nombre de sala y edificio.");
            return;
        }

        const nuevaAula = {
            aula: inputMarca.value,
            edificio: parseInt(selEdificio.value), // ID del edificio
            status: "Cerrada"
        };

        try {
            const resp = await fetch("/api/aulas", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(nuevaAula)
            });
            const data = await resp.json();

            if (resp.ok && data.success) {
                closeModal(modalConfirmar);
                openModal(modalExito);
                limpiarFormulario();
            } else {
                alert(data.error || "Error al guardar la sala");
            }
        } catch (err) {
            console.error("Error guardando aula:", err);
            alert("Error de conexión con el servidor");
        }

    } else {
        // Recurso normal
        const nuevoRecurso = {
            nombre: inputMarca.value,
            descripcion: inputDescripcion.value,
            tipo: parseInt(selTipo.value),
            status: selEstado.value,
            inventario: parseInt(inputInventario.value)
        };

        try {
            const resp = await fetch("/Recursos", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(nuevoRecurso),
            });
            const data = await resp.json();

            if (resp.ok && data.success) {
                closeModal(modalConfirmar);
                openModal(modalExito);
                await cargarRecursos();
            } else {
                alert(data.error || "Error al guardar recurso");
            }
        } catch (err) {
            console.error("Error guardando recurso:", err);
            alert("Error de conexión con el servidor");
        }
    }
  });


  btnAceptarExito.addEventListener("click", () => {
    closeModal(modalExito);
    limpiarFormulario();
  });

  // Inicializar eventos de editar y recargar
  function inicializarEventos() {
    document.querySelectorAll(".btn-editar").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = btn.dataset.id;
        idRecursoEditar = id;

        try {
          // Primero obtenemos los datos del recurso
          const resp = await fetch(`/Recursos/${id}`);
          const data = await resp.json();

          if (!resp.ok || !data) {
            alert("No se encontraron datos del recurso.");
            return;
          }

          // Cargar tipos de recurso y luego asignar el valor
          await cargarTiposRecurso(selTipoActualizar);
          selTipoActualizar.value = data.tipo_id || "";
          inputMarcaActualizar.value = data.nombre || "";
          inputDescripcionActualizar.value = data.descripcion || "";
          selEstadoActualizar.value = data.status || "";
          inputInventarioActualizar.value = data.inventario !== undefined ? data.inventario : "";

          // 🔹 Actualizar campos según tipo
          // 🔹 Actualizar campos según tipo (modal ACTUALIZAR)
          actualizarCamposPorTipo(
            selTipoActualizar,
            inputInventarioActualizar,
            inputMarcaActualizar,
            inputDescripcionActualizar,
            selEstadoActualizar,
            campoEdificio,
            campoAula,
            selEdificio,
            selAula
          );

          openModal(modalActualizar);

        } catch (err) {
          console.error("Error al obtener recurso:", err);
          alert("Error al cargar los datos del recurso.");
        }
      });
    });

    document.querySelectorAll(".btn-recargar").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = btn.dataset.id;
        const fila = btn.closest("tr");
        const estadoEl = fila.querySelector("td:nth-child(4) span");
        const nuevoEstado = estadoEl.textContent.trim() === "Activo" ? "Inactivo" : "Activo";

        try {
          const resp = await fetch(`/Recursos/estado`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ idrecurso: id, status: nuevoEstado }),
          });
          const data = await resp.json();

          if (resp.ok && data.success) {
            estadoEl.textContent = nuevoEstado;
            estadoEl.className = `estado ${nuevoEstado === "Activo" ? "activo" : "inactivo"}`;
          } else {
            alert("Error al actualizar estado");
          }
        } catch (err) {
          console.error("Error actualizando estado:", err);
        }
      });
    });
  }

  cerrarActualizar.addEventListener("click", () => closeModal(modalActualizar));

  btnActualizar.addEventListener("click", async () => {
    if (!idRecursoEditar) { alert("Error: No se ha seleccionado ningún recurso."); return; }

    const actualizado = {
      nombre: inputMarcaActualizar.value,
      descripcion: inputDescripcionActualizar.value,
      tipo: parseInt(selTipoActualizar.value),
      status: selEstadoActualizar.value,
      inventario: parseInt(inputInventarioActualizar.value)
    };

    try {
      const resp = await fetch(`/Recursos/${idRecursoEditar}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(actualizado),
      });

      const data = await resp.json();

      if (resp.ok && data.success) {
        closeModal(modalActualizar);
        openModal(modalExito);
        await cargarRecursos();
      } else {
        alert(data.error || "Error al actualizar el recurso");
      }
    } catch (err) {
      console.error("Error actualizando recurso:", err);
      alert("Error de conexión con el servidor");
    }
  });

  [modalAgregar, modalActualizar, modalConfirmar, modalExito].forEach((modal) => {
    modal.addEventListener("click", (e) => { if (e.target === modal) closeModal(modal); });
  });

  await cargarRecursos();
});


async function cargarAulasPorEdificio(edificioId, aulaSelect) {
    try {
        const resp = await fetch(`/api/aulas_por_edificio/${edificioId}`);
        const data = await resp.json();

        aulaSelect.innerHTML = '<option value="">Seleccione un aula</option>';
        data.forEach(aula => {
            const option = document.createElement("option");
            option.value = aula.id;
            option.textContent = aula.aula;
            aulaSelect.appendChild(option);
        });
    } catch (err) {
        console.error("Error cargando aulas:", err);
    }
}
