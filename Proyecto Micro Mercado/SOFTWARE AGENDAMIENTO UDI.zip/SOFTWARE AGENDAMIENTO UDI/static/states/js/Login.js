// Detectar si el login fue abierto con una solicitud
const params = new URLSearchParams(window.location.search);
const solicitud_id = params.get('solicitud_id');

// Mostrar/Ocultar contraseña
const togglePassword = document.getElementById("togglePasswordIcon");
const passwordInput = document.querySelector("#password");
togglePassword.addEventListener("click", () => {
  const isPassword = passwordInput.getAttribute("type") === "password";
  passwordInput.setAttribute("type", isPassword ? "text" : "password");
  togglePassword.classList.toggle("eye-closed", isPassword);
});

// Elementos Recuperar
const modalRecuperar = document.getElementById("modalRecuperar");
const abrirModal = document.getElementById("abrirModal");
const solicitarRegistro = document.getElementById("solicitarRegistro");
const cerrarModal = document.getElementById("cerrarModal");
const leftPanel = document.querySelector('.left-panel');
const correoInput = document.getElementById("correoRecuperar");
const mensajeExito = document.getElementById("mensajeExito");

// Elementos Verificar
const modalVerificar = document.getElementById("modalVerificar");
const cerrarModalVerificar = document.getElementById("cerrarModalVerificar");
const verificarForm = document.getElementById("verificarForm");
const mensajeCodigoExito = document.getElementById("mensajeCodigoExito");
const mensajeCodigoError = document.getElementById("mensajeCodigoError");
const codigoInput = document.getElementById("codigoVerificar");

// Elementos Cambio de contraseña
const modalCambioClave = document.getElementById("modalCambioClave");
const cerrarModalCambio = document.getElementById("cerrarModalCambio");
const cambioClaveForm = document.getElementById("cambioClaveForm");
const nuevaClaveInput = document.getElementById("nuevaClave");
const confirmarClaveInput = document.getElementById("confirmarClave");
const mensajeCambioExito = document.getElementById("mensajeCambioExito");
const mensajeCambioError = document.getElementById("mensajeCambioError");
const requisitosDiv = document.getElementById("requisitosClave");

const modalExitoso = document.getElementById("modalExitoso");
const cerrarModalExitoso = document.getElementById("cerrarModalExitoso");

const iniciarSesionBtn = document.getElementById("iniciarSesionBtn");

const BASE_URL = 'http://127.0.0.1:5050';
let correoRecuperacion = "";



// --- Redirigir al formulario de registro ---

if (solicitarRegistro) {
  solicitarRegistro.addEventListener("click", (e) => {
    e.preventDefault(); // evita el salto al inicio
    window.location.href = "/registro"; // redirige al formulario
  });
}

// Abrir modal Recuperar
abrirModal.addEventListener("click", (e) => {
  e.preventDefault();

  // Limpiar campos del modal Recuperar
  if (correoInput) correoInput.value = "";
  if (mensajeExito) mensajeExito.style.display = "none";

  // A su vez, asegurar que el modal de verificar esté limpio
  if (codigoInput) codigoInput.value = "";
  if (mensajeCodigoError) mensajeCodigoError.style.display = "none";
  if (mensajeCodigoExito) mensajeCodigoExito.style.display = "none";

  modalRecuperar.classList.add("show");
  leftPanel.classList.add("opaco");
});

// Cerrar modal Recuperar
if (cerrarModal) {
  cerrarModal.addEventListener("click", () => {
    modalRecuperar.classList.remove("show");
    leftPanel.classList.remove("opaco");

    // Limpiar campos
    if (correoInput) correoInput.value = "";
    if (mensajeExito) mensajeExito.style.display = "none";
  });
}

// Enviar correo Recuperar
const recuperarForm = document.getElementById("recuperarForm");
if (recuperarForm) {
  recuperarForm.addEventListener("submit", async function(e) {
    e.preventDefault();

    const correo = correoInput ? correoInput.value.trim() : "";

    try {
      const response = await fetch('http://127.0.0.1:5050/enviar_codigo', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ correo })
      });


      const data = await response.json();

      if (data.success) {
        correoRecuperacion = correo;
        if (mensajeExito) mensajeExito.style.display = "block";

        setTimeout(() => {
          modalRecuperar.classList.remove("show");
          if (mensajeExito) mensajeExito.style.display = "none";
          if (correoInput) correoInput.value = "";

          if (codigoInput) codigoInput.value = "";
          if (mensajeCodigoError) mensajeCodigoError.style.display = "none";
          if (mensajeCodigoExito) mensajeCodigoExito.style.display = "none";

          modalVerificar.classList.add("show");
          if (codigoInput) codigoInput.focus();
        }, 2500);
      } else {
        alert(data.error || "No se pudo enviar el código. Intenta más tarde.");
      }

    } catch (error) {
      console.error("Error al enviar solicitud:", error);
      alert("Error al conectar con el servidor.");
    }
  });
}

// Cerrar modal Verificar
if (cerrarModalVerificar) {
  cerrarModalVerificar.addEventListener("click", () => {
    modalVerificar.classList.remove("show");
    leftPanel.classList.remove("opaco");

    // Limpiar campos
    if (codigoInput) codigoInput.value = "";
    if (mensajeCodigoError) mensajeCodigoError.style.display = "none";
    if (mensajeCodigoExito) mensajeCodigoExito.style.display = "none";
  });
}

// Verificar código
if (verificarForm) {
  verificarForm.addEventListener("submit", async function(e) {
    e.preventDefault();

    const codigoIngresado = codigoInput ? codigoInput.value.trim() : "";
    const correo = correoRecuperacion;


    if (!codigoIngresado || !correo) {
      alert("Por favor ingresa el código y correo.");
      return;
    }

    // Reiniciar mensajes
    if (mensajeCodigoExito) mensajeCodigoExito.style.display = "none";
    if (mensajeCodigoError) mensajeCodigoError.style.display = "none";

    try {
      const response = await fetch(`${BASE_URL}/verificar_codigo`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ correo, codigo: codigoIngresado })
      });

      const data = await response.json();

      if (data.success) {
        if (mensajeCodigoExito) mensajeCodigoExito.style.display = "block";

        setTimeout(() => {
          modalVerificar.classList.remove("show");
          modalVerificar.setAttribute && modalVerificar.setAttribute('aria-hidden','true');
          if (mensajeCodigoExito) mensajeCodigoExito.style.display = "none";
          if (codigoInput) codigoInput.value = "";

          if (modalCambioClave) {
            modalCambioClave.classList.add("show");
            modalCambioClave.setAttribute && modalCambioClave.setAttribute('aria-hidden','false');
          }
          if (leftPanel) leftPanel.classList.add("opaco");

          if (nuevaClaveInput) {
            nuevaClaveInput.value = "";
            setTimeout(() => nuevaClaveInput.focus(), 50);
          }
          if (confirmarClaveInput) confirmarClaveInput.value = "";
          if (mensajeCambioError) mensajeCambioError.style.display = "none";
          if (mensajeCambioExito) mensajeCambioExito.style.display = "none";
        }, 2800);

      } else {
        if (mensajeCodigoError) mensajeCodigoError.style.display = "block";
        if (codigoInput) {
          codigoInput.value = "";
          codigoInput.focus();
        }
        setTimeout(() => {
          if (mensajeCodigoError) mensajeCodigoError.style.display = "none";
        }, 2500);
      }
    } catch (error) {
      console.error("Error al verificar código:", error);
      alert("Error del servidor. Intenta más tarde.");
    }
  });
}

// Cerrar modal Cambio de contraseña
if (cerrarModalCambio) {
  cerrarModalCambio.addEventListener("click", () => {
    if (modalCambioClave) {
      modalCambioClave.classList.remove("show");
      modalCambioClave.setAttribute && modalCambioClave.setAttribute('aria-hidden','true');
    }
    if (leftPanel) leftPanel.classList.remove("opaco");

    // limpiar campos y mensajes
    if (nuevaClaveInput) nuevaClaveInput.value = "";
    if (confirmarClaveInput) confirmarClaveInput.value = "";
    if (mensajeCambioError) mensajeCambioError.style.display = "none";
    if (mensajeCambioExito) mensajeCambioExito.style.display = "none";

    if (requisitosDiv) requisitosDiv.innerHTML = '';
  });
}

// Función que devuelve estado de requisitos
function validarRequisitos(pass) {
  return {
    length: pass.length >= 8,
    uppercase: /[A-Z]/.test(pass),
    lowercase: /[a-z]/.test(pass),
    digit: /\d/.test(pass),
    special: /[!@#\$%\^&\*\(\)\-_=\+\[\]\{\};:'",\.<>\/\?\\|`~]/.test(pass)
  };
}

// Actualiza la lista visible de requisitos
function actualizarRequisitos(pass) {
  if (!requisitosDiv) return;
  const r = validarRequisitos(pass || "");
  const items = [
    { key: 'length', text: 'Al menos 8 caracteres' },
    { key: 'uppercase', text: 'Al menos una letra MAYÚSCULA' },
    { key: 'lowercase', text: 'Al menos una letra minúscula' },
    { key: 'digit', text: 'Al menos un número' },
    { key: 'special', text: 'Al menos un carácter especial (!@#... )' }
  ];
  const ul = document.createElement('ul');
  items.forEach(it => {
    const li = document.createElement('li');
    if (r[it.key]) li.classList.add('ok');
    li.textContent = it.text;
    ul.appendChild(li);
  });
  requisitosDiv.innerHTML = "";
  requisitosDiv.appendChild(ul);
}

// Listener en tiempo real
if (nuevaClaveInput) {
  nuevaClaveInput.addEventListener('input', (e) => {
    const val = e.target.value;
    actualizarRequisitos(val);
    if (mensajeCambioError) mensajeCambioError.style.display = 'none';
  });
}

// Limpiar requisitos al abrir/cerrar modal cambio
if (modalCambioClave) {
  if (cerrarModalCambio) {
    cerrarModalCambio.addEventListener('click', () => {
      if (requisitosDiv) requisitosDiv.innerHTML = '';
    });
  }
}

// Modificar envío de cambio de contraseña: verificar requisitos además de coincidencia
if (cambioClaveForm) {
  cambioClaveForm.addEventListener("submit", async function (e) {
    e.preventDefault();

    const nueva = nuevaClaveInput ? nuevaClaveInput.value.trim() : "";
    const confirmar = confirmarClaveInput ? confirmarClaveInput.value.trim() : "";

    const req = validarRequisitos(nueva);
    const allOk = req.length && req.uppercase && req.lowercase && req.digit && req.special;

    actualizarRequisitos(nueva);

    if (!allOk) {
      if (mensajeCambioError) {
        mensajeCambioError.textContent = 'La contraseña no cumple todos los requisitos';
        mensajeCambioError.style.display = 'block';
      }
      nuevaClaveInput?.focus();
      setTimeout(() => {
        mensajeCambioError.style.display = 'none';
      }, 2500);
      return;
    }

    if (nueva !== confirmar) {
      if (mensajeCambioError) {
        mensajeCambioError.textContent = 'Las contraseñas no coinciden';
        mensajeCambioError.style.display = 'block';
      }
      nuevaClaveInput?.focus();
      setTimeout(() => {
        mensajeCambioError.style.display = 'none';
      }, 2500);
      return;
    }

    try {
      const response = await fetch(`${BASE_URL}/cambiar_clave`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          correo: correoRecuperacion,
          nueva_clave: nueva
        })
      });

      const data = await response.json();
      if (data.success) {
        modalCambioClave?.classList.remove("show");
        modalExitoso?.classList.add("show");
        leftPanel?.classList.add("opaco");

        nuevaClaveInput.value = "";
        confirmarClaveInput.value = "";
        requisitosDiv.innerHTML = '';
      } else {
        alert("Error al cambiar la contraseña: " + (data.error || "Intenta más tarde"));
      }

    } catch (error) {
      console.error("Error al enviar nueva contraseña:", error);
      alert("Error del servidor");
    }
  });
}


// Cerrar modalExitoso
if (cerrarModalExitoso) {
  cerrarModalExitoso.addEventListener("click", () => {
    if (modalExitoso) {
      modalExitoso.classList.remove("show");
      modalExitoso.setAttribute && modalExitoso.setAttribute('aria-hidden','true');
    }
    if (leftPanel) leftPanel.classList.remove("opaco");
  });
}

// Botón Iniciar sesión
if (iniciarSesionBtn) {
  iniciarSesionBtn.addEventListener("click", () => {
    window.location.href = "/";
  });
}


document.querySelectorAll('.input-group .eye-icon').forEach(icon => {
  const parent = icon.parentElement;
  if (!parent) return;
  const input = parent.querySelector('input[type="password"], input[type="text"]');
  if (!input) return;

  icon.addEventListener('click', () => {
    const isPassword = input.getAttribute('type') === 'password';
    input.setAttribute('type', isPassword ? 'text' : 'password');
    icon.classList.toggle('eye-closed', isPassword);
  });

  icon.tabIndex = 0;
  icon.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      icon.click();
    }
  });
});


// Manejo AJAX del formulario de login
(function(){
  const loginForm = document.getElementById('loginForm');
  const usuario = document.getElementById('usuario');
  const password = document.getElementById('password');
  const rol = document.getElementById('rol');
  const mensajeLogin = document.getElementById('mensajeLogin');
  const btn = loginForm ? loginForm.querySelector('button[type="submit"]') : null;

  if (!loginForm || !mensajeLogin) return;

  function showMessage(text, type = 'error') {
    mensajeLogin.style.display = 'block';
    mensajeLogin.className = type === 'error' ? 'mensaje-error' : 'mensaje-exito';
    mensajeLogin.textContent = text;
  }
  function hideMessage() {
    mensajeLogin.style.display = 'none';
    mensajeLogin.textContent = '';
  }

  async function fetchWithTimeout(resource, options = {}) {
    const { timeout = 8000 } = options;
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeout);
    try {
      const response = await fetch(resource, { ...options, signal: controller.signal });
      clearTimeout(id);
      return response;
    } catch (err) {
      clearTimeout(id);
      throw err;
    }
  }

  loginForm.addEventListener('submit', async function(e){
    e.preventDefault();
    hideMessage();

    const u = usuario?.value.trim() || '';
    const p = password?.value.trim() || '';
    const r = rol?.value || '';

    if (!u) return showMessage('Complete el correo institucional.');
    if (!p) return showMessage('Complete la contraseña.');
    if (!r) return showMessage('Seleccione un rol.');

    if (btn) {
      btn.disabled = true;
      btn.textContent = 'Ingresando...';
    }

    try {
      const resp = await fetchWithTimeout('/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ correo: u, clave: p, rol: r }),
        timeout: 10000
      });

      const data = await resp.json();

      if (resp.ok && data.success) {
        // ✅ Inicio de sesión exitoso
        showMessage(data.message || 'Inicio de sesión exitoso', 'success');

        const nombre = data.nombre || u;
        localStorage.setItem('usuario', nombre);
        localStorage.setItem('rol', r);

        setTimeout(() => {
          window.location.href = '/Calendario';
        }, 1000);
      } else {
        showMessage(data.error || 'Credenciales incorrectas.');
      }
    } catch (err) {
      showMessage('Error de conexión con el servidor.');
      console.error('Error en login:', err);
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = 'Ingresar';
      }
    }
  });
})();

// --- Limpiar campos si vuelve atrás (sin borrar sesión) ---
window.addEventListener('pageshow', function (event) {
  const isBackOrForward = event.persisted || performance.getEntriesByType('navigation')[0]?.type === 'back_forward';

  if (isBackOrForward) {
    const usuarioInput = document.getElementById('usuario');
    const passwordInput = document.getElementById('password');
    const rolSelect = document.getElementById('rol');
    const mensaje = document.getElementById('mensaje');
    const mensajeLogin = document.getElementById('mensajeLogin');

    if (usuarioInput) usuarioInput.value = '';
    if (passwordInput) passwordInput.value = '';
    if (rolSelect) rolSelect.selectedIndex = 0;
    if (mensaje) mensaje.style.display = 'none';
    if (mensajeLogin) mensajeLogin.style.display = 'none';
  }
});


