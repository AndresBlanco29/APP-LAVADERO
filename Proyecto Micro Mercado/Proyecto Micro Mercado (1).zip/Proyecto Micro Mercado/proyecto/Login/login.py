import tkinter as tk
from tkinter import ttk
from tkinter import messagebox as mb
from usuarios import *
import ventas
import os
import usuarios

class login:
    def __init__(self):

        self.login = tk.Tk()

        self.login.title("Inicio de sesión")

        self.login.geometry("474x600")
        
        self.center_window(474, 600)

        self.items()

        self.login.mainloop()
        

    def center_window(self, width, height):

        screen_width = self.login.winfo_screenwidth()
        screen_height = self.login.winfo_screenheight()

        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)

        self.login.geometry(f'{width}x{height}+{x}+{y}')

    def items(self):
    
        self.ancho_ventana = 474
        self.alto_ventana = 600

        ruta_imagen = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'login.png')
        print(f"Cargando imagen desde: {ruta_imagen}")  # Debug
        self.img_login = tk.PhotoImage(file=ruta_imagen)

        img_ancho = self.img_login.width()
        img_alto = self.img_login.height()

        self.canvas1 = tk.Canvas(self.login, width=self.ancho_ventana, height=self.alto_ventana)
        self.canvas1.grid(row=0, column=0, columnspan=2, rowspan=5)  

        img_x = (self.ancho_ventana // 2) - (img_ancho // 2)
        img_y = (self.alto_ventana // 2) - (img_alto // 2)

        self.canvas1.create_image(img_x, img_y, anchor="nw", image=self.img_login)

        self.caja_usuario = tk.Entry(self.login, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=23, font=("Arial", 14))

        self.caja_usuario.place(x=171, y=328)
        
        self.caja_usuario.focus()

        self.caja_contraseña = tk.Entry(self.login, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=23, font=("Arial", 14))

        self.caja_contraseña.place(x=171, y=400)

        self.boton_login = tk.Button(self.login, text="Entrar", font=("Arial", 14), command=self.validar_login, background="#171d74", fg="white", width=16)

        self.boton_login.place(x=153, y=503)

    def validar_login(self):

        usuario = self.caja_usuario.get()

        contraseña = self.caja_contraseña.get()

        if usuarios.usuarios.ValidacionUsuarios(usuario, contraseña):
            mb.showinfo("Éxito", "Bienvenido")
            self.login.destroy()
            ventas.ventas(usuario) 
        else:
            mb.showerror("Error", "Usuario o contraseña incorrectos")

login()
