import pymysql

class FormularioLogin:
    def conexion_base_de_datos():
        try:
            conex = pymysql.connect(
                user="root", 
                password="", 
                host="localhost", 
                port=3306, 
                database="proyecto_micro_mercado"
            )
            print("Conexión establecida")
            return conex
        except pymysql.MySQLError as error:
            print("Error al conectar a la base de datos: {}".format(error))
            return None

FormularioLogin.conexion_base_de_datos()
