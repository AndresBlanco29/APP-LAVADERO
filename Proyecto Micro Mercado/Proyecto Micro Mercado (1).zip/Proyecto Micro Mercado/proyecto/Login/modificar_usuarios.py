import tkinter as tk
from tkinter import ttk
from tkinter import messagebox as mb
from Consultas import *
import os

class modificar_usuarios:
    def __init__(self, usuario_data):
        
        self.usuario_data = usuario_data
        

        self.modi_usuarios = tk.Toplevel()


        self.modi_usuarios.title("Modificar Usuarios")

   
        self.modi_usuarios.geometry("652x650")
        
        self.center_window(652, 650)

  
        self.items()

  
        self.modi_usuarios.mainloop()


    def center_window(self, width, height):
      
        screen_width = self.modi_usuarios.winfo_screenwidth()
        screen_height = self.modi_usuarios.winfo_screenheight()

     
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)

        
        self.modi_usuarios.geometry(f'{width}x{height}+{x}+{y}')

    def items(self):
    
        self.ancho_ventana = 652
        self.alto_ventana = 650
        
        ruta_imagen = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'modificar_usuarios.png')
        print(f"Cargando imagen desde: {ruta_imagen}") 
        self.img_modi_usu = tk.PhotoImage(file=ruta_imagen)

    
        img_ancho = self.img_modi_usu.width()
        img_alto = self.img_modi_usu.height()

      
        self.canvas1 = tk.Canvas(self.modi_usuarios, width=self.ancho_ventana, height=self.alto_ventana)
        self.canvas1.grid(row=0, column=0, columnspan=2, rowspan=5)  

     
        img_x = (self.ancho_ventana // 2) - (img_ancho // 2) -84
        img_y = (self.alto_ventana // 2) - (img_alto // 2) - 26

   
        self.canvas1.create_image(img_x, img_y, anchor="nw", image=self.img_modi_usu)
        
      
        self.modi_Id = tk.Entry(self.modi_usuarios, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=37, font=("Arial", 12))
        self.modi_Id.place(x=261, y=90)
        self.modi_Id.place_forget()
        self.modi_Id.insert(0, self.usuario_data[0])
        
        
    
        self.modi_nombre_usuario = tk.Entry(self.modi_usuarios, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=37, font=("Arial", 12))
        self.modi_nombre_usuario.place(x=261, y=176)
        self.modi_nombre_usuario.insert(0, self.usuario_data[1]) 
        
        self.modi_contraseña_usuario = tk.Entry(self.modi_usuarios, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=37, font=("Arial", 12))
        self.modi_contraseña_usuario.place(x=256, y=265)
        self.modi_contraseña_usuario.insert(0, self.usuario_data[2])
        
        self.modi_Nombre = tk.Entry(self.modi_usuarios, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=37, font=("Arial", 12))
        self.modi_Nombre.place(x=261, y=365)
        self.modi_Nombre.insert(0, self.usuario_data[3])
        
        self.modi_numero = tk.Entry(self.modi_usuarios, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=37, font=("Arial", 12))
        self.modi_numero.place(x=261, y=450)
        self.modi_numero.insert(0, self.usuario_data[4])
        
        # Creamos el botón para guardar y lo ubicamos
        self.borde_modificar_usuario = tk.Frame(self.modi_usuarios, background="white", bd=2)
        self.borde_modificar_usuario.place(x=206, y=569)
        self.modi_usuario = tk.Button(self.borde_modificar_usuario, text="Modificar Usuario", background="#131861", font=("Arial", 14, "bold"), foreground="White", command=self.modificar_usuario, width=20)
        self.modi_usuario.pack()
        
    def modificar_usuario(self):
        try:
            codigo = self.modi_Id.get()
            usuario = self.modi_nombre_usuario.get()
            password = self.modi_contraseña_usuario.get()
            nombre_empleado = self.modi_Nombre.get()
            telefono = self.modi_numero.get()
            
            if not all([codigo, usuario, password, nombre_empleado, telefono]):
                mb.showwarning("Advertencia","Todos los campos son obligatorios", parent = self.modi_usuarios)
                return
            
            personal_modi = modificar_personal(usuario, password, nombre_empleado, telefono, codigo)
            
            if personal_modi:
                mb.showinfo("Exito", "Los datos han sido modificado correctamente", parent = self.modi_usuarios)
                self.limpiar_cajas()
                
        except ValueError as error:
            mb.showerror("Error", "Error al modificar los datos {}".format(error), parent = self.modi_usuarios)
            
    def limpiar_cajas(self):
        
        self.modi_Id.delete(0, tk.END)
        self.modi_nombre_usuario.delete(0, tk.END)
        self.modi_contraseña_usuario.delete(0, tk.END)
        self.modi_Nombre.delete(0, tk.END)
        self.modi_numero.delete(0, tk.END)
    
#modificar_usuarios()