import tkinter as tk
from tkinter import ttk
from tkinter import messagebox as mb
from Consultas import *
import os

class Proveedores:
    def __init__(self):
        
        
        self.proveedor = tk.Toplevel()

      
        self.proveedor.title("Proveedores")

      
        self.proveedor.geometry("1050x720")
        
       
        self.proveedor.bind("<Motion>", self.mostrar_coordenadas)

       
        self.center_window(1050, 720)

        
        self.items()

        
        self.proveedor.mainloop()
        
    def mostrar_coordenadas(self, event):
        print(f"Coordenadas: {event.x}, {event.y}")

    def center_window(self, width, height):
        
        screen_width = self.proveedor.winfo_screenwidth()
        screen_height = self.proveedor.winfo_screenheight()

       
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)

       
        self.proveedor.geometry(f'{width}x{height}+{x}+{y}')

    def items(self):
       
        self.ancho_ventana = 1050
        self.alto_ventana = 720
        
        ruta_imagen = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'proveedores.png')
        print(f"Cargando imagen desde: {ruta_imagen}")  # Debug
        self.img_proovedores = tk.PhotoImage(file=ruta_imagen)

        
        img_ancho = self.img_proovedores.width()
        img_alto = self.img_proovedores.height()

       
        self.canvas1 = tk.Canvas(self.proveedor, width=self.ancho_ventana, height=self.alto_ventana)
        self.canvas1.grid(row=0, column=0, columnspan=2, rowspan=5)  

    
        img_x = (self.ancho_ventana // 2) - (img_ancho // 2) -60
        img_y = (self.alto_ventana // 2) - (img_alto // 2) 

        self.canvas1.create_image(img_x, img_y, anchor="nw", image=self.img_proovedores)
        
   
        self.tree_proveedor = ttk.Treeview(self.proveedor, columns=("NIT", "Razon_Social", "Telefono", "Direccion"), show="headings")
        self.tree_proveedor.column("# 1", anchor="center", width=140)
        self.tree_proveedor.heading("# 1", text="NIT")
        self.tree_proveedor.column("# 2", anchor="center", width=170)
        self.tree_proveedor.heading("# 2", text="Razon_Social")
        self.tree_proveedor.column("# 3", anchor="center", width=140)
        self.tree_proveedor.heading("# 3", text="Telefono")
        self.tree_proveedor.column("# 4", anchor="center", width=140)
        self.tree_proveedor.heading("# 4", text="Direccion")
        
        for row in mostrar_proveedores():
            self.tree_proveedor.insert("", "end", values=row)
        
        self.tree_proveedor.place(x=20, y=320)
        
      
        self.buscar_proveedores = tk.Entry(self.proveedor, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=37, font=("Arial", 12))
        self.buscar_proveedores.place(x=563, y=113)
        self.buscar_proveedores.focus()
        self.buscar_proveedores.bind("<KeyRelease>", self.buscar)
      
        self.NIT_proveedores = tk.Entry(self.proveedor, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=21, font=("Arial", 12))
        self.NIT_proveedores.place(x=825, y=273)
        
        
        self.nombre_proveedor = tk.Entry(self.proveedor, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=21, font=("Arial", 12))
        self.nombre_proveedor.place(x=825, y=333)
        
       
        self.telefono_proveedor = tk.Entry(self.proveedor, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=21, font=("Arial", 12))
        self.telefono_proveedor.place(x=825, y=396)
        
        
        self.direccion_proveedor = tk.Entry(self.proveedor, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=21, font=("Arial", 12))
        self.direccion_proveedor.place(x=825, y=459)
        
        
        self.borde_borrar_campos = tk.Frame(self.proveedor, background="white", bd=2)
        self.borde_borrar_campos.place(x=733, y=511)
       
        self.borrar_campos = tk.Button(self.borde_borrar_campos, text="Borrar Campos", background="#131861", font=("Arial", 12, "bold"), foreground="White", command=self.borrar_campos_proveedores, width=20)
        self.borrar_campos.pack()
        
        
        self.borde_agregar_proveedor = tk.Frame(self.proveedor, background="white", bd=2)
        self.borde_agregar_proveedor.place(x=652, y=580)
        
        
        self.agregar_proveedor = tk.Button(self.borde_agregar_proveedor, text="Agregar", background="#131861", font=("Arial", 12, "bold"), foreground="White", command=self.agregar_pro, width=10)
        self.agregar_proveedor.pack()
        
       
        self.borde_modificar_proveedor = tk.Frame(self.proveedor, background="white", bd=2)
        self.borde_modificar_proveedor.place(x=786, y=580)
        
        
        self.modificar_proveedor = tk.Button(self.borde_modificar_proveedor, text="Modificar", background="#131861", font=("Arial", 12, "bold"), foreground="White", command=self.modi_prove, width=10)
        self.modificar_proveedor.pack()
        
       
        self.borde_eliminar_proveedor = tk.Frame(self.proveedor, background="white", bd=2)
        self.borde_eliminar_proveedor.place(x=912, y=580)
        
     
        self.eliminar_proveedor = tk.Button(self.borde_eliminar_proveedor, text="Eliminar", background="#131861", font=("Arial", 12, "bold"), foreground="White", command=self.eliminar_prove, width=10)
        self.eliminar_proveedor.pack()
        

        self.tree_proveedor.bind("<<TreeviewSelect>>", self.obtener_datos)
        
    def buscar(self, event = None):
        try:
            buscado = self.buscar_proveedores.get().lower()
            self.tree_proveedor.delete(*self.tree_proveedor.get_children())
            resultado = buscar_proveedor(buscado, buscado)
            
            for row in resultado:
                self.tree_proveedor.insert("", tk.END, values=row)
                
        except ValueError as error:
            mb.showerror("Error {}".format(error), parent = self.proveedor)
        
    def borrar_campos_proveedores(self):
        
        self.buscar_proveedores.delete(0, tk.END)
        self.NIT_proveedores.delete(0, tk.END)
        self.NIT_proveedores.focus()
        self.nombre_proveedor.delete(0, tk.END)
        self.telefono_proveedor.delete(0, tk.END)
        self.direccion_proveedor.delete(0, tk.END)
        
    
    def agregar_pro(self):
        try:
            NIT = self.NIT_proveedores.get()
            Nombre = self.nombre_proveedor.get()
            Telefono = self.telefono_proveedor.get()
            Direccion = self.direccion_proveedor.get()
            
            if not all ([NIT,Nombre, Telefono, Direccion]):
                mb.showwarning("Advertencia","Llene todos los campos", parent = self.proveedor)
                return
            if mb.askyesno("Confirmar", "Desea agregar un nuevo proveedor?", parent = self.proveedor):
                Agregar_Proveedor(NIT,Nombre, Telefono, Direccion)
                mb.showinfo("Exito","El proveedor se agrego correctamente", parent = self.proveedor)
            
            self.borrar_campos_proveedores()
            
            self.actualizar_tabla()
            
        except ValueError as error:
            mb.showerror("Error {}".format(error), parent = self.proveedor)
    
    def modi_prove(self):
        try:
            NIT = self.NIT_proveedores.get()
            Nombre = self.nombre_proveedor.get()
            Telefono = self.telefono_proveedor.get()
            Direccion = self.direccion_proveedor.get()
            
            seleccionado = self.tree_proveedor.selection()
            
            if not seleccionado:
                mb.showwarning("Advertencia", "Debe seleccionar un proveedor", parent = self.proveedor)
                return
            
            if seleccionado:
                pregunta = mb.askyesno("Confirmar", "Desea modificar los datos del proveedor", parent = self.proveedor)
            
            if pregunta:
                modificar_proveedor(Nombre, Telefono, Direccion, NIT)
                mb.showinfo("Exito", "Se han modificado correctamente los datos", parent = self.proveedor)
            
            self.borrar_campos_proveedores()
        
            self.actualizar_tabla()
        except ValueError as error:
            mb.showerror("Error {}".format(error), parent = self.proveedor)
    
    def eliminar_prove(self):
        
        seleccionado = self.tree_proveedor.selection()
        
        if not seleccionado:
            mb.showwarning("Advertencia","Debe seleccionar un proveedor", parent = self.proveedor)
            return
        if seleccionado:
            pregunta = mb.askyesno("Confirmar", "Desea eliminar el proveedor?", parent = self.proveedor)  
            
        if pregunta:  
            item = self.tree_proveedor.item(seleccionado, "values")
            NIT = item[0]
            eliminar_proveedor(NIT)
            mb.showinfo("Exito","Se ha eliminado correctamente el proveedor", parent = self.proveedor)
        
        self.borrar_campos_proveedores()
        
        self.actualizar_tabla()
    
    def actualizar_tabla(self):
        try:
            self.tree_proveedor.delete(*self.tree_proveedor.get_children())
            
            resultados = mostrar_proveedores()
            
            for row in resultados:
                self.tree_proveedor.insert("", tk.END, values=row)
        except ValueError as error:
            mb.showerror("Error {}".format(error), parent = self.proveedor)
            
    def obtener_datos(self, event=None):
        seleccionado = self.tree_proveedor.selection()
        
        if not seleccionado:
            self.tree_proveedor.delete(0, tk.END)
        if seleccionado:
            item = self.tree_proveedor.item(seleccionado, "values")
            
            NIT = item[0]
            self.NIT_proveedores.delete(0, tk.END)
            self.NIT_proveedores.insert(0, NIT)
            
            Nombre = item[1]
            self.nombre_proveedor.delete(0, tk.END)
            self.nombre_proveedor.insert(0, Nombre)
            
            Telefono = item[2]
            self.telefono_proveedor.delete(0, tk.END)
            self.telefono_proveedor.insert(0, Telefono)
            
            Direccion = item[3]
            self.direccion_proveedor.delete(0, tk.END)
            self.direccion_proveedor.insert(0, Direccion)
#Proveedores()