import tkinter as tk
from tkinter import ttk
from tkinter import messagebox as mb
from Consultas import *
import os
import usuarios
from datetime import datetime


class entrada_dinero:
    def __init__(self, usuario):
        
        self.usuario = usuario
        
 
        self.entrada_dinero = tk.Toplevel()

 
        self.entrada_dinero.title("Entrada de dinero")

        self.entrada_dinero.geometry("633x341")
 
        self.entrada_dinero.bind("<Motion>", self.mostrar_coordenadas)

        self.center_window(633, 341)

      
        self.items()

        self.entrada_dinero.mainloop()
        
    def mostrar_coordenadas(self, event):
        print(f"Coordenadas: {event.x}, {event.y}")

    def center_window(self, width, height):
   
        screen_width = self.entrada_dinero.winfo_screenwidth()
        screen_height = self.entrada_dinero.winfo_screenheight()

   
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)

     
        self.entrada_dinero.geometry(f'{width}x{height}+{x}+{y}')

    def items(self):
      
        self.ancho_ventana = 633
        self.alto_ventana = 341
        
        ruta_imagen = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'Entrada.png')
        print(f"Cargando imagen desde: {ruta_imagen}")  
        self.img_entrada = tk.PhotoImage(file=ruta_imagen)

        img_ancho = self.img_entrada.width()
        img_alto = self.img_entrada.height()

     
        self.canvas1 = tk.Canvas(self.entrada_dinero, width=self.ancho_ventana, height=self.alto_ventana)
        self.canvas1.grid(row=0, column=0, columnspan=2, rowspan=5) 

      
        img_x = (self.ancho_ventana // 2) - (img_ancho // 2) - 17
        img_y = (self.alto_ventana // 2) - (img_alto // 2) + 25

        
        self.canvas1.create_image(img_x, img_y, anchor="nw", image=self.img_entrada)
        
        self.cantidad_dinero = tk.Entry(self.entrada_dinero, validate="key", validatecommand=(self.entrada_dinero.register(self.validar_numero), "%P"), highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=13, font=("Arial", 12))
        self.cantidad_dinero.place(x=49, y=154)
        
        self.comentarios = tk.Entry(self.entrada_dinero, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=40, font=("Arial", 12))
        self.comentarios.place(x=49, y=250)
        
        self.btn_guardar = tk.Button(self.entrada_dinero, text="Guardar", width=8, font=("Arial", 18, "bold"), background="#171d74", foreground="White", command=self.guardar_entrada)
        self.btn_guardar.place(x=463, y=110)
        
        self.btn_cancelar = tk.Button(self.entrada_dinero, text="Cancelar", width=8, font=("Arial", 18, "bold"), background="#171d74", foreground="White", command=self.cancelar)
        self.btn_cancelar.place(x=463, y=185)
        
    def validar_numero(self, texto):
        
        if texto == "" or texto.isdigit():
            return True
        else:
            return False
        
    def guardar_entrada(self):
        
        nombre_usuario = usuarios.usuarios.Obtener_Nombre_Empleado(self.usuario)
        cantidad = self.cantidad_dinero.get()
        comentarios = self.comentarios.get().strip()
        fecha_actual = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        if not cantidad or not comentarios:
            mb.showerror("Error", "Por favor, llene los campos", parent = self.entrada_dinero)
        else:
            mb.showinfo("Éxito", "Entrada de dinero guardada correctamente.", parent=self.entrada_dinero)
            Agregar_entrada_dinero(cantidad, comentarios, nombre_usuario, fecha_actual)
            self.cantidad_dinero.delete(0, tk.END)
            self.comentarios.delete(0, tk.END)
    
    def cancelar(self):
        pass
    
#entrada_dinero()