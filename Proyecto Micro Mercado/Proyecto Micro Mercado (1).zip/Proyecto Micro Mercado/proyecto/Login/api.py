from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List
from datetime import date
import mysql.connector

class Producto(BaseModel):
    Id_Producto:       int
    Nombre:            str
    Precio_Venta:      float
    Precio_Compra:     float
    Cantidad:          int
    Marca:             str
    Descripcion:       Optional[str]
    Categoria:         Optional[str]
    Fecha_Entrada:     Optional[date]
    Fecha_Vencimiento: Optional[date]
    Unidad_Medida:     Optional[str]
    Proveedor_ID:      Optional[int]
    Ubicacion_Estante: Optional[str]
    ubicacion_pasillo: Optional[str]
    Codigo_Barras:     Optional[str]

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   
    allow_methods=["*"],
    allow_headers=["*"],
)

def get_db():
    return mysql.connector.connect(
        host="localhost",
        user="api_user",
        password="solomessi10",
        database="proyecto_micro_mercado"
    )

@app.get("/api/productos", response_model=List[Producto])
def listar_productos(
    codigo_barras: Optional[str] = Query(None, alias="codigo_barras")
):
    """
    Si llamas /api/productos devuelve TODOS los productos.
    Si llamas /api/productos?codigo_barras=123 devuelve solo
    aquellos con Codigo_Barras = '123'.
    """
    db     = get_db()
    cursor = db.cursor(dictionary=True)
    
    if codigo_barras:
        sql = """
          SELECT 
            Id_Producto, Nombre, Precio_Venta, Precio_Compra,
            Cantidad, Marca, Descripcion, Categoria,
            Fecha_Entrada, Fecha_Vencimiento,
            Unidad_Medida, Proveedor_ID,
            Ubicacion_Estante, ubicacion_pasillo, Codigo_Barras
          FROM productos
          WHERE Codigo_Barras = %s
        """
        cursor.execute(sql, (codigo_barras,))
    else:
        sql = """
          SELECT 
            Id_Producto, Nombre, Precio_Venta, Precio_Compra,
            Cantidad, Marca, Descripcion, Categoria,
            Fecha_Entrada, Fecha_Vencimiento,
            Unidad_Medida, Proveedor_ID,
            Ubicacion_Estante, ubicacion_pasillo, Codigo_Barras
          FROM productos
        """
        cursor.execute(sql)

    filas = cursor.fetchall()
    cursor.close()
    db.close()
    return filas
