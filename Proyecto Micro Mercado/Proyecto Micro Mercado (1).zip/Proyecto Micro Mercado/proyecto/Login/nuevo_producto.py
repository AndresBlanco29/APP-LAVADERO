import tkinter as tk
from tkinter import ttk
from tkinter import messagebox as mb
import os

from PIL import Image, ImageTk
from Consultas import *  # Asegúrate de que esta importación funcione correctamente.

class nuevo_producto:
    def __init__(self):
        self.nuevo = tk.Toplevel()
        self.nuevo.title("Nuevo Producto")
        self.nuevo.geometry("625x650")
        self.nuevo.bind("<Motion>", self.mostrar_coordenadas)
        self.center_window(625, 650)
        self.items()
        self.nuevo.mainloop()
        
    def mostrar_coordenadas(self, event):
        print(f"Coordenadas: {event.x}, {event.y}")

    def center_window(self, width, height):
        screen_width = self.nuevo.winfo_screenwidth()
        screen_height = self.nuevo.winfo_screenheight()
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)
        self.nuevo.geometry(f'{width}x{height}+{x}+{y}')

    def items(self):
        self.ancho_ventana = 625
        self.alto_ventana = 650
        
        ruta_imagen = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'nuevo_producto.png')
        self.img_nuevo_p = tk.PhotoImage(file=ruta_imagen)

        img_ancho = self.img_nuevo_p.width()
        img_alto = self.img_nuevo_p.height()

        self.canvas1 = tk.Canvas(self.nuevo, width=self.ancho_ventana, height=self.alto_ventana)
        self.canvas1.grid(row=0, column=0, columnspan=2, rowspan=5)

        img_x = (self.ancho_ventana // 2) - (img_ancho // 2) + 77
        img_y = (self.alto_ventana // 2) - (img_alto // 2) + 10
        self.canvas1.create_image(img_x, img_y, anchor="nw", image=self.img_nuevo_p)

    
        self.codigo = tk.Entry(self.nuevo, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=29, font=("Arial", 12), state="readonly")
        self.codigo.place(x=277, y=101)
        
        self.nombre_producto = tk.Entry(self.nuevo, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=29, font=("Arial", 12))
        self.nombre_producto.place(x=277, y=167)
        
        self.precio_compra_producto = tk.Entry(self.nuevo, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=29, font=("Arial", 12))
        self.precio_compra_producto.place(x=277, y=233)
        
        self.precio_venta_producto = tk.Entry(self.nuevo, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=29, font=("Arial", 12))
        self.precio_venta_producto.place(x=277, y=299)
        
        self.cantidad_producto = tk.Entry(self.nuevo, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=29, font=("Arial", 12))
        self.cantidad_producto.place(x=277, y=363)
        
        self.marca_producto = tk.Entry(self.nuevo, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=29, font=("Arial", 12))
        self.marca_producto.place(x=277, y=429)

        self.borde_guardar = tk.Frame(self.nuevo, background="white", bd=2)
        self.borde_guardar.place(x=60, y=493)
        
        self.guardar = tk.Button(self.borde_guardar, text="Guardar", background="#d17100", font=("Arial", 14, "bold"), foreground="black", command=self.guardar_producto, width=40)
        self.guardar.pack()
        
        self.borde_cancelar = tk.Frame(self.nuevo, background="white", bd=2)
        self.borde_cancelar.place(x=60, y=570)
        
        self.cancelar = tk.Button(self.borde_cancelar, text="Cancelar", background="#e51400", font=("Arial", 14, "bold"), foreground="black", command=self.cancelar_nuevo, width=40)
        self.cancelar.pack()

    

    def guardar_producto(self):
        try:
            codigo_producto = self.codigo.get()
            Nombre = self.nombre_producto.get()
            precio_venta = self.precio_venta_producto.get()
            precio_compra = self.precio_compra_producto.get()
            cantidad = self.cantidad_producto.get()
            marca = self.marca_producto.get()
            
            if not all([codigo_producto, Nombre, precio_venta, precio_compra, cantidad, marca]):
                mb.showwarning("Advertencia", "Llene todos los campos", parent=self.nuevo)
                return
            
     
            Agregar_Producto(Nombre, precio_venta, precio_compra, cantidad, marca)
            mb.showinfo("Éxito", "El producto se agregó correctamente", parent=self.nuevo)

                
        except ValueError as error:
            mb.showerror("Error al agregar el producto: {}".format(error), parent=self.nuevo)

    def cancelar_nuevo(self):
        pregunta = mb.askyesno("Advertencia", "¿Desea cancelar el proceso?", parent=self.nuevo)
        if pregunta:
            self.nuevo.destroy()


