from conexionLogin import *
import mysql.connector


class usuarios():
    
    def ValidacionUsuarios(usuario, contraseña):
        try:
            cone = FormularioLogin.conexion_base_de_datos()
            cursor = cone.cursor()
            query = "SELECT * FROM usuarios WHERE Usuario = %s AND Contraseña = %s"
            cursor.execute(query, (usuario, contraseña))
            resultado = cursor.fetchall()
            cone.close()
            if resultado:
                return True
            else:
                return False
            
            
        except mysql.connector.Error as error:
            print("Error al conectar la base de datos {}".format(error))
            
    def Obtener_Nombre_Empleado(Usuario):
        try:
            cone = FormularioLogin.conexion_base_de_datos()
            cursor = cone.cursor()
            
           
            query = """
                SELECT e.Nombres 
                FROM usuarios u
                JOIN empleados e ON u.Empleados_Id_Empleados = e.Id_empleados
                WHERE u.Usuario = %s
            """
            cursor.execute(query, (Usuario,))
            resultado = cursor.fetchone()
            
            cursor.close()
            cone.close()  
            
            if resultado:
                return resultado[0]  
            
            return None  

        except mysql.connector.Error as error:
            print(f"Error al conectar a la base de datos: {error}")
            return None  

    def Obtener_Id_Empleado(Usuario):
        try:
            cone = FormularioLogin.conexion_base_de_datos()
            cursor = cone.cursor()
            
           
            query = "SELECT Empleados_Id_Empleados FROM usuarios WHERE Usuario = %s"
            cursor.execute(query, (Usuario,))
            resultado = cursor.fetchone()
            
            cursor.close()
            cone.close()  
            
            if resultado:
                return resultado[0]  
            
            return None  

        except mysql.connector.Error as error:
            print(f"Error al conectar a la base de datos: {error}")
            return None  



            