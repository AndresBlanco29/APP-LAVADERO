from tkinter import ttk
from tkinter import messagebox as mb
from tkcalendar import *
from tkcalendar import DateEntry
from datetime import *
from Consultas import *
import os
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet

class R_Ventas:
    def __init__(self):
        self.R_Venta = tk.Toplevel()
        self.R_Venta.title("Reporte de Ventas")
        self.R_Venta.geometry("1050x720")
        self.R_Venta.bind("<Motion>", self.mostrar_coordenadas)
        self.center_window(1050, 720)
        self.items()
        self.R_Venta.mainloop()
        
    def mostrar_coordenadas(self, event):
        print(f"Coordenadas: {event.x}, {event.y}")

    def center_window(self, width, height):
        screen_width = self.R_Venta.winfo_screenwidth()
        screen_height = self.R_Venta.winfo_screenheight()
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)
        self.R_Venta.geometry(f'{width}x{height}+{x}+{y}')

    def items(self):
        self.ancho_ventana = 1050
        self.alto_ventana = 720
        
        ruta_imagen = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'R_ventas.png')
        print(f"Cargando imagen desde: {ruta_imagen}")
        self.img_R_Venta = tk.PhotoImage(file=ruta_imagen)
        img_ancho = self.img_R_Venta.width()
        img_alto = self.img_R_Venta.height()
        self.canvas1 = tk.Canvas(self.R_Venta, width=self.ancho_ventana, height=self.alto_ventana)
        self.canvas1.grid(row=0, column=0, columnspan=2, rowspan=5)
        img_x = (self.ancho_ventana // 2) - (img_ancho // 2) - 60
        img_y = (self.alto_ventana // 2) - (img_alto // 2)
        self.canvas1.create_image(img_x, img_y, anchor="nw", image=self.img_R_Venta)
        
        self.tree_ventas = ttk.Treeview(self.R_Venta, columns=("Id_Venta", "Fecha", "Producto", "Cantidad", "Subtotal"), show="headings")
        self.tree_ventas.column("#1", anchor="center", width=160)
        self.tree_ventas.heading("#1", text="Id_Venta")
        self.tree_ventas.column("#2", anchor="center", width=200)
        self.tree_ventas.heading("#2", text="Fecha")
        self.tree_ventas.column("#3", anchor="center", width=200)
        self.tree_ventas.heading("#3", text="Producto")
        self.tree_ventas.column("#4", anchor="center", width=200)
        self.tree_ventas.heading("#4", text="Cantidad")
        self.tree_ventas.column("#5", anchor="center", width=200)
        self.tree_ventas.heading("#5", text="Subtotal")
        self.tree_ventas.place(x=44, y=220, height=240)
        
        for row in mostrar_R_Ventas():
            self.tree_ventas.insert("", "end", values=row)
        
        self.buscar_venta = tk.Entry(self.R_Venta, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=32, font=("Arial", 12))
        self.buscar_venta.place(x=444, y=139)
        self.buscar_venta.bind("<KeyRelease>", self.buscar_venta_codigo)
        
        self.fecha_desde = DateEntry(self.R_Venta, width=21, background='darkblue', foreground='white', borderwidth=2, year=2024, font=("Arial", 12, "bold"), locale='es_ES')
        self.fecha_desde.place(x=369, y=175)
        
        self.fecha_hasta = DateEntry(self.R_Venta, width=21, background='darkblue', foreground='white', borderwidth=2, year=2024, font=("Arial", 12, "bold"), locale='es_ES')
        self.fecha_hasta.place(x=638, y=175)
        
        self.buscar_btn = tk.Button(self.R_Venta, text="Buscar", command=self.buscar_ventas_Fecha)
        self.buscar_btn.place(x=800, y=139)
        
        self.reporte_inventario = tk.Button(self.R_Venta, text="Generar Reporte Total", background="#131861", font=("Arial", 11, "bold"), foreground="White", command=self.generar_reporte)
        self.reporte_inventario.place(x=118, y=620)
        
        self.reporte_inventario_diario = tk.Button(self.R_Venta, text="Generar Reporte diario", background="#131861", font=("Arial", 11, "bold"), foreground="White", command=self.generar_reporte_diario)
        self.reporte_inventario_diario.place(x=600, y=620)
        
        self.fecha_seleccionada = DateEntry(self.R_Venta, width=21, background='darkblue', foreground='white', borderwidth=2, year=2024, font=("Arial", 10, "bold"), locale='es_ES')
        self.fecha_seleccionada.place(x=600, y=470)
        
    def buscar_ventas_Fecha(self):
        fecha_inicio = self.fecha_desde.get_date().strftime('%Y-%m-%d')
        fecha_fin = self.fecha_hasta.get_date().strftime('%Y-%m-%d')
        if fecha_inicio == fecha_fin:
            fecha_fin = (self.fecha_hasta.get_date() + timedelta(days=1)).strftime('%Y-%m-%d')
        ventas = mostrar_venta_por_fecha(fecha_inicio, fecha_fin)
        if not ventas:
            mb.showinfo("Resultado", "No se encontraron ventas en este periodo.", parent=self.R_Venta)
            return
        for item in self.tree_ventas.get_children():
            self.tree_ventas.delete(item)
        for venta in ventas:
            self.tree_ventas.insert("", "end", values=venta)

    def buscar_venta_codigo(self, event=None):
        venta_buscada = self.buscar_venta.get()
        self.tree_ventas.delete(*self.tree_ventas.get_children())
        resultado = buscar_codigo_venta(venta_buscada)
        for row in resultado:
            self.tree_ventas.insert("", tk.END, values=row)

    def generar_reporte(self):
        ventas = [self.tree_ventas.item(item, "values") for item in self.tree_ventas.get_children()]
        if not ventas:
            mb.showinfo("Reporte", "No hay ventas para generar el reporte.", parent=self.R_Venta)
            return
        encabezados = ['ID Venta', 'Fecha', 'Producto', 'Cantidad', 'Subtotal']
        data = [encabezados] + ventas
        total_ventas = sum(float(venta[4]) for venta in ventas)
        
        pdf = SimpleDocTemplate("C:\\Users\\SENA\\Desktop\\proyecto\\reportes\\reporte_ventas.pdf", pagesize=letter)
        elementos = []
        estilos = getSampleStyleSheet()
        titulo = Paragraph("Reporte de Ventas", estilos['Title'])
        elementos.append(titulo)
        elementos.append(Paragraph("<br/><br/>", estilos['Normal']))
        tabla = Table(data)
        tabla.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ]))
        elementos.append(tabla)
        elementos.append(Paragraph(f"<br/>Total de ventas: {total_ventas:.2f}", estilos['Normal']))
        pdf.build(elementos)
        mb.showinfo("Reporte Generado", "El reporte de ventas se ha generado exitosamente como 'reporte_ventas.pdf'.", parent=self.R_Venta)

    def generar_reporte_diario(self):
        fecha_seleccionada = self.fecha_seleccionada.get_date().strftime('%Y-%m-%d')
        mb.showinfo("Prueba", f"Fecha seleccionada: {fecha_seleccionada}", parent=self.R_Venta)
        ventas_diarias = mostrar_venta_por_fecha_unica(fecha_seleccionada)
        print("Ventas diarias:", ventas_diarias)
        mb.showinfo("Prueba", f"Ventas diarias: {ventas_diarias}", parent=self.R_Venta)
        if not ventas_diarias:
            mb.showinfo("Reporte Diario", "No hay ventas registradas para la fecha seleccionada.", parent=self.R_Venta)
            return
        encabezados = ["ID Venta", "Fecha", "Producto", "Cantidad", "Subtotal"]
        ventas_diarias_list = list(ventas_diarias)
        data = [encabezados] + ventas_diarias_list
        total_ventas = sum(float(venta[4]) for venta in ventas_diarias)
        pdf = SimpleDocTemplate("C:\\Users\\SENA\\Desktop\\proyecto\\reportes\\reporte_diario.pdf", pagesize=letter)
        elementos = []
        estilos = getSampleStyleSheet()
        titulo = Paragraph(f"Reporte de Ventas - {fecha_seleccionada}", estilos['Title'])
        elementos.append(titulo)
        elementos.append(Paragraph("<br/><br/>", estilos['Normal']))
        tabla = Table(data)
        tabla.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ]))
        elementos.append(tabla)
        elementos.append(Paragraph(f"<br/>Total de ventas: {total_ventas:.2f}", estilos['Normal']))
        pdf.build(elementos)
        mb.showinfo("Reporte Diario Generado", f"El reporte diario se ha generado exitosamente como 'reporte_diario_{fecha_seleccionada}.pdf'.", parent=self.R_Venta)
