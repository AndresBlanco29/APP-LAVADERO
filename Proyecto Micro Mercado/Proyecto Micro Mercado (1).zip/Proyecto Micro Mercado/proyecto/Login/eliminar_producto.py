import tkinter as tk
from tkinter import ttk
from tkinter import messagebox as mb
import Consultas
import os

class Eliminar:
    def __init__(self):
        

        self.eliminar = tk.Toplevel()


        self.eliminar.title("Eliminar Producto")

  
        self.eliminar.geometry("652x650")
        
  
        self.eliminar.bind("<Motion>", self.mostrar_coordenadas)

 
        self.center_window(652, 650)

 
        self.items()


        self.eliminar.mainloop()
        
    def mostrar_coordenadas(self, event):
        print(f"Coordenadas: {event.x}, {event.y}")

    def center_window(self, width, height):
  
        screen_width = self.eliminar.winfo_screenwidth()
        screen_height = self.eliminar.winfo_screenheight()

    
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)

        self.eliminar.geometry(f'{width}x{height}+{x}+{y}')

    def items(self):
   
        self.ancho_ventana = 652
        self.alto_ventana = 650
        
        ruta_imagen = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'eliminar.png')
        print(f"Cargando imagen desde: {ruta_imagen}")  
        self.img_eliminar = tk.PhotoImage(file=ruta_imagen)

      
        img_ancho = self.img_eliminar.width()
        img_alto = self.img_eliminar.height()

  
        self.canvas1 = tk.Canvas(self.eliminar, width=self.ancho_ventana, height=self.alto_ventana)
        self.canvas1.grid(row=0, column=0, columnspan=2, rowspan=5)  

        img_x = (self.ancho_ventana // 2) - (img_ancho // 2) -84
        img_y = (self.alto_ventana // 2) - (img_alto // 2) - 26

    
        self.canvas1.create_image(img_x, img_y, anchor="nw", image=self.img_eliminar)
        
  
        self.tree_productos = ttk.Treeview(self.eliminar, columns=("Codigo", "Nombre", "Precio_de_venta", "Precio_de_Compra", "Cantidad", "Marca"), show="headings")
        self.tree_productos.column("# 1", anchor="center", width=90)
        self.tree_productos.heading("# 1", text="Codigo")
        self.tree_productos.column("# 2", anchor="center", width=140)
        self.tree_productos.heading("# 2", text="Nombre")
        self.tree_productos.column("# 3", anchor="center", width=100)
        self.tree_productos.heading("# 3", text="Precio_de_venta")
        self.tree_productos.column("# 4", anchor="center", width=110)
        self.tree_productos.heading("# 4", text="Precio_de_Compra")
        self.tree_productos.column("# 5", anchor="center", width=80)
        self.tree_productos.heading("# 5", text="Cantidad")
        self.tree_productos.column("# 6", anchor="center",width=110)
        self.tree_productos.heading("# 6", text="Marca")
    
        
        for row in Consultas.mostrar_Productos():
            self.tree_productos.insert("", "end", values=row)
        
        self.tree_productos.place(x=9, y=250)
        
    
        self.buscar_producto = tk.Entry(self.eliminar, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=37, font=("Arial", 12))
        self.buscar_producto.place(x=159, y=184)
        
        self.buscar_producto.focus()
        
    
        self.borde_guardar_cambios = tk.Frame(self.eliminar, background="white", bd=2)
        self.borde_guardar_cambios.place(x=216, y=569)
        
 
        self.eliminar_producto = tk.Button(self.borde_guardar_cambios, text="Eliminar Productos", background="#131861", font=("Arial", 14, "bold"), foreground="White", command=self.eliminar_productos, width=18)
        self.eliminar_producto.pack()
        
    def eliminar_productos(self):
        try:
            Codigo = self.buscar_producto.get()
            
            producto_seleccionado = self.tree_productos.selection()
            
            if not Codigo and not producto_seleccionado:
                mb.showwarning("Advertencia", "Debe ingresar el código del producto o seleccionar un producto en la tabla.", parent = self.eliminar)
                return
            
            
            if not Codigo and producto_seleccionado:
                
                codigo = self.tree_productos.item(producto_seleccionado[0], "values")[0]
                confirmacion = mb.askyesno("Confirmación", f"¿Está seguro de que desea eliminar el producto con código: {codigo}?", parent=self.eliminar)
                
                if not confirmacion:
                    return
                
                producto_eliminado = Consultas.eliminar_producto(codigo)
                
                if producto_eliminado:
                    mb.showinfo("Éxito", "Producto eliminado correctamente.", parent=self.eliminar)
                    
                    if producto_seleccionado:
                        self.tree_productos.delete(producto_seleccionado[0])
                        
                    else:
                        mb.showerror("Error", "No se pudo eliminar el producto. Verifique el código ingresado.", parent=self.eliminar)
                
        except ValueError as error:
            mb.showerror("Error al eliminar el producto {}".format(error), parent = self.eliminar)
    
#Eliminar()