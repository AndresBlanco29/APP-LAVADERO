import tkinter as tk
from tkinter import ttk
from tkinter import messagebox as mb
import nuevo_producto
import modificar_producto
import eliminar_producto
from agregar_mercancia import *
import Consultas
import csv
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
import os
from usuarios import *
from datetime import datetime
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet

class Frm_inventario:
    
    def __init__(self, usuario):
        
        self.usuario = usuario
        
        self.inventario = tk.Toplevel()
        
        self.inventario.title("Inventario")
        
        self.inventario.bind("<Motion>", self.mostrar_coordenadas)
        
        self.inventario.geometry("1000x720")
        
        self.center_window(1000, 720)
        
        self.items()

        self.inventario.mainloop()
        
    def mostrar_coordenadas(self, event):
        print(f"Coordenadas: {event.x}, {event.y}")
        
    def items(self):

        self.ancho_ventana = 1000
        self.alto_ventana = 720
        
        ruta_imagen = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'inventario.png')
        print(f"Cargando imagen desde: {ruta_imagen}")  # Debug
        self.img_inventario = tk.PhotoImage(file=ruta_imagen)

        img_ancho = self.img_inventario.width()
        img_alto = self.img_inventario.height()

        self.canvas1 = tk.Canvas(self.inventario, width=self.ancho_ventana, height=self.alto_ventana)
        self.canvas1.place(relx=0.5, rely=0.5, anchor="center")  

        img_x = (self.ancho_ventana // 2) - (img_ancho // 2)- 34
        img_y = (self.alto_ventana // 2) - (img_alto // 2)

        self.canvas1.create_image(img_x, img_y, anchor="nw", image=self.img_inventario)

        self.canvas_header = tk.Canvas(self.inventario, height=37, bg="#A8A8A8", bd=1, highlightthickness=0)
        self.canvas_header.pack(fill="x", padx=2, pady=137)

        self.canvas_header.create_text(79, 15, text="Codigo", fill="#000000", font=("Verdana", 13, "normal"))
        self.canvas_header.create_text(244, 15, text="Nombre", fill="#000000", font=("Verdana", 13, "normal"))
        self.canvas_header.create_text(426, 15, text="Precio de venta", fill="#000000", font=("Verdana", 13, "normal"))
        self.canvas_header.create_text(596, 15, text="Precio de compra", fill="#000000", font=("Verdana", 13, "normal"))
        self.canvas_header.create_text(755, 15, text="Cantidad", fill="#000000", font=("Verdana", 13, "normal"))
        self.canvas_header.create_text(903, 15, text="Marca", fill="#000000", font=("Verdana", 13, "normal"))

        self.tree_frame = tk.Frame(self.inventario, bd=3, relief="solid")
        self.tree_frame.place(x=10, y=185)  

        self.tree_productos = ttk.Treeview(self.tree_frame, columns=("Codigo", "Nombre", "Precio_de_venta", "Precio_de_Compra", "Cantidad", "Marca"), show="", height=10)
        self.tree_productos.column("# 1", anchor="center", width=140)
        self.tree_productos.column("# 2", anchor="center", width=195)
        self.tree_productos.column("# 3", anchor="center", width=170)
        self.tree_productos.column("# 4", anchor="center", width=170)
        self.tree_productos.column("# 5", anchor="center", width=140)
        self.tree_productos.column("# 6", anchor="center",width=160)
        
        for row in Consultas.mostrar_Productos():
            try:
                codigo, nombre, precio_venta, precio_compra, cantidad, marca = row
                
                precio_venta = f"{float(precio_venta) / (100 if '.' not in str(precio_venta) else 1):.2f}"
                precio_compra = f"{float(precio_compra) / (100 if '.' not in str(precio_compra) else 1):.2f}"
                
                self.tree_productos.insert("", "end", values=(codigo, nombre, precio_venta, precio_compra, cantidad, marca))
            except ValueError as e:
                print(f"Error al procesar la fila {row}: {e}")
            except TypeError as e:
                print(f"Error de tipo al procesar la fila {row}: {e}")


        self.tree_productos.pack()
        
        self.agregar_producto = tk.Button(self.inventario, text="Agregar un producto", background="#131861", font=("Arial", 11, "bold"), foreground="White", command=self.abrir_nuevo_producto)
        self.agregar_producto.place(x=90, y=523)
        
        self.modificar_producto = tk.Button(self.inventario, text="Modificar un producto", background="#131861", font=("Arial", 11, "bold"), foreground="White", command=self.abrir_modificar_producto)
        self.modificar_producto.place(x=307, y=523)

        self.eliminar_producto = tk.Button(self.inventario, text="Eliminar un producto", background="#131861", font=("Arial", 11, "bold"), foreground="White", command=self.abrir_eliminar_producto)
        self.eliminar_producto.place(x=530, y=523)

        self.agregar_mercancia = tk.Button(self.inventario, text="Agregar Mercancia", background="#131861", font=("Arial", 11, "bold"), foreground="White", command=self.abrir_agregar_mercancia)
        self.agregar_mercancia.place(x=750, y=523)

        self.mayor_existencias = tk.Button(self.inventario, text="Ordenar Mayor Existencias", background="#131861", font=("Arial", 11, "bold"), foreground="White", command=self.mayor_exis)
        self.mayor_existencias.place(x=20, y=615)

        self.menor_existencias = tk.Button(self.inventario, text="Ordenar Menor Existencias", background="#131861", font=("Arial", 11, "bold"), foreground="White", command=self.menor_exis)
        self.menor_existencias.place(x=250, y=615)

        self.reporte_inventario = tk.Button(self.inventario, text="Generar Reporte De Inventario", background="#131861", font=("Arial", 11, "bold"), foreground="White", command=self.generar_reporte)
        self.reporte_inventario.place(x=118, y=660)
        
        self.buscar_producto = tk.Entry(self.inventario, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=33, font=("Arial", 12))
        self.buscar_producto.place(x=346, y=83)
        
        self.buscar_producto.focus()
        
        self.buscar_producto.bind("<KeyRelease>", self.buscar)
        
        self.inversion_total = tk.Entry(self.inventario, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=17, font=("Arial", 12))
        self.inversion_total.place(x=823, y=621)

        self.venta_total = tk.Entry(self.inventario, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=17, font=("Arial", 12))
        self.venta_total.place(x=823, y=676)
        
        self.actualizar = tk.Button(self.inventario, text="Actualizar Tabla", background="#131861", font=("Arial", 11, "bold"), foreground="White", command=self.actualizar_tabla)
        self.actualizar.place(x=440, y=434)
        
        self.actualizar_tabla()
        
    def actualizar_tabla(self):
        try:
            self.tree_productos.delete(*self.tree_productos.get_children())
            
            resultados = Consultas.mostrar_Productos()
            total_inversion = 0 
            total_venta = 0

            for row in resultados:
                self.tree_productos.insert("", tk.END, values=row)
                total_inversion += row[3]
                total_venta += row[2]

  
            self.inversion_total.delete(0, tk.END) 
            self.inversion_total.insert(0, f"${total_inversion:,.0f}")  
            
            self.venta_total.delete(0, tk.END)
            self.venta_total.insert(0,f"${total_venta:,.0f}")
            
        except ValueError as error:
            mb.showerror("Error", "Error al actualizar la tabla {}".format(error), parent=self.inventario)

        
    def buscar(self, event=None):
        try:
            texto_buscado = self.buscar_producto.get().lower()
            
            self.tree_productos.delete(*self.tree_productos.get_children())
            
            resultados = Consultas.buscar_productos(texto_buscado, texto_buscado, texto_buscado)
            
            for row in resultados:
                self.tree_productos.insert("", tk.END, values=row)
                
        except ValueError as error:
            mb.showerror("Error {}".format(error), parent=self.inventario)
        
        
    def abrir_nuevo_producto(self):
        nuevo_producto.nuevo_producto()
        
    def abrir_modificar_producto(self):
        modificar_producto.Modificar()
        
    def abrir_eliminar_producto(self):
        eliminar_producto.Eliminar()
        
    def abrir_agregar_mercancia(self):
        Mercancia()
        
    def center_window(self, width, height):

        screen_width = self.inventario.winfo_screenwidth()
        screen_height = self.inventario.winfo_screenheight()

     
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)

        self.inventario.geometry(f'{width}x{height}+{x}+{y}')
        
    def mayor_exis(self):
        try:
            productos = Consultas.mostrar_Productos()
            
            productos_ordenados = sorted(productos, key=lambda x: x[4], reverse=True)
            
            self.tree_productos.delete(*self.tree_productos.get_children())
            
            for row in productos_ordenados:
                self.tree_productos.insert("", tk.END, values=row)
        except ValueError as error:
            mb.showerror("Error {}".format(error), parent=self.inventario)
            
    def menor_exis(self):
        try:
            productos = Consultas.mostrar_Productos()
            
            productos_ordenados = sorted(productos, key=lambda x: x[4], reverse=False)
            
            self.tree_productos.delete(*self.tree_productos.get_children())
            
            for row in productos_ordenados:
                self.tree_productos.insert("", tk.END, values=row)
        except ValueError as error:
            mb.showerror("Error {}".format(error), parent=self.inventario)

    def generar_reporte(self):
        nombre_usuario = usuarios.Obtener_Nombre_Empleado(self.usuario)

 
        productos = []
        for item in self.tree_productos.get_children():
            valores = self.tree_productos.item(item, 'values')
            codigo = valores[0]
            nombre = valores[1]
            precio_venta = float(valores[2])
            precio_compra = float(valores[3])
            cantidad = int(valores[4])
            total_compra = precio_compra * cantidad
            total_venta = precio_venta * cantidad
            
            productos.append([codigo, nombre, precio_compra, precio_venta, cantidad, total_compra, total_venta])

      
        encabezados = ['Codigo del producto', 'Nombre del producto', 'Precio a la compra', 
                    'Precio a la venta', 'Stock', 'Total a la compra', 'Total a la venta']
        data = [encabezados] + productos

 
        total_inversion = sum(producto[5] for producto in productos)
        total_venta = sum(producto[6] for producto in productos)

      
        pdf = SimpleDocTemplate("C:\\Users\\SENA\\Desktop\\proyecto\\reportes\\reporte_inventario.pdf", pagesize=letter)
        elementos = []

        estilos = getSampleStyleSheet()

        
        fecha_actual = datetime.now().strftime("%d/%m/%Y") 
        titulo = Paragraph(f"Reporte de inventario al día {fecha_actual}", estilos['Title'])  
        elementos.append(titulo)

        elementos.append(Paragraph("<br/><br/>", estilos['Normal']))

      
        tabla = Table(data)
        tabla.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ]))
        elementos.append(tabla)

        
        elementos.append(Paragraph(f"<br/>Total en inventario (inversión): {total_inversion}", estilos['Normal']))
        elementos.append(Paragraph(f"Total en inventario a la venta: {total_venta}", estilos['Normal']))
        elementos.append(Paragraph(f"Usuario en turno: {nombre_usuario}", estilos['Normal']))

      
        pdf.build(elementos)  
        mb.showinfo("Reporte Generado", "El reporte de inventario se ha generado exitosamente como 'reporte_inventario.pdf'.", parent=self.inventario)




#Frm_inventario()
