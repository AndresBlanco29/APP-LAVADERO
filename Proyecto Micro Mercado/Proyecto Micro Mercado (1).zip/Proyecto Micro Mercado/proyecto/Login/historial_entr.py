from tkinter import ttk
from tkinter import messagebox as mb
from tkcalendar import *
from tkcalendar import DateEntry
from datetime import *
from Consultas import *
import os
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet


class His_entr_sali:
    def __init__(self):
        
   
        self.His_entr_sali = tk.Toplevel()

   
        self.His_entr_sali.title("Historial de entrada y salida de dinero en caja")

     
        self.His_entr_sali.geometry("1050x720")
        
      
        self.His_entr_sali.bind("<Motion>", self.mostrar_coordenadas)

        self.center_window(1050, 720)

   
        self.items()


        self.His_entr_sali.mainloop()
        
    def mostrar_coordenadas(self, event):
        print(f"Coordenadas: {event.x}, {event.y}")

    def center_window(self, width, height):
     
        screen_width = self.His_entr_sali.winfo_screenwidth()
        screen_height = self.His_entr_sali.winfo_screenheight()

    
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)

        self.His_entr_sali.geometry(f'{width}x{height}+{x}+{y}')

    def items(self):

        self.ancho_ventana = 1050
        self.alto_ventana = 720
        
        ruta_imagen = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'Historial_entr_sal.png')
        print(f"Cargando imagen desde: {ruta_imagen}")  
        self.img_his_entr = tk.PhotoImage(file=ruta_imagen)

      
        img_ancho = self.img_his_entr.width()
        img_alto = self.img_his_entr.height()


        self.canvas1 = tk.Canvas(self.His_entr_sali, width=self.ancho_ventana, height=self.alto_ventana)
        self.canvas1.grid(row=0, column=0, columnspan=2, rowspan=5) 

       
        img_x = (self.ancho_ventana // 2) - (img_ancho // 2) + 19
        img_y = (self.alto_ventana // 2) - (img_alto // 2) + 11

   
        self.canvas1.create_image(img_x, img_y, anchor="nw", image=self.img_his_entr)
        
   
        self.tree_his_entr = ttk.Treeview(self.His_entr_sali, columns=("Id_Entrada", "Asunto", "Cantidad", "Cajero", "Fecha"), show="headings")
        self.tree_his_entr.column("#1", anchor="center", width=70)
        self.tree_his_entr.heading("#1", text="Id_Entrada")
        self.tree_his_entr.column("#2", anchor="center", width=140)
        self.tree_his_entr.heading("#2", text="Asunto")
        self.tree_his_entr.column("#3", anchor="center", width=80)
        self.tree_his_entr.heading("#3", text="Cantidad")
        self.tree_his_entr.column("#4", anchor="center", width=120)
        self.tree_his_entr.heading("#4", text="Cajero")
        self.tree_his_entr.column("#5", anchor="center", width=100)
        self.tree_his_entr.heading("#5", text="Fecha")
        self.tree_his_entr.place(x=10, y=300, height=240)
        
        for row in mostrar_entrada_dinero():
            self.tree_his_entr.insert("","end", values=row)
        
      
        self.tree_his_sal = ttk.Treeview(self.His_entr_sali, columns=("Id_Salida", "Asunto", "Cantidad", "Cajero", "Fecha"), show="headings")
        self.tree_his_sal.column("#1", anchor="center", width=70)
        self.tree_his_sal.heading("#1", text="Id_Salida")
        self.tree_his_sal.column("#2", anchor="center", width=140)
        self.tree_his_sal.heading("#2", text="Asunto")
        self.tree_his_sal.column("#3", anchor="center", width=80)
        self.tree_his_sal.heading("#3", text="Cantidad")
        self.tree_his_sal.column("#4", anchor="center", width=120)
        self.tree_his_sal.heading("#4", text="Cajero")
        self.tree_his_sal.column("#5", anchor="center", width=100)
        self.tree_his_sal.heading("#5", text="Fecha")
        self.tree_his_sal.place(x=527, y=300, height=240)
        
        for row in mostrar_salida_dinero():
            self.tree_his_sal.insert("","end", values=row)
        
     
        self.fecha_desde = DateEntry(self.His_entr_sali, width=10, background='darkblue',foreground='white', borderwidth=2, year=2024, font=("Arial", 12, "bold"), locale='es_ES')
        self.fecha_desde.place(x = 389, y=155)
        
    
        self.fecha_hasta = DateEntry(self.His_entr_sali, width=10, background='darkblue',foreground='white', borderwidth=2, year=2024, font=("Arial", 12, "bold"), locale='es_ES')
        self.fecha_hasta.place(x = 590, y=155)
        
    
        self.buscar_btn = tk.Button(self.His_entr_sali, text="Buscar", command=self.buscar_movimientos_Fecha)
        self.buscar_btn.place(x=740, y=155)
        
        self.desde = tk.Label(self.His_entr_sali, text="Buscar del" ,background="#171d74", font=("Arial", 14, "bold"), foreground="white")
        self.desde.place(x=260, y=154)
        
        self.al = tk.Label(self.His_entr_sali, text="al" ,background="#171d74", font=("Arial", 14, "bold"), foreground="white")
        self.al.place(x=530, y=154)
        
        self.Entrada = tk.Label(self.His_entr_sali, text="Entradas:" ,background="#171d74", font=("Arial", 18, "bold"), foreground="white")
        self.Entrada.place(x=10, y=260)
        
        self.Salida = tk.Label(self.His_entr_sali, text="Salidas:" ,background="#171d74", font=("Arial", 18, "bold"), foreground="white")
        self.Salida.place(x=525, y=260)
        
        self.total_entrada = tk.Label(self.His_entr_sali, text="Total en entradas:" ,background="#171d74", font=("Arial", 14), foreground="white")
        self.total_entrada.place(x=210, y=547)
        
        self.en_total_entrada = tk.Entry(self.His_entr_sali, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=16, font=("Arial", 12))
        self.en_total_entrada.place(x=370, y=547)
        
        self.total_salida = tk.Label(self.His_entr_sali, text="Total en salidas:" ,background="#171d74", font=("Arial", 14), foreground="white")
        self.total_salida.place(x=740, y=547)
        
        self.en_total_salida = tk.Entry(self.His_entr_sali, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=16, font=("Arial", 12))
        self.en_total_salida.place(x=885, y=547)
        
        
        self.actualizar = tk.Button(self.His_entr_sali, text="Actualizar Tablas", background="#131861", font=("Arial", 12, "bold"), foreground="White", command=self.actualizar_tabla, width=20)
        self.actualizar.place(x=410, y=650)
        
        self.actualizar_tabla()
        
    def buscar_ventas_Fecha(self):
        pass
    
    def actualizar_tabla(self):
        try:
            self.tree_his_entr.delete(*self.tree_his_entr.get_children())
            
            resultado_entrada = mostrar_entrada_dinero()
            total_entrada = 0 
            total_salida = 0
            

            for row in resultado_entrada:
                self.tree_his_entr.insert("", tk.END, values=row)
                total_entrada += row[2]

   
            self.en_total_entrada.delete(0, tk.END)  
            self.en_total_entrada.insert(0, f"${total_entrada:,.0f}")  
            
            self.tree_his_sal.delete(*self.tree_his_sal.get_children())
            
            resultado_salida = mostrar_salida_dinero()
            total_salida = 0
            

            for row in resultado_salida:
                self.tree_his_sal.insert("", tk.END, values=row)
                total_salida += row[2]

           
            self.en_total_salida.delete(0, tk.END)  
            self.en_total_salida.insert(0, f"${total_salida:,.0f}")  
    
            
        except ValueError as error:
            mb.showerror("Error", "Error al actualizar la tabla {}".format(error), parent=self.His_entr_sali)

    def buscar_movimientos_Fecha(self):
    
        fecha_inicio = self.desde.get_date().strftime('%Y-%m-%d')
        fecha_fin = self.al.get_date().strftime('%Y-%m-%d')

     
        if fecha_inicio == fecha_fin:
            fecha_fin = (self.al.get_date() + timedelta(days=1)).strftime('%Y-%m-%d')

      
        busqueda = mostrar_movimientos_por_fecha(fecha_inicio, fecha_fin)

 
        if not busqueda:
            mb.showinfo("Resultado", "No se encontraron movimientos en este periodo.", parent=self.His_entr_sali)
            return

  
        for item in self.tree_his_entr.get_children():
            self.tree_his_entr.delete(item)


        for movimiento in busqueda:
            self.tree_his_entr.insert("", "end", values=movimiento)

    

         
#His_entr_sali()