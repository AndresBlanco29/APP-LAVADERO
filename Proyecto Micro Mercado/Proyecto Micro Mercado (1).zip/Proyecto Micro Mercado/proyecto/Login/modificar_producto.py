import tkinter as tk
from tkinter import ttk
from tkinter import messagebox as mb
from Consultas import *
from inventario import *
import inventario
from ventas import *
import os

class Modificar:
    def __init__(self):
        
        self.modificar = tk.Toplevel()

        self.modificar.title("Modificar Producto")

        self.modificar.geometry("652x650")
        

        self.modificar.bind("<Motion>", self.mostrar_coordenadas)

   
        self.center_window(652, 650)


        self.items()

        
    def mostrar_coordenadas(self, event):
        print(f"Coordenadas: {event.x}, {event.y}")

    def center_window(self, width, height):
       
        screen_width = self.modificar.winfo_screenwidth()
        screen_height = self.modificar.winfo_screenheight()

  
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)

     
        self.modificar.geometry(f'{width}x{height}+{x}+{y}')

    def items(self):
      
        self.ancho_ventana = 652
        self.alto_ventana = 650
        
        ruta_imagen = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'modificar_producto.png')
        print(f"Cargando imagen desde: {ruta_imagen}")  # Debug
        self.img_modificar = tk.PhotoImage(file=ruta_imagen)

       
        img_ancho = self.img_modificar.width()
        img_alto = self.img_modificar.height()

     
        self.canvas1 = tk.Canvas(self.modificar, width=self.ancho_ventana, height=self.alto_ventana)
        self.canvas1.grid(row=0, column=0, columnspan=2, rowspan=5)  

       
        img_x = (self.ancho_ventana // 2) - (img_ancho // 2) -84
        img_y = (self.alto_ventana // 2) - (img_alto // 2) - 26

        self.canvas1.create_image(img_x, img_y, anchor="nw", image=self.img_modificar)
        
   
        self.codigo_producto = tk.Entry(self.modificar, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=29, font=("Arial", 12))
        self.codigo_producto.place(x=261, y=130)
        
        self.codigo_producto.focus()
  
        self.nombre_producto = tk.Entry(self.modificar, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=37, font=("Arial", 12))
        self.nombre_producto.place(x=261, y=218)
        

        self.precio_compra_producto = tk.Entry(self.modificar, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=37, font=("Arial", 12))
        self.precio_compra_producto.place(x=261, y=273)
  
        self.precio_venta_producto = tk.Entry(self.modificar, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=37, font=("Arial", 12))
        self.precio_venta_producto.place(x=261, y=328)
        
   
        self.cantidad_producto = tk.Entry(self.modificar, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=37, font=("Arial", 12))
        self.cantidad_producto.place(x=261, y=384)
        
        self.marca_producto = tk.Entry(self.modificar, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=37, font=("Arial", 12))
        self.marca_producto.place(x=261, y=434)
   
        self.desc_producto = tk.Entry(self.modificar, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=37, font=("Arial", 12))
        self.desc_producto.place(x=261, y=496)
 
        self.buscar_codigo_producto = tk.Button(self.modificar, text="Buscar", background="#131861", font=("Arial", 10, "bold"), foreground="White", command=self.Buscar_codigo, width=5)
        self.buscar_codigo_producto.place(x=545, y=129)
        
        self.borde_guardar = tk.Frame(self.modificar, background="white", bd=2)
        self.borde_guardar.place(x=90, y=493)
        
        self.guardar = tk.Button(self.borde_guardar, text="Guardar", background="#d17100", font=("Arial", 14, "bold"), foreground="black", command=self.guardar_cambios, width=42)
        self.guardar.pack()
        
        self.borde_cancelar = tk.Frame(self.modificar, background="white", bd=2)
        self.borde_cancelar.place(x=90, y=570)
        
        self.cancelar = tk.Button(self.borde_cancelar, text="Cancelar", background="#e51400", font=("Arial", 14, "bold"), foreground="black", command=self.cancelar_cambios, width=42)
        self.cancelar.pack()
        
    def guardar_cambios(self):
        try:
            Codigo = self.codigo_producto.get()
            Nombre = self.nombre_producto.get()
            precio_compra = float(self.precio_compra_producto.get())
            precio_venta = float(self.precio_venta_producto.get())
            Cantidad = int(self.cantidad_producto.get())
            Marca = self.marca_producto.get()
            
            if not all([Nombre, precio_venta, precio_compra, Cantidad, Marca, Codigo]):
                mb.showwarning("Advertencia","Todos los campos son obligatorios", parent = self.modificar)
                return
            
            producto_modi = modificar_producto(Nombre, precio_venta, precio_compra, Cantidad, Marca, Codigo)
            
            if producto_modi:
                mb.showinfo("Exito", "Producto Modificado Correctamente", parent= self.modificar)
                self.limpiar_cajas()
             
                
        except ValueError as error:
            mb.showerror("Error", "Error al modificar los datos {}".format(error), parent=self.modificar)
            
    def cancelar_cambios(self):
        pass
            
    def Buscar_codigo(self):
        try:

            Codigo = self.codigo_producto.get()
            
      
            if not Codigo:
                mb.showerror("Error", "Por favor ingrese un código de producto", parent=self.modificar)
                return
            
     
            producto = buscar_codigo(Codigo)
            
            if producto:
        
                self.nombre_producto.delete(0, "end")
                self.nombre_producto.insert(0, producto[1]) 
                
                self.precio_compra_producto.delete(0, "end")
                self.precio_compra_producto.insert(0, producto[2]) 
                
                self.precio_venta_producto.delete(0, "end")
                self.precio_venta_producto.insert(0, producto[3])
                
                self.cantidad_producto.delete(0, "end")
                self.cantidad_producto.insert(0, producto[4])
                
                self.marca_producto.delete(0, "end")
                self.marca_producto.insert(0, producto[5])
                
            else:
                mb.showinfo("No encontrado", "No se encontró el producto con ese código",parent = self.modificar)

        except ValueError as error:
            mb.showerror("Error al buscar el producto: {}".format(error), parent=self.modificar)
            
        
    def limpiar_cajas(self):
        self.codigo_producto.delete(0, "end")
        self.nombre_producto.delete(0, "end")
        self.precio_compra_producto.delete(0, "end")
        self.precio_venta_producto.delete(0, "end")
        self.cantidad_producto.delete(0, "end")
        self.marca_producto.delete(0, "end")
        self.desc_producto.delete(0, "end")

#Modificar()