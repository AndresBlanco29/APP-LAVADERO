import tkinter as tk
from tkinter import ttk
from tkinter import messagebox as mb
from Consultas import *
import os
import historial_entr
import entrada
import salida


class entra_sali:
    def __init__(self, usuario):
        
        self.usuario = usuario
        
     
        self.entra_sali = tk.Toplevel()

 
        self.entra_sali.title("Entrada y salida de dinero")

   
        self.entra_sali.geometry("633x341")
        
   
        self.entra_sali.bind("<Motion>", self.mostrar_coordenadas)

      
        self.center_window(633, 341)

      
        self.items()

     
        self.entra_sali.mainloop()
        
    def mostrar_coordenadas(self, event):
        print(f"Coordenadas: {event.x}, {event.y}")

    def center_window(self, width, height):
    
        screen_width = self.entra_sali.winfo_screenwidth()
        screen_height = self.entra_sali.winfo_screenheight()

        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)

  
        self.entra_sali.geometry(f'{width}x{height}+{x}+{y}')

    def items(self):
       
        self.ancho_ventana = 633
        self.alto_ventana = 341
        
        ruta_imagen = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'entrsal.png')
        print(f"Cargando imagen desde: {ruta_imagen}")  
        self.img_entr_sali = tk.PhotoImage(file=ruta_imagen)

     
        img_ancho = self.img_entr_sali.width()
        img_alto = self.img_entr_sali.height()

      
        self.canvas1 = tk.Canvas(self.entra_sali, width=self.ancho_ventana, height=self.alto_ventana)
        self.canvas1.grid(row=0, column=0, columnspan=2, rowspan=5) 

     
        img_x = (self.ancho_ventana // 2) - (img_ancho // 2) - 17
        img_y = (self.alto_ventana // 2) - (img_alto // 2) + 25

    
        self.canvas1.create_image(img_x, img_y, anchor="nw", image=self.img_entr_sali)
        
        self.btn_entr_dine = tk.Button(self.entra_sali, text="Entrada de dinero", width=14, font=("Arial", 14, "bold"), background="#171d74", foreground="White", command=self.abrir_entr_dine)
        self.btn_entr_dine.place(x=30, y=201)
        
        self.btn_sal_dine = tk.Button(self.entra_sali, text="Salida de dinero", width=14, font=("Arial", 14, "bold"), background="#171d74", foreground="White", command=self.abrir_sali_dine)
        self.btn_sal_dine.place(x=230, y=201)
        
        self.btn_hist_entr_sal = tk.Button(self.entra_sali, text="Historial entr/sali", width=14, font=("Arial", 14, "bold"), background="#171d74", foreground="White", command=self.abrir_hist_sali_dine)
        self.btn_hist_entr_sal.place(x=430, y=201)
        
    def abrir_entr_dine(self):
        entrada.entrada_dinero(self.usuario)
    
    def abrir_sali_dine(self):
        salida.salida_dinero(self.usuario)
    
    def abrir_hist_sali_dine(self):
        historial_entr.His_entr_sali()
    
#entra_sali()