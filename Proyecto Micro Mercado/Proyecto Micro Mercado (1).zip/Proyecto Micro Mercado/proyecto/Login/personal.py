import tkinter as tk
from tkinter import ttk
from tkinter import messagebox as mb
import modificar_usuarios
import nuevo_usuario
import Consultas as Consultas
import os

class Personal:
    def __init__(self):
        
        
        self.personal = tk.Toplevel()

        
        self.personal.title("Personal")
    
       
        self.personal.geometry("900x650")
        
        
        self.personal.bind("<Motion>", self.mostrar_coordenadas)

        
        self.center_window(900, 650)

      
        self.items()

       
        self.personal.mainloop()
        
    def mostrar_coordenadas(self, event):
        print(f"Coordenadas: {event.x}, {event.y}")

    def center_window(self, width, height):
       
        screen_width = self.personal.winfo_screenwidth()
        screen_height = self.personal.winfo_screenheight()

    
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)

     
        self.personal.geometry(f'{width}x{height}+{x}+{y}')

    def items(self):
     
        self.ancho_ventana = 900
        self.alto_ventana = 650
        
        ruta_imagen = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'personal.png')
        print(f"Cargando imagen desde: {ruta_imagen}")  # Debug
        self.img_personal = tk.PhotoImage(file=ruta_imagen)

        img_ancho = self.img_personal.width()
        img_alto = self.img_personal.height()

       
        self.canvas1 = tk.Canvas(self.personal, width=self.ancho_ventana, height=self.alto_ventana)
        self.canvas1.grid(row=0, column=0, columnspan=2, rowspan=5) 

  
        img_x = (self.ancho_ventana // 2) - (img_ancho // 2) + 24
        img_y = (self.alto_ventana // 2) - (img_alto // 2) - 26

  
        self.canvas1.create_image(img_x, img_y, anchor="nw", image=self.img_personal)
        
 
        self.tree_personal = ttk.Treeview(self.personal, columns=("Codigo", "usuario", "password", "nombre", "telefono"), show="headings")
        self.tree_personal.column("#1", anchor="center", width=140)
        self.tree_personal.heading("#1", text="Codigo")
        self.tree_personal.column("#2", anchor="center", width=140)
        self.tree_personal.heading("#2", text="Usuario")
        self.tree_personal.column("#3", anchor="center", width=140)
        self.tree_personal.heading("#3", text="Password")
        self.tree_personal.column("#4", anchor="center", width=140)
        self.tree_personal.heading("#4", text="Nombre")
        self.tree_personal.column("#5", anchor="center", width=140)
        self.tree_personal.heading("#5", text="Telefono")
        
        for row in Consultas.mostrar_personal():
            self.tree_personal.insert("", tk.END, values= row)
        
        self.tree_personal.place(x=130, y=200)
        
   
        self.buscar_usuario = tk.Entry(self.personal, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=33, font=("Arial", 12))
        self.buscar_usuario.place(x=357, y=125)
        
        self.buscar_usuario.focus()
        
        self.buscar_usuario.bind("<KeyRelease>", self.buscar)

      
        self.usuario_seleccionado = tk.Entry(self.personal, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=23, font=("Arial", 12))
        self.usuario_seleccionado.place(x=342, y=495)
     
        borde_frame_agregar = tk.Frame(self.personal, background="white", bd=2)
        borde_frame_agregar.place(x=355, y=580)
        
    
        self.agregar_usuario = tk.Button(borde_frame_agregar, text="Agregar usuario", background="#131861", font=("Arial", 12, "bold"), foreground="White", width=19, bd=0, command=self.abrir_agregar_usuario)
        self.agregar_usuario.pack()
        
   
        borde_frame_modificar = tk.Frame(self.personal, background="white", bd=2)
        borde_frame_modificar.place(x=85, y=580)
        
       
        self.modificar_usuario = tk.Button(borde_frame_modificar, text="Modificar usuario seleccionado", background="#131861", font=("Arial", 12, "bold"), foreground="White", width=24, bd=0, command=self.abrir_modificar_usuario)
        self.modificar_usuario.pack()
        
     
        borde_frame_eliminar = tk.Frame(self.personal, background="white", bd=2)
        borde_frame_eliminar.place(x=572, y=580)
        
   
        self.eliminar_usuario = tk.Button(borde_frame_eliminar, text="Eliminar usuario seleccionado", background="#131861", font=("Arial", 12, "bold"), foreground="White", width=24, bd=0, command=self.Eliminar_usuario)
        self.eliminar_usuario.pack()
        
   
        self.actualizar = tk.Button(self.personal, text="Actualizar Tabla", background="#131861", font=("Arial", 11, "bold"), foreground="White", command=self.actualizar_tabla)
        self.actualizar.place(x=395, y=444)
        
        self.actualizar_tabla()
        self.tree_personal.bind("<<TreeviewSelect>>", self.obtener_usuario)
        
    def actualizar_tabla(self):
        try:
            self.tree_personal.delete(*self.tree_personal.get_children())
            
            resultados = Consultas.mostrar_personal()

            for row in resultados:
                self.tree_personal.insert("", tk.END, values=row)

            
        except ValueError as error:
            mb.showerror("Error", "Error al actualizar la tabla {}".format(error), parent = self.personal)
        
        self.buscar_usuario.focus()
        
    def abrir_modificar_usuario(self):
        usuario_data = self.obtener_datos()
        if usuario_data:
            modificar_usuarios.modificar_usuarios(usuario_data)
        else:
            mb.showwarning("Advertencia", "Seleccione un usuario para modificar.", parent = self.personal)
        
    def abrir_agregar_usuario(self):
        nuevo_usuario.nuevo_usuario()
    
    def Eliminar_usuario(self):
        try:
            usuario_seleccionado = self.tree_personal.selection()
            
            if not usuario_seleccionado:
                mb.showinfo("Advertencia","Seleccione un usuario", parent = self.personal)
                return
            
            item = self.tree_personal.item(usuario_seleccionado, 'values')
            Codigo = item[0]
            
            Consultas.eliminar_personal(Codigo)
            self.actualizar_tabla()
            
        except ValueError as error:
            mb.showerror("Error {}".format(error), parent = self.personal)
    
    def buscar(self, event=None):
        try:
            texto_buscado = self.buscar_usuario.get().lower()
            
            self.tree_personal.delete(*self.tree_personal.get_children())
            
            resultado = Consultas.buscar_personal( texto_buscado, texto_buscado, texto_buscado)
            
            for row in resultado:
                self.tree_personal.insert("", tk.END, values=row)
                
            if self.tree_personal.get_children():
                self.first_item = self.tree_personal.get_children()[0]
                self.tree_personal.selection_set(self.first_item)
                self.obtener_usuario()
        except ValueError as error:
            mb.showerror("Error {}".format(error), parent = self.personal)
            
    def obtener_usuario(self, event= None):
        try:
            usuario = self.tree_personal.selection()
            if not usuario:
                self.usuario_seleccionado.delete(0, tk.END)
            if usuario:
                item = self.tree_personal.item(usuario, 'values')
                nombre_usuario = item[1]
                self.usuario_seleccionado.delete(0, tk.END)
                self.usuario_seleccionado.insert(0, nombre_usuario)
                
        except ValueError as error:
            mb.showerror("Error {}".format(error), parent = self.personal)
            
    def obtener_datos(self):
        try:
            usuario = self.tree_personal.selection()
            if usuario:
                item = self.tree_personal.item(usuario, 'values')
                return item 
            return None
        except ValueError as error:
            mb.showerror("Error {}".format(error), parent = self.personal)
#Personal()