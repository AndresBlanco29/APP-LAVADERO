import tkinter as tk
from tkinter import ttk
from tkinter import messagebox as mb
from PIL import Image, ImageTk
from datetime import datetime
from usuarios import *
import inventario
import cobrar
import personal
import proveedores
import R_Ventas
import entr_sald
from Consultas import *
import tkinter.font as tkFont
import os

class ventas:
    def __init__(self, usuario):
        
        self.usuario = usuario
        
        self.ventas = tk.Tk()

        self.ventas.title("Menu")

        self.ventas.geometry("1280x720")

        self.ventas.bind("<Motion>", self.mostrar_coordenadas)
        
        self.ventas.bind("<F12>", self.abrir_cobrar)

        self.center_window(1280, 720)

        self.items()

        self.ventas.mainloop()
        
    def mostrar_coordenadas(self, event):
        print(f"Coordenadas: {event.x}, {event.y}")

    def center_window(self, width, height):

        screen_width = self.ventas.winfo_screenwidth()
        screen_height = self.ventas.winfo_screenheight()

        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)

        self.ventas.geometry(f'{width}x{height}+{x}+{y}')

    def items(self):

        self.ancho_ventana = 1280
        self.alto_ventana = 720
        
        ruta_imagen = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ventas.png')
        print(f"Cargando imagen desde: {ruta_imagen}")  
        self.img_login = tk.PhotoImage(file=ruta_imagen)
        
        ruta_imagen_agregar = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'agregar.png')
        print(f"Cargando imagen desde: {ruta_imagen_agregar}")  

        img_agregar_pil = Image.open(ruta_imagen_agregar)
        img_agregar_pil = img_agregar_pil.resize((30, 30), Image.Resampling.LANCZOS)  

        self.img_agregar = ImageTk.PhotoImage(img_agregar_pil)

        img_ancho = self.img_login.width()
        img_alto = self.img_login.height()

        self.canvas1 = tk.Canvas(self.ventas, width=self.ancho_ventana, height=self.alto_ventana)
        self.canvas1.grid(row=0, column=0, columnspan=2, rowspan=5) 

        img_x = (self.ancho_ventana // 2) - (img_ancho // 2)
        img_y = (self.alto_ventana // 2) - (img_alto // 2)

        self.canvas1.create_image(img_x, img_y, anchor="nw", image=self.img_login)

        font = tkFont.Font(family="Helvetica", size=14)

        style = ttk.Style()
        style.configure("Treeview", font=font, rowheight=22) 

        self.tree_frame = tk.Frame(self.ventas, bd=3, relief="solid")
        self.tree_frame.place(x=23, y=312)  

        self.tree_venta = ttk.Treeview(
            self.tree_frame,
            columns=("N.Producto", "Codigo", "Producto", "Cantidad", "Precio U", "Subtotal", ""),
            show="",
            height=10
        )

        self.tree_venta.column("#1", anchor="center", width=153)
        self.tree_venta.column("#2", anchor="center", width=160)
        self.tree_venta.column("#3", anchor="center", width=190)
        self.tree_venta.column("#4", anchor="center", width=150)
        self.tree_venta.column("#5", anchor="center", width=160)
        self.tree_venta.column("#6", anchor="center", width=160)
        self.tree_venta.column("#7", anchor="center", width=260)

        self.tree_venta.pack()

        self.btn_ventas = tk.Button(self.ventas, text="Venta", width=15, height=1, fg='black')
        self.btn_ventas.place(x=40, y=123)

        self.btn_inventario = tk.Button(self.ventas, text="Productos", width=15, height=1, fg='black', command=self.Abrir_inventario)
        self.btn_inventario.place(x=200, y=123)

        self.btn_personal = tk.Button(self.ventas, text="Personal", width=15, height=1,fg='black', command=self.abrir_personal)
        self.btn_personal.place(x=360, y=123)

        self.btn_proveedores = tk.Button(self.ventas, text="Proveedores", width=18, height=1,fg='black', command=self.abrir_proveedor)
        self.btn_proveedores.place(x=524, y=123)

        self.btn_RVentas = tk.Button(self.ventas, text="R.Ventas", width=18, height=1,fg='black', command=self.abrir_R_Ventas)
        self.btn_RVentas.place(x=706, y=123)
        
        self.btn_entrada_dinero = tk.Button(self.ventas, text="Entrada/Salida(Dinero)", width=18, height=1,fg='black', command=self.abrir_entrada_dinero)
        self.btn_entrada_dinero.place(x=900, y=123)

        self.codigo_producto = tk.Entry(self.ventas, validate="key", validatecommand=(self.ventas.register(self.validar_numero), "%P"), highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=22, font=("Arial", 12))
        self.codigo_producto.place(x=209, y=210)

        self.cantidad_producto = tk.Entry(self.ventas,validate="key", validatecommand=(self.ventas.register(self.validar_numero), "%P"), highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=13, font=("Arial", 12))
        self.cantidad_producto.place(x=603, y=210)

        self.btn_cancelarVenta = tk.Button(self.ventas, text="Cancelar Venta", width=13, font=("Arial", 14, "bold"), background="#171d74", foreground="White", command=self.cancelar_venta)
        self.btn_cancelarVenta.place(x=42, y=584)

        self.btn_cancelarProducto = tk.Button(self.ventas, text="Cancelar Producto", width=15, font=("Arial", 14, "bold"), background="#171d74", foreground="White", command=self.cancelar_producto)
        self.btn_cancelarProducto.place(x=237, y=584)

        self.btn_cobrar = tk.Button(self.ventas, text="F-12 Cobrar", width=11, font=("Arial", 15, "bold"), background="#d17100", foreground="Black", command=self.abrir_cobrar)
        self.btn_cobrar.place(x=842, y=577)

        self.btn_agregar = tk.Button(self.ventas, image=self.img_agregar, command=self.agregar_lista_venta, bg=self.ventas.cget('bg'), bd=0)
        self.btn_agregar.place(x=426, y=208)

        self.labelF_Actual = tk.Label(self.ventas,  background="#171d74", font=("Arial", 18, "bold"), foreground="White")
        self.labelF_Actual.place(x=1104, y=48)

        self.labelH_Actual = tk.Label(self.ventas, background="#9d9d9d", font=("Arial", 18, "bold"), foreground="Black")
        self.labelH_Actual.place(x=1076, y=655)

        self.cobro = tk.Label(self.ventas, background="#bdbfd4", font=("Arial", 40, "bold"), foreground="#171d74", text="$  0.00")
        self.cobro.place(x=1000, y=558)

        self.turno = tk.Label(self.ventas, background="#9d9d9d", font=("Arial", 18, "bold"), foreground="#171d74")
        self.turno.place(x=270, y=654)
        
        self.obtener_nombre_empleado()
        
        self.actualizar_fecha_hora()
        
    def abrir_cobrar(self, event = None):
        
        self.calcular_total_articulos()
        
        productos_comprado = [(self.tree_venta.item(fila, "values")[1],self.tree_venta.item(fila, "values")[3], self.tree_venta.item(fila, "values")[5]) for fila in self.tree_venta.get_children()]
        
        if not productos_comprado:
            mb.showerror("Error", "Tiene que haber un producto ingresado en la lista")
            return
        if productos_comprado:
        
            cobrar.cobrar(self.total_ventas, self.total_articulos, self.id_empleado, productos_comprado)
        
    def Abrir_inventario(self):
        inventario.Frm_inventario(self.usuario)
        
        
    def abrir_personal(self):
        personal.Personal()
        

    def abrir_proveedor(self):
        proveedores.Proveedores()
        
    def abrir_R_Ventas(self):
        R_Ventas.R_Ventas()
        
    def abrir_entrada_dinero(self):
        entr_sald.entra_sali(self.usuario)
        
    def obtener_nombre_empleado(self):
        
        nombre_empleado = usuarios.Obtener_Nombre_Empleado(self.usuario)
        id_empleado = usuarios.Obtener_Id_Empleado(self.usuario)
        self.empleado = nombre_empleado
        self.id_empleado = id_empleado
        self.turno.config(text=f"{nombre_empleado}")
        
    def actualizar_fecha_hora(self):
        
        # Obtenemos la fecha actual
        self.Fecha_Actual = datetime.now()
        self.año = self.Fecha_Actual.year
        self.mes = self.Fecha_Actual.month
        self.dia = self.Fecha_Actual.day
        
        self.labelF_Actual.config(text=f"{self.dia:02d}/{self.mes:02d}/{self.año}")
        
        # Obtenemos la hora actual
        self.Hora_Actual = datetime.now()
        self.hora = self.Hora_Actual.hour
        self.minutos = self.Hora_Actual.minute
        self.segundos = self.Hora_Actual.second
        
        hora_formateada = self.hora % 12
        hora_formateada = hora_formateada if hora_formateada != 0 else 12
        am_pm = "a.m." if self.hora < 12 else "p.m."
        
        self.labelH_Actual.config(text=f"{hora_formateada:02d}:{self.minutos:02d}:{self.segundos:02d} {am_pm}")
        
        self.ventas.after(1000, self.actualizar_fecha_hora)
        
    def validar_numero(self, texto):
        
        if texto == "" or texto.isdigit():
            return True
        else:
            return False

    def agregar_lista_venta(self):
        Codigo = self.codigo_producto.get().strip()
        Cantidad = self.cantidad_producto.get().strip()

        if not Codigo or not Cantidad:
            mb.showerror("Error", "Llene todos los campos")
            return  

        if not Codigo.isdigit():
            mb.showerror("Error", "El código debe contener solo números.")
            return

        if not Cantidad.isdigit():
            mb.showerror("Error", "La cantidad debe ser un número.")
            return

        Codigo = int(Codigo)
        Cantidad = int(Cantidad)

        producto = obtener_producto(Codigo)
        cantidad_disponible = cantidad_producto(Codigo)

        if not producto:
            mb.showerror("Error", "El producto no existe en la base de datos")
            return

        if Cantidad > cantidad_disponible:
            mb.showwarning("Advertencia", f"Cantidad solicitada ({Cantidad}) supera la cantidad en stock disponible ({cantidad_disponible}).")
            return

        nombre_producto = producto[1]
        Precio_Unitario = producto[2]
        subtotal = Precio_Unitario * Cantidad

        for item in self.tree_venta.get_children():
            if int(self.tree_venta.item(item, "values")[1]) == Codigo:
                mb.showerror("Error", f"El producto con código {Codigo} ya está en la lista.")
                return

        if len(self.tree_venta.get_children()) == 0:
            numero_producto = 1
        else:
            ultimo_item = self.tree_venta.get_children()[-1]
            ultimo_numero = int(self.tree_venta.item(ultimo_item, "values")[0])
            numero_producto = ultimo_numero + 1

        self.tree_venta.insert("", tk.END, values=(numero_producto, Codigo, nombre_producto, Cantidad, Precio_Unitario, subtotal))

        # Limpiar los campos
        self.codigo_producto.delete(0, tk.END)
        self.cantidad_producto.delete(0, tk.END)
        self.codigo_producto.focus()

        self.actualizar_total()

        if cantidad_disponible - Cantidad <= 10:
            mb.showinfo("Reabastecimiento necesario", f"El stock del producto '{nombre_producto}' está bajo (restan {cantidad_disponible - Cantidad} unidades). Considere reabastecer.")

    def actualizar_total(self):
        
        total = 0.00

        for fila in self.tree_venta.get_children():
            subtotal = float(self.tree_venta.item(fila, "values")[5])
            total += subtotal
 
        self.cobro.config(text=f"${total:,.0f}")
        self.total_ventas = total
        
    def cancelar_producto(self):
        
        producto_seleccionado = self.tree_venta.selection()
        
        if not producto_seleccionado:
            mb.showerror("Error", "Debe seleccionar un producto")
            return
        
        for item in producto_seleccionado:
            self.tree_venta.delete(item)
            
        self.actualizar_total()
        
    def cancelar_venta(self):
        
        productos = self.tree_venta.get_children()
        
        if mb.askyesno("Confirmar", "Desea cancelar la venta?"):
            for items in productos:
                self.tree_venta.delete(items)
                
            self.actualizar_total()
            
            self.codigo_producto.delete(0, tk.END)
            self.codigo_producto.focus()
            self.cantidad_producto.delete(0, tk.END)
    
    def calcular_total_articulos(self):
        total_articulos = sum(int(self.tree_venta.item(fila, "values")[3]) for fila in self.tree_venta.get_children())
        self.total_articulos = total_articulos
        
    def limpiar_treeview(self):
        for item in self.tree_venta.get_children():
            self.tree_venta.delete(item)
        
#ventas("")
