import tkinter as tk
from tkinter import ttk
from tkinter import messagebox as mb
from Consultas import *
import os

class nuevo_usuario:
    def __init__(self):
        
        
        self.nuevo_usuario = tk.Toplevel()

      
        self.nuevo_usuario.title("Nuevos Usuarios")

        self.nuevo_usuario.geometry("652x650")
        
        
        self.nuevo_usuario.bind("<Motion>", self.mostrar_coordenadas)

        
        self.center_window(652, 650)

        
        self.items()

       
        self.nuevo_usuario.mainloop()
        
    def mostrar_coordenadas(self, event):
        print(f"Coordenadas: {event.x}, {event.y}")

    def center_window(self, width, height):
      
        screen_width = self.nuevo_usuario.winfo_screenwidth()
        screen_height = self.nuevo_usuario.winfo_screenheight()

       
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)

    
        self.nuevo_usuario.geometry(f'{width}x{height}+{x}+{y}')

    def items(self):
      
        self.ancho_ventana = 652
        self.alto_ventana = 650
        
        ruta_imagen = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'nuevo_usuario.png')
        print(f"Cargando imagen desde: {ruta_imagen}")  # Debug
        self.img_modi_usu = tk.PhotoImage(file=ruta_imagen)

      
        img_ancho = self.img_modi_usu.width()
        img_alto = self.img_modi_usu.height()

 
        self.canvas1 = tk.Canvas(self.nuevo_usuario, width=self.ancho_ventana, height=self.alto_ventana)
        self.canvas1.grid(row=0, column=0, columnspan=2, rowspan=5)  

   
        img_x = (self.ancho_ventana // 2) - (img_ancho // 2) -84
        img_y = (self.alto_ventana // 2) - (img_alto // 2) - 26

        self.canvas1.create_image(img_x, img_y, anchor="nw", image=self.img_modi_usu)
        

        self.nombre_usuario = tk.Entry(self.nuevo_usuario, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=37, font=("Arial", 12))
        self.nombre_usuario.place(x=261, y=148)
        self.nombre_usuario.focus()
        
   
        self.contraseña_usuario = tk.Entry(self.nuevo_usuario, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=37, font=("Arial", 12))
        self.contraseña_usuario.place(x=261, y=219)
        
 
        self.Nombre = tk.Entry(self.nuevo_usuario, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=37, font=("Arial", 12))
        self.Nombre.place(x=261, y=290)
        
 
        self.numero = tk.Entry(self.nuevo_usuario, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=37, font=("Arial", 12))
        self.numero.place(x=261, y=361)
        
   
        self.correo = tk.Entry(self.nuevo_usuario, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=37, font=("Arial", 12))
        self.correo.place(x=261, y=432)
        
   
        self.borde_guardar_usuario = tk.Frame(self.nuevo_usuario, background="white", bd=2)
        self.borde_guardar_usuario.place(x=206, y=569)
        
   
        self.guardar_usuario = tk.Button(self.borde_guardar_usuario, text="Agregar Usuario", background="#131861", font=("Arial", 14, "bold"), foreground="White", command=self.guardar_nuevo_usuario, width=20)
        self.guardar_usuario.pack()
        
    def guardar_nuevo_usuario(self):
        try:
            usuario = self.nombre_usuario.get()
            password = self.contraseña_usuario.get()
            nombre = self.nombre_usuario.get()
            telefono = self.numero.get()
            correo = self.correo.get()
            
            if not all ([usuario, password, nombre]):
                mb.showwarning("Advertencia","Debe llenar todos los campos", parent = self.nuevo_usuario)
                return
            
            Agregar_Personal(usuario, password, nombre, telefono, correo)
            mb.showinfo("Exito","El usuario se agrego correctamente", parent = self.nuevo_usuario)
            
            self.limpiar_cajas()
            self.nombre_usuario.focus()
            
        except ValueError as error:
            mb.showerror("Error al agregar el nuevo usuario{}".format(error), parent = self.nuevo_usuario)
            
    def limpiar_cajas(self):
        self.nombre_usuario.delete(0, tk.END)
        self.contraseña_usuario.delete(0, tk.END)
        self.Nombre.delete(0, tk.END)
        self.numero.delete(0, tk.END)
        self.correo.delete(0, tk.END)
#nuevo_usuario()