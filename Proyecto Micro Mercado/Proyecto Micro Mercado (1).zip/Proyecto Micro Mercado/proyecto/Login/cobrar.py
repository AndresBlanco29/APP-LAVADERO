import tkinter as tk
from tkinter import ttk
from tkinter import messagebox as mb
from Consultas import *
import os


class cobrar:
    def __init__(self, total_ventas, total_articulos, id_empleado, productos_comprados):
        
        self.total = total_ventas
        
        self.total_art = total_articulos
        
        self.id_empleado = id_empleado
        
        self.productos_comprados = productos_comprados
        

        self.cobrar = tk.Toplevel()


        self.cobrar.title("Cobrar")

        self.cobrar.geometry("652x583")
        
     
        self.cobrar.bind("<Motion>", self.mostrar_coordenadas)

     
        self.center_window(652, 583)

     
        self.items()

    
        self.cobrar.mainloop()
        
    def mostrar_coordenadas(self, event):
        print(f"Coordenadas: {event.x}, {event.y}")

    def center_window(self, width, height):
   
        screen_width = self.cobrar.winfo_screenwidth()
        screen_height = self.cobrar.winfo_screenheight()

    
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)

      
        self.cobrar.geometry(f'{width}x{height}+{x}+{y}')

    def items(self):
    
        self.ancho_ventana = 652
        self.alto_ventana = 583
        
        ruta_imagen = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'cobrar.png')
        print(f"Cargando imagen desde: {ruta_imagen}")  # Debug
        self.img_cobrar = tk.PhotoImage(file=ruta_imagen)

   
        img_ancho = self.img_cobrar.width()
        img_alto = self.img_cobrar.height()


        self.canvas1 = tk.Canvas(self.cobrar, width=self.ancho_ventana, height=self.alto_ventana)
        self.canvas1.grid(row=0, column=0, columnspan=2, rowspan=5)  


        img_x = (self.ancho_ventana // 2) - (img_ancho // 2) -84
        img_y = (self.alto_ventana // 2) - (img_alto // 2) + 8

 
        self.canvas1.create_image(img_x, img_y, anchor="nw", image=self.img_cobrar)
        
        self.total_articu = tk.Label(self.cobrar, text=f"{self.total_art}", font=("Arial", 30, "bold"), foreground="white", background="#171d74")
        self.total_articu.place(x=70, y=100)
        

        self.total = tk.Label(self.cobrar, text=f"$ {self.total : ,.0f}", font=("Arial", 45, "bold"), foreground="black")
        self.total.place(x=290, y=120)
        

        self.pago = tk.Entry(self.cobrar, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=16, font=("Arial", 20), justify="center")
        self.pago.place(x=310, y=251)
        self.pago.focus()
        self.pago.bind("<KeyRelease>", self.formatear_comas)
        self.pago.bind("<KeyRelease>", self.calcular_vueltos)
        

        self.vueltos = tk.Label(self.cobrar, text=f"$ {0.00 : ,.0f}", font=("Arial", 45, "bold"), foreground="red")
        self.vueltos.place(x=310, y=330)
        

        self.btn_cobrar = tk.Button(self.cobrar, text="Cobrar", width=12, font=("Arial", 14, "bold"), background="#e0e0e0", foreground="black", command=self.cobrar_total)
        self.btn_cobrar.place(x=360, y=460)
        

        self.btn_cancelar = tk.Button(self.cobrar, text="Cancelar", width=12, font=("Arial", 14, "bold"), background="#e0e0e0", foreground="black", command=self.cancelar_venta)
        self.btn_cancelar.place(x=360, y=525)
        
    def formatear_comas(self, event):
        
        texto = self.pago.get()
        
        texto = ''.join([c for c in texto if c.isdigit()])
        
        if texto:
            numero = int(texto)
            texto_formateado = f"{numero:,.0f}"
            
        else:
            texto_formateado = ""
            
        self.pago.delete(0, tk.END)
        self.pago.insert(0, texto_formateado)
        
    def calcular_vueltos(self, event):
      
        total_venta_texto = self.total.cget("text") 
        total_venta_sin_comas = ''.join([c for c in total_venta_texto if c.isdigit()]) 
        if total_venta_sin_comas:
            total_venta = int(total_venta_sin_comas) 
        else:
            total_venta = 0 
            
      
        texto_pago = self.pago.get().replace(",", "")  
        try:
            pago = float(texto_pago)
        except ValueError:
            pago = 0  
        
        
        vuelto = pago - total_venta
        
      
        if vuelto < 0:
            vuelto = 0
        
      
        self.vueltos.config(text=f"$ {vuelto:,.0f}")  
        
      
        texto_pago_formateado = f"{pago:,.0f}"
        self.pago.delete(0, tk.END)
        self.pago.insert(0, texto_pago_formateado)
        
    def cobrar_total(self):
        
        import ventas
        total_venta = self.total.cget("text")  
        total_venta = total_venta.replace("$", "").replace(",", "").strip()  
        total_venta = float(total_venta) 
        
        pago = self.pago.get().replace(",", "").strip()

        if not pago:
            mb.showerror("Error", "Ingrese el dinero recibido", parent=self.cobrar)
            return
        
        pago = float(pago)
        
        if pago < total_venta:
            mb.showwarning("Advertencia", "El pago ingresado es menor al total", parent=self.cobrar)
            return
        
        id_venta = realizar_venta(total_venta, self.id_empleado)
        
        if id_venta:
            
            for producto in self.productos_comprados:
                insertar_producto_has_venta(id_venta, producto[0], producto[1], producto[2])
            mb.showinfo("Informacion", "Se ha realizado correctamente la venta", parent = self.cobrar)
            
            self.total.config(text=f"$ {0.00 : ,.0f}")
            self.pago.delete(0, tk.END)
            self.total_articu.config(text=0)
            
            self.cobrar.destroy()
            
            for producto in self.productos_comprados:
                actualizar_stock(producto[0], producto[1])
                print(producto[0], producto[1])
            
    def cancelar_venta(self):
        
        if mb.askyesno("Confirmar", "Desea cancelar el cobro?", parent=self.cobrar):
            self.cobrar.destroy()
#cobrar()