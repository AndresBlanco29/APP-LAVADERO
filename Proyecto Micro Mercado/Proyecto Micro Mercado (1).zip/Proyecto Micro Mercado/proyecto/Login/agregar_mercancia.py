import tkinter as tk
from tkinter import ttk
from tkinter import messagebox as mb
from PIL import Image, ImageTk
import os

class Mercancia:
    def __init__(self):
        
        self.total_a_pagar = 0

        self.mercancia = tk.Toplevel()
        
        self.mercancia.title("Agregar Mercancia")

        self.mercancia.geometry("805x680")
        
        self.mercancia.bind("<Motion>", self.mostrar_coordenadas)

        self.center_window(805, 680)

        self.items()

        self.mercancia.mainloop()
        
    def mostrar_coordenadas(self, event):
        print(f"Coordenadas: {event.x}, {event.y}")

    def center_window(self, width, height):
 
        screen_width = self.mercancia.winfo_screenwidth()
        screen_height = self.mercancia.winfo_screenheight()

        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)

        self.mercancia.geometry(f'{width}x{height}+{x}+{y}')

    def items(self):
        
        import Consultas

        self.ancho_ventana = 805
        self.alto_ventana = 680
        
        ruta_imagen = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'agregar_mercancia.png')
        print(f"Cargando imagen desde: {ruta_imagen}")  
        self.img_agregar_m = tk.PhotoImage(file=ruta_imagen)
        
        ruta_imagen_agregar = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'agregar.png')
        print(f"Cargando imagen desde: {ruta_imagen_agregar}")  

        img_agregar_pil = Image.open(ruta_imagen_agregar)
        img_agregar_pil = img_agregar_pil.resize((30, 30), Image.Resampling.LANCZOS)  

        self.img_agregar = ImageTk.PhotoImage(img_agregar_pil)

        img_ancho = self.img_agregar_m.width()
        img_alto = self.img_agregar_m.height()

        self.canvas1 = tk.Canvas(self.mercancia, width=self.ancho_ventana, height=self.alto_ventana)
        self.canvas1.grid(row=0, column=0, columnspan=2, rowspan=5) 

        img_x = (self.ancho_ventana // 2) - (img_ancho // 2) -6
        img_y = (self.alto_ventana // 2) - (img_alto // 2) 

        self.canvas1.create_image(img_x, img_y, anchor="nw", image=self.img_agregar_m)

        self.tree_productos = ttk.Treeview(self.mercancia, columns=("Codigo", "Nombre", "Precio_de_venta", "Precio_de_Compra", "Cantidad"), show="headings", height=7)
        self.tree_productos.column("# 1", anchor="center", width=140)
        self.tree_productos.heading("# 1", text="Codigo")
        self.tree_productos.column("# 2", anchor="center", width=170)
        self.tree_productos.heading("# 2", text="Nombre")
        self.tree_productos.column("# 3", anchor="center", width=140)
        self.tree_productos.heading("# 3", text="Precio_de_venta")
        self.tree_productos.column("# 4", anchor="center", width=140)
        self.tree_productos.heading("# 4", text="Precio_de_Compra")
        self.tree_productos.column("# 5", anchor="center", width=120)
        self.tree_productos.heading("# 5", text="Cantidad")
        
        for row in Consultas.mostrar_Productos():
            self.tree_productos.insert("", "end", values=row)
            
        if self.tree_productos.get_children():
            first_item = self.tree_productos.get_children()[0]
            self.tree_productos.selection_set(first_item)
        
        self.tree_productos.place(x=50, y=235)

        self.tree_productos_agregado = ttk.Treeview(self.mercancia, columns=( "Nombre",  "Precio_de_Compra", "Agregar_Cantidad"), show="headings", height=7)
        self.tree_productos_agregado.column("# 1", anchor="center", width=140)
        self.tree_productos_agregado.heading("# 1", text="Nombre")
        self.tree_productos_agregado.column("# 2", anchor="center", width=170)
        self.tree_productos_agregado.heading("# 2", text="Precio_de_Compra")
        self.tree_productos_agregado.column("# 3", anchor="center", width=140)
        self.tree_productos_agregado.heading("# 3", text="Agregar_Cantidad")

        self.tree_productos_agregado.place(x=70, y=430)

        self.añadir_proveedor = ttk.Combobox(self.mercancia, width=28, font=("Arial", 12))
        self.añadir_proveedor.place(x=397, y=100)
        
        self.llenar_combo()

        self.buscar_producto = tk.Entry(self.mercancia, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=29, font=("Arial", 12))
        self.buscar_producto.place(x=397, y=138)
        
        self.buscar_producto.bind("<KeyRelease>", self.buscar)

        self.mostrar_producto = tk.Entry(self.mercancia, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=22, font=("Arial", 12))
        self.mostrar_producto.place(x=236, y=187)
        
        self.añadir_producto = tk.Entry(self.mercancia, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=10, font=("Arial", 12))
        self.añadir_producto.place(x=513, y=187)

        self.ingresar_dinero = tk.Entry(self.mercancia, highlightthickness=3, highlightbackground="#c5c5c5", highlightcolor="#c5c5c5", width=16, font=("Arial", 12))
        self.ingresar_dinero.place(x=585, y=472)

        self.borde_finalizar_compra = tk.Frame(self.mercancia, background="white", bd=1)
        self.borde_finalizar_compra.place(x=600, y=615)
        

        self.finalizar_compra = tk.Button(self.borde_finalizar_compra, text="Finalizar Compra", width=13, font=("Arial", 12, "bold"), background="#d17100", foreground="Black", command=self.comprar)
        self.finalizar_compra.pack()
        

        self.borde_cancelar_compra = tk.Frame(self.mercancia, background="white", bd=1)
        self.borde_cancelar_compra.place(x=450, y=615)

        self.cancelar_compra = tk.Button(self.borde_cancelar_compra, text="Cancelar Compra", width=13, font=("Arial", 12, "bold"), background="#e51400", foreground="Black", anchor="center", command=self.cancelar)
        self.cancelar_compra.pack()
        
        self.borde_quitar_producto_seleccionado = tk.Frame(self.mercancia, background="white", bd=1)
        self.borde_quitar_producto_seleccionado.place(x=150, y=615)
        
        self.quitar_producto_seleccionado = tk.Button(self.borde_quitar_producto_seleccionado, text="Quitar producto seleccionado", background="#131861", font=("Arial", 12, "bold"), foreground="White", width=24, command=self.quitar_producto)
        self.quitar_producto_seleccionado.pack()
        

        self.btn_agregar = tk.Button(self.mercancia, image=self.img_agregar, command=self.agregar_funcion, bg="#131861", bd=0)
        self.btn_agregar.place(x=620, y=186)
        
        self.total = tk.Label(self.mercancia, text="$ 0.00", font=("Arial", 35, "bold"), fg="white", bg="#171d74")
        self.total.place(x=540, y=520)
    
        self.tree_productos.bind("<<TreeviewSelect>>", self.obtener_datos_seleccionados)
        
    def agregar_funcion(self):
        try:
            nombre = self.mostrar_producto.get()
            cantidad_a_agre = self.añadir_producto.get()

            if not cantidad_a_agre.isdigit():
                mb.showerror("Error", "Por favor ingrese una cantidad válida.", parent = self.mercancia)
                return
                
            cantidad_a_agre = int(cantidad_a_agre)  

            for item in self.tree_productos.get_children():
                producto = self.tree_productos.item(item, 'values')

                if producto[1] == nombre:
                    cantidad_actual = int(producto[4])
                    nueva_cantidad = cantidad_actual + cantidad_a_agre 
                    
                    precio_compra = int(producto[3])
                    
                    total_pagar = cantidad_a_agre * precio_compra  

                    encontrado = False
                    for item_agregado in self.tree_productos_agregado.get_children():
                        producto_agregado = self.tree_productos_agregado.item(item_agregado, 'values')

                        if producto_agregado[0] == nombre:
                            cantidad_agregada_actual = int(producto_agregado[2])  
                            nueva_cantidad_agregada = cantidad_agregada_actual + cantidad_a_agre
                            total_agregado_actual = int(producto_agregado[1])  
                            nuevo_total = total_agregado_actual + total_pagar
                            
                            self.total_a_pagar += total_pagar  
                            self.total.config(text=f"$ {self.total_a_pagar}", font=("Arial", 35, "bold"), fg="white", bg="#171d74") 
                            self.tree_productos_agregado.item(item_agregado, values=(nombre, producto[3],nueva_cantidad_agregada))
                            
                            encontrado = True
                            break

                    if not encontrado:
                        self.tree_productos_agregado.insert("", "end", values=(nombre, producto[3], cantidad_a_agre))
                        self.total_a_pagar += total_pagar 
                        self.total.config(text=f"$ {self.total_a_pagar}", font=("Arial", 35, "bold"), fg="white", bg="#171d74")  

                    self.añadir_producto.delete(0, tk.END)
                    return
            mb.showerror("Error", "Producto no encontrado.", parent = self.mercancia)
        except ValueError as error:
            mb.showerror("Error al agregar {}".format(error), parent = self.mercancia)

    def quitar_producto(self):
        try:
            producto_seleccionado = self.tree_productos_agregado.selection()

            if not producto_seleccionado:
                mb.showwarning("Advertencia", "Debe seleccionar un producto", parent = self.mercancia)
                return
            
            for item in producto_seleccionado:
                producto_agregado = self.tree_productos_agregado.item(item, 'values')
                precio_compra = int(producto_agregado[1])
                cantidad_agregada = int(producto_agregado[2])

                total_restar = precio_compra * cantidad_agregada

                self.total_a_pagar -= total_restar
                self.total.config(text=f"$ {self.total_a_pagar}", font=("Arial", 35, "bold"), fg="white", bg="#171d74")
                
                self.tree_productos_agregado.delete(item)
        except ValueError as error:
            mb.showerror("Error","Erro al quitar el producto seleccionado", parent = self.mercancia)
    
    def cancelar(self):
        
        confirmacion = mb.askyesno("Confirmar", "Desea cancelar?", parent = self.mercancia)
        
        if not confirmacion:
            return
            
        for item in self.tree_productos_agregado.get_children():
            self.tree_productos_agregado.delete(item)
            
        for item in self.tree_productos.get_children():
            self.tree_productos.delete(item)
        

        self.total_a_pagar = 0
        self.total.config(text=f"$ {self.total_a_pagar}", font=("Arial", 35, "bold"), fg="white", bg="#171d74")
        

        self.añadir_proveedor.delete(0, tk.END)
        self.añadir_producto.delete(0, tk.END)
        self.mostrar_producto.delete(0, tk.END)
        self.buscar_producto.delete(0, tk.END)
        self.ingresar_dinero.delete(0, tk.END)
        self.buscar_producto.focus()
        
        mb.showinfo("Compra Cancelada", "La compra ha sido cancelada.", parent = self.mercancia)

    
    def comprar(self):
        import Consultas

        if not self.tree_productos_agregado.get_children():
            mb.showinfo("Sin artículos", "No hay artículos para comprar.", parent=self.mercancia)
            return  

  
        for item in self.tree_productos_agregado.get_children():
            producto_agregado = self.tree_productos_agregado.item(item, 'values')
            nombre = producto_agregado[0]
            cantidad_agrega = int(producto_agregado[2])

            producto_info = Consultas.obtener_producto_por_nombre(nombre)
            
            if producto_info:
                cantidad_actual = producto_info[4]  
                nueva_cantidad = cantidad_actual + cantidad_agrega
                
                print(f"Actualizando producto: {nombre}, Cantidad actual: {cantidad_actual}, Cantidad a agregar: {cantidad_agrega}, Nueva cantidad: {nueva_cantidad}")
                
               
                resultado = Consultas.actualizar_cantidad_producto(nombre, nueva_cantidad)
                if not resultado:
                    mb.showerror("Error", f"No se pudo actualizar el producto: {nombre}", parent=self.mercancia)
                    return  

    
        self.tree_productos_agregado.delete(*self.tree_productos_agregado.get_children())

    
        self.total_a_pagar = 0
        self.total.config(text=f"$ {self.total_a_pagar}")

    
        self.tree_productos.delete(*self.tree_productos.get_children())
        productos_actualizados = Consultas.mostrar_Productos()
        
        for row in productos_actualizados:
            self.tree_productos.insert("", "end", values=row)

        mb.showinfo("Éxito", "Compra realizada y productos actualizados correctamente.", parent=self.mercancia)

     
        self.añadir_proveedor.delete(0, tk.END)
        self.añadir_producto.delete(0, tk.END)
        self.mostrar_producto.delete(0, tk.END)
        self.buscar_producto.delete(0, tk.END)
        self.ingresar_dinero.delete(0, tk.END)
        self.buscar_producto.focus()

    
    def llenar_combo(self):
        import Consultas
        proveedores = Consultas.llenar_combobox()
        self.añadir_proveedor ['values'] = proveedores
        
    def buscar(self, event=None):
        import Consultas
        try:
            codigo = self.buscar_producto.get()
            
            if not (codigo,):
                mb.showwarning("Advertencia","Ingrese el codigo a buscar", parent = self.mercancia)
                
                
            self.tree_productos.delete(*self.tree_productos.get_children())
            resultados = Consultas.buscar_productos(codigo, codigo, codigo)
            
            for row in resultados:
                self.tree_productos.insert("", tk.END, values=row)
                
            if self.tree_productos.get_children():
                self.first_item = self.tree_productos.get_children()[0]
                self.tree_productos.selection_set(self.first_item)
                self.obtener_datos_seleccionados()
                
        except ValueError as error:
            mb.showerror("Error al buscar el producto {}".format(error), parent = self.mercancia)
            
    def obtener_datos_seleccionados(self, event=None):
        try:
            datos = self.tree_productos.selection()
            if not datos:
                self.mostrar_producto.delete(0, tk.END)
            if datos:
                item = self.tree_productos.item(datos, 'values')
                nombre_producto = item[1]
                
                self.mostrar_producto.delete(0, tk.END)
                self.mostrar_producto.insert(0, nombre_producto)
                
        except ValueError as error:
            mb.showerror("Error","Error al obtener los datos seleccionados", parent = self.mercancia)
#Mercancia()
